# Arquitetura implementada — YSO CRM

## Atualização de 27/10/2026 — acessos e clínica

Nome da instalação: Dr. Alexandre Fuzimoto. Mesma base demonstrativa, com registros antigos preservados; não é banco de pacientes. Cada futura empresa deve ter instalação e banco separados. Não há isolamento multiempresa nesta aplicação.

`migrations/002-auth.sql` acrescenta usuários, sessões, limites de tentativas e auditoria, além de autor opcional nas notas. `src/auth.mjs` usa scrypt com salt aleatório; o banco armazena somente hash das senhas e dos tokens. Cookie HttpOnly/SameSite Strict, validade máxima de 8h e inatividade de 30min. Polling não renova inatividade. Cookie sem Secure somente porque a aplicação é HTTP estritamente local; produção requer HTTPS e revisão de configuração.

Rotas de dados exigem sessão ativa; troca de senha temporária é obrigatória. Gerenciamento de contas e auditoria exigem administrador no servidor. Desativação, alteração de acesso e senha revogam sessões. Criação inicial protegida por transação; credencial temporária fora do repositório, em AppData, herda as permissões restritas da pasta.

Atendente pode operar todos os clientes/atendimentos desta instalação. Responsáveis de acompanhamento são rótulos em owners, não contas em app_users. Auditoria registra login, alterações de acesso/senha e criação/alteração de atendimentos; não é trilha completa de todas as operações. Histórico antigo não ganha autor inventado.

`public/whatsapp.js` monta somente URL https://wa.me com telefone validado, digitado temporariamente. Nenhuma chamada de API ou gravação de telefone. O clique no link transmite o número ao WhatsApp; não inclui dados do atendimento. Não há envio, sincronização ou confirmação de entrega.

38 testes automatizados aprovados nesta atualização, incluindo autenticação e permissões. A descrição de 23 testes abaixo é o marco anterior. Guia atual: README.md; material de operação em docs/GUIA-CLINICA.md e docs/TREINAMENTO-WHATSAPP.md.

## Estrutura

- `public/`: interface HTML/CSS/JavaScript, logo YSO e paleta azul-marinho/turquesa/branco.
- `src/server.mjs`: servidor HTTP e API local, validação de origem, entrega de arquivos públicos e respostas de erro.
- `src/rules.mjs`: regras de cadastro, datas e transições.
- `src/db.mjs`: conexão PostgreSQL, migração e exemplos fictícios.
- `migrations/001-initial.sql`: clientes, responsáveis, atendimentos, notas e restrições.
- `scripts/`: inicialização, preparação, backup e verificação de restauração.
- `test/`: testes de regras e integração com banco separado.

A interface funciona em `http://127.0.0.1:3000`; o PostgreSQL em `127.0.0.1:5432`. Ambos são locais. Somente rotas de arquivos públicos explícitas são servidas. O navegador não recebe credenciais.

## PostgreSQL instalado

PostgreSQL 18.6 instalado pelos binários Windows oficiais disponibilizados pela EDB. Foi escolhida uma instalação isolada por usuário, sem serviço automático, em `%LOCALAPPDATA%\YSO\crm-demo\runtime\pgsql`. O cluster fica em `pgdata` na mesma raiz, fora do OneDrive. `npm.cmd start` inicia o cluster quando necessário.

Autenticação SCRAM, senhas aleatórias geradas localmente e arquivos de configuração protegidos por permissões Windows. `admin.json` é usado somente na preparação; `app.json` pelo backend. O usuário `yso_crm_app` não tem SUPERUSER, CREATEDB ou CREATEROLE, e é proprietário das bases do demonstrativo e testes. Não há uso de Supabase ou Render.

Bases existentes: `yso_crm_demo`, `yso_crm_test` e `yso_crm_restore_test`. A última contém a cópia usada na primeira verificação de restauração, não acompanha automaticamente alterações posteriores.

## Consistência

Consultas parametrizadas, chaves estrangeiras e contato único normalizado. Mudanças de etapa, notas e retornos são gravadas numa única transação e conexão. A linha do atendimento é bloqueada durante a alteração; um número de versão impede sobrescrever uma mudança feita em outra tela.

Retorno usa DATE e chega à API como AAAA-MM-DD, sem conversão de fuso. Notas usam TIMESTAMPTZ. A exibição e o cálculo de hoje seguem America/Sao_Paulo. Atendimentos encerrados ficam somente para consulta. O cadastro compartilhado do cliente continua editável.

Os exemplos são inseridos explicitamente por `npm.cmd run setup`, somente quando não há clientes. Reiniciar a aplicação não executa reset. O pacote pg 8.23.1 está fixado no lockfile; npm ci reproduz as dependências numa futura cópia do projeto.

## Backup, testes e operação

`npm.cmd run backup` usa pg_dump em formato custom e grava na pasta local `backups`. O PostgreSQL permanece funcionando. `node scripts/verify-backup.mjs` restaura o backup mais recente em uma base com nome yso_crm_restore seguido do instante da execução; compara todas as nove tabelas, incluindo acessos e auditoria. Não sobrescreve bases anteriores. Execute backup e comparação sem operações no CRM entre eles, pois a comparação é contra a base atual. Cada verificação deixa uma base separada preservada e consome espaço; sua remoção deve ser deliberada.

23 testes automatizados aprovados com PostgreSQL real. A base yso_crm_test é explicitamente conferida antes da limpeza. A interface foi exercitada com um cliente e atendimento fictícios. Dados sobreviveram ao reinício do backend; backup/restauração foram verificados separadamente.

Use Iniciar CRM.cmd ou npm.cmd start; Ctrl+C encerra o backend. Após isso, npm.cmd run stop encerra somente o cluster PostgreSQL deste projeto. Não há publicação, serviço pago, integração automática WhatsApp ou envio de e-mail.

## Identidade visual

Logo fornecida pelo usuário, copiada sem alteração para public/yso-logo.jpg. Cores de interface inspiradas nela: azul-marinho #092B50, turquesa #00A7A5 e branco; botões usam turquesa escuro #007D80 para leitura. Essas cores são escolhas de interface, não uma especificação oficial extraída da marca.

## Referências

- [Binários oficiais para Windows](https://www.enterprisedb.com/download-postgresql-binaries).
- [PostgreSQL para Windows](https://www.postgresql.org/download/windows/).
- [node-postgres](https://node-postgres.com/).

