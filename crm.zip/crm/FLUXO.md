# Fluxo funcional — oficina fictícia YSO

Definido em 26/10/2026. Este documento define as regras da primeira versão local implementada. Consulte README.md para executar e demonstrar.

## Cenário e jornada

A Oficina Horizonte Demo é inteiramente fictícia. A recepção registra uma solicitação, acompanha a avaliação e a decisão do cliente, segue a execução e encerra o atendimento após a entrega simulada.

1. **Receber:** localizar ou cadastrar o cliente fictício; abrir um atendimento com o serviço desejado, um responsável e a data da próxima atualização.
2. **Avaliar:** registrar o diagnóstico simulado e a proposta de serviço nas observações.
3. **Aguardar a decisão:** simular a apresentação da proposta ao cliente e agendar o retorno para obter uma resposta.
4. **Executar:** registrar a aprovação simulada e acompanhar o serviço, mantendo uma próxima data de atualização.
5. **Encerrar:** registrar o resultado e a entrega simulada, concluindo o atendimento; se houver desistência, registrar o motivo e cancelar.

O cliente possui um cadastro reutilizável e pode ter vários atendimentos. Cada atendimento representa uma solicitação acompanhada de forma independente, com seu próprio responsável e retorno. Uma nova visita gera outro atendimento, preservando o anterior.

## Etapas e transições

| Etapa | Significado | Condição para avançar |
| --- | --- | --- |
| Novo atendimento | Solicitação recebida e registrada. | Ir para Em avaliação quando o responsável iniciar a análise. |
| Em avaliação | Oficina analisa o pedido. | Ir para Aguardando aprovação após registrar diagnóstico e proposta nas observações. |
| Aguardando aprovação | Proposta apresentada de forma simulada; decisão pendente. | Ir para Em execução após registrar explicitamente a aprovação simulada. |
| Em execução | Serviço aprovado em andamento. | Ir para Concluído após registrar serviço realizado e entrega simulada. |
| Concluído | Serviço e entrega finalizados. | Etapa final, sem retorno pendente. |
| Cancelado | Atendimento interrompido ou proposta recusada. | Etapa final; motivo do cancelamento obrigatório. |

Regras do demonstrativo:

- Todo novo atendimento começa em Novo atendimento. O caminho normal segue a ordem da tabela, sem saltar etapas.
- Qualquer etapa ativa pode ir para Cancelado com motivo registrado.
- Aguardando aprovação pode voltar para Em avaliação quando a proposta precisar de revisão; registrar o motivo. Uma proposta revisada precisa de nova aprovação antes da execução.
- Concluído e Cancelado são finais: não reabrir nem alterar os dados do atendimento nesta versão. Uma nova solicitação gera outro atendimento para o mesmo cliente.
- Ao mudar uma etapa ativa, confirmar responsável e próximo retorno. A data pode ser mantida se ainda for válida.
- Ao encerrar, registrar a observação exigida e limpar a data do próximo retorno na mesma operação.
- O responsável é quem acompanha o atendimento, mesmo quando outra pessoa executa o serviço. Transferir a responsabilidade é permitido enquanto o atendimento estiver ativo, sempre para alguém da lista fictícia.

## Campos e obrigatoriedade

| Entidade / campo | Obrigatório? | Regra |
| --- | --- | --- |
| Cliente / nome | Sim | Texto não vazio; usar nome claramente fictício. |
| Cliente / contato de demonstração | Sim | Usar e-mail fictício terminado em `@example.com`, por exemplo `cliente01@example.com`. Não enviar mensagens. |
| Atendimento / cliente | Sim | Selecionar um cadastro existente ou cadastrar o cliente antes de salvar. |
| Atendimento / serviço solicitado | Sim | Descrever o pedido em texto não vazio, por exemplo “Avaliação de ruído nos freios”. |
| Atendimento / etapa | Sim | Um dos seis valores definidos; começa em Novo atendimento. |
| Atendimento / responsável | Sim | Selecionar uma pessoa da equipe fictícia da oficina. |
| Atendimento / observações | Condicional | Opcional na abertura; adicionar uma nota para avaliação/proposta, aprovação, revisão, conclusão ou cancelamento conforme a transição. |
| Atendimento / data do próximo retorno | Sim, enquanto ativo | Data válida, exibida como DD/MM/AAAA. Vazia em Concluído e Cancelado. |

Identificadores internos de cliente e atendimento serão gerados automaticamente, sem preenchimento pelo usuário. O contato fictício será único por cliente, ignorando espaços nas extremidades e diferenças entre maiúsculas e minúsculas; se já existir, reutilizar o cadastro. Nomes iguais, sozinhos, não identificam o mesmo cliente.

Textos obrigatórios não podem conter apenas espaços. As observações serão notas acrescentadas ao atendimento, preservando as anteriores; cada nota terá data e hora automáticas. Para uma transição que exige observação, uma nota antiga não substitui a nova justificativa. Mensagens de validação deverão indicar o campo a corrigir e preservar o que já foi preenchido.

Para manter o foco no acompanhamento comercial, veículo, placa, CPF, endereço, valores, pagamentos, peças e estoque ficam fora desta versão. Se necessário para o cenário, uma descrição fictícia de veículo pode aparecer nas observações, sem criar novos campos obrigatórios.

## Próximo retorno

A data representa quando o responsável deve revisar o atendimento ou simular uma atualização ao cliente; não é um agendamento de serviço e não dispara mensagem automática.

- Ao criar ou reagendar, aceitar hoje ou uma data futura, usando o calendário de America/Sao_Paulo.
- Retorno para hoje: destacar como **Hoje**.
- Retorno anterior a hoje em atendimento ativo: destacar como **Atrasado**. A passagem do tempo não muda a etapa nem cancela o atendimento.
- Retorno futuro: indicar como **Agendado**.
- Um retorno vencido já salvo não impede consultar ou editar outros campos. Para avançar ou retroceder entre etapas ativas, é necessário atualizá-lo para hoje ou depois.
- Concluir ou cancelar é permitido mesmo com retorno vencido; o encerramento remove a pendência.
- Retornos ocorrem em qualquer dia do calendário nesta versão, sem regras de feriados ou dias úteis.

## Telas previstas — esboço textual

1. **Clientes:** lista com nome e contato fictício; ação para cadastrar e selecionar um cliente e consultar seus atendimentos.
2. **Atendimentos:** lista com cliente, serviço, etapa, responsável e próximo retorno; filtros por etapa, responsável e retorno (Hoje, Atrasado ou Agendado). Atendimentos encerrados continuam consultáveis, sem pendências de retorno.
3. **Detalhe do atendimento:** dados do cliente, serviço, etapa, responsável, notas e retorno; ações para editar dados permitidos, adicionar nota, avançar, revisar proposta ou cancelar. Encerrados ficam somente para consulta.

Esse esboço define o conteúdo e as ações. A tecnologia está definida em [ARQUITETURA.md](ARQUITETURA.md); a aparência será construída na etapa de implementação.

## Exemplos exclusivamente fictícios

Responsáveis fictícios da oficina: **Bia Demo (recepção)** e **Rui Demo (serviços)**. São personagens do cenário e não representam os papéis de Luca, Japonês, João ou Enzo na equipe YSO.

| Cliente | Contato fictício | Serviço | Etapa | Responsável | Próximo retorno |
| --- | --- | --- | --- | --- | --- |
| Marina Cliente Demo | marina.demo@example.com | Avaliação de ruído nos freios | Novo atendimento | Bia Demo | Hoje |
| Pedro Cliente Demo | pedro.demo@example.com | Revisão preventiva | Aguardando aprovação | Rui Demo | Amanhã |
| Carla Cliente Demo | carla.demo@example.com | Avaliação de ruído na suspensão | Em avaliação | Rui Demo | Ontem — exemplo de pendência vencida |

Hoje, amanhã e ontem são relativos ao dia da demonstração, não textos a salvar no campo de data. O caso vencido simula um atendimento cadastrado anteriormente; não autoriza cadastrar um novo retorno no passado. O exemplo de Pedro deve incluir notas anteriores de avaliação e proposta simuladas.

## Roteiro mínimo da demonstração futura

1. Cadastrar Marina Cliente Demo com seu contato fictício e abrir o pedido de avaliação dos freios; atribuir Bia Demo e retorno para hoje.
2. Mostrar que os campos obrigatórios impedem salvar um atendimento incompleto.
3. Iniciar a avaliação e transferir o acompanhamento para Rui Demo.
4. Adicionar “Avaliação simulada concluída; proposta: revisão dos freios” e mover para Aguardando aprovação, com retorno para amanhã.
5. Registrar “Cliente fictícia aprovou a proposta na simulação” e mover para Em execução, confirmando a próxima atualização.
6. Registrar “Revisão fictícia concluída e entrega simulada realizada” e concluir; verificar que o retorno foi limpo.
7. Usar outro atendimento fictício para demonstrar cancelamento com motivo, sem alterar o concluído.
8. Consultar o caso atrasado de Carla e reagendar para hoje, registrando uma nota sobre o acompanhamento simulado.

## Critérios para os testes futuros

- Não salvar cadastro ou atendimento com campo obrigatório ausente ou preenchido apenas com espaços.
- Reutilizar cliente pelo contato fictício e permitir múltiplos atendimentos independentes.
- Impedir etapas fora da sequência e transições sem a nova nota obrigatória.
- Exigir aprovação registrada antes de iniciar execução.
- Destacar corretamente retornos de hoje, futuros e vencidos, incluindo a virada do dia.
- Impedir novas datas inválidas ou passadas, sem bloquear edição de outros campos de um caso já vencido.
- Exigir motivo para cancelamento e resultado/entrega para conclusão; limpar retorno em ambos.
- Preservar notas anteriores e manter encerrados para consulta.

Todas as interações com clientes são simuladas. Não haverá WhatsApp real, envio de e-mail, serviços pagos ou publicação na internet.


## Proteção contra duplicação nas novas observações

Antes de salvar, a tela e o servidor rejeitam frases iguais de pelo menos três palavras ou blocos inteiros colados repetidamente na mesma observação. A comparação ignora diferenças de maiúsculas/minúsculas e espaços. O aviso mantém o texto no formulário para revisão; não há corte automático. Palavras recorrentes em frases distintas continuam permitidas. A regra não compara notas de datas diferentes nem altera o histórico existente. Se rejeitada, a operação não muda etapa, versão ou notas do atendimento.
# Nota de escopo — 27/10/2026

Este arquivo preserva o fluxo original da oficina fictícia e seus exemplos. O primeiro cliente agora é Dr. Alexandre Fuzimoto; consulte **docs/GUIA-CLINICA.md** para a simulação administrativa. Não reutilize diagnósticos ou serviços mecânicos como registros de pacientes. Os dados anteriores não foram convertidos.

