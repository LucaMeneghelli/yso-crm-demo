@echo off
cd /d "%~dp0"
echo Iniciando YSO CRM local...
echo Abra http://127.0.0.1:3000 no navegador quando aparecer Local.
call npm.cmd start
pause
