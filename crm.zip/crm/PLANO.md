# Plano YSO — CRM e operação da clínica

## Prioridade atual — teste na escola pelo navegador

Publicação gratuita autorizada. Supabase `yso-crm-escola` criado em Ohio e disponível; modo online preparado e 43 testes locais aprovados. Render pertence a Luca, mas o GitHub conectado pertence a outra pessoa: criar repositório na conta de Luca. Falta publicar, configurar segredos e validar os dois perfis online. Nenhuma contratação paga autorizada.

Atualizado em 27/10/2026. Cliente: **Dr. Alexandre Fuzimoto**. Dados fictícios e ambiente local. Clínica e YSO usarão WhatsApp Business; primeira ligação autorizada: botão para abrir conversa, envio manual. Site institucional fica depois do CRM e treinamento.

## Equipe

| Pessoa/equipe | Responsabilidade |
| --- | --- |
| Luca e Japonês | Desenvolver juntos, testar, manter código, acessos e implantação. |
| João | Comercial, escopo dos planos e alinhamento com a clínica. |
| Enzo | Conteúdo, respostas e material de treinamento. |
| Clínica | Validar horários, informações administrativas e responsáveis. |
| Clínica + YSO | Contas individuais, um responsável por conversa e próximo retorno definido. |

## 1. Ambiente

- [x] Node/npm/Git verificados; PostgreSQL isolado fora do OneDrive.
- [x] Aplicação local e bancos separados de demonstração e testes.
- [x] Identidade YSO, inicialização e backup.
- [ ] Organizar colaboração Git e revisão conjunta Luca/Japonês.
- [ ] Planejar hospedagem após validar o piloto; nada contratado/publicado.

## 2. Fluxo

- [x] Jornada original da oficina preservada em FLUXO.md.
- [x] Guia administrativo da clínica e operação compartilhada preparados.
- [ ] Validar nomes definitivos das etapas e transferências com a clínica.
- [ ] Definir necessidade de agenda com horário: hoje há somente data de retorno.

## 3. Implementação

- [x] Contatos fictícios, atendimentos, filtros, retornos e histórico.
- [x] Prevenção de notas duplicadas e preservação dos encerrados.
- [x] Login administrador/atendente; troca inicial obrigatória e sessões revogáveis.
- [x] Gestão de usuários e auditoria de contas/atendimentos.
- [x] Nome Dr. Alexandre Fuzimoto e orientação administrativa.
- [x] Atalho WhatsApp com número temporário, sem envio ou sincronização.
- [ ] Associar responsáveis às contas da equipe após definir os operadores.
- [ ] Preparar instalação separada para clínica antes de inserir dados reais.
- [ ] Integração oficial de mensagens apenas em projeto posterior, após avaliar número, acessos, necessidade e custos.

## 4. Testes

- [x] 38 testes automatizados em PostgreSQL isolado.
- [x] Permissões verificadas pelo servidor; senha temporária, expiração, logout e revogação.
- [x] Registros anteriores comparados após migração, sem alterações de conteúdo.
- [x] Backup anterior à migração.
- [x] Backup atualizado restaurado e comparado em nove tabelas, incluindo acessos.
- [x] Interface verificada: login, painel, acessos, auditoria, link manual e logout.
- [ ] Homologação conjunta clínica/YSO com contas e contatos de teste autorizados.
- [ ] Testes de carga, recuperação e revisão de segurança no futuro ambiente de produção.

## 5. Demonstração e treinamento

- [x] Roteiro de WhatsApp Business e guia administrativo preparados.
- [ ] Luca definir senha pessoal do administrador.
- [ ] Criar contas individuais de quem participará.
- [ ] Ministrar treinamento de 45 minutos, incluindo transferência entre equipes.
- [ ] João validar plano 1 (cliente opera) e plano 2 (YSO participa), horários, escopo e limites. Preços não definidos.
- [ ] Enzo revisar mensagens com a clínica, sem promessas não aprovadas.

Próximo passo: simulação completa da recepção, do primeiro contato à confirmação administrativa. Treinamento preparado, ainda não ministrado.
Histórico anterior: docs/PLANO-oficina-2026-10-26.md.


## Evolução de 29/10/2026
Telefone persistente, WhatsApp por cliente e atendimento, mostrar senha e apresentação sem rótulos de demonstração implementados. 44 testes locais passaram. Modelo: mesmo código com banco e implantação separados por empresa. Parametrização da clínica, revisão visual, validação online de atendente e limpeza com backup ainda pendentes. Detalhes: docs/ATUALIZACAO-CONTATOS.md.

## Financeiro — 29/10/2026
Módulo implementado com separação de acesso, centavos inteiros, parcelas, pagamentos parciais e estornos auditados. Migração aditiva 004. Validação local: 46 testes; ver docs/FINANCEIRO.md. Conferência autenticada online e validação móvel pendentes.
