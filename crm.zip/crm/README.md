# YSO CRM — Dr. Alexandre Fuzimoto

**Online:** https://yso-crm-escola.onrender.com/ — publicação inicial confirmada em 28/10/2026. Evolução de contatos e WhatsApp em [ATUALIZACAO-CONTATOS.md](docs/ATUALIZACAO-CONTATOS.md).

Atualizado em 29/10/2026. CRM administrativo de recepção. Não é prontuário nem agenda clínica. Os cadastros e históricos existentes permanecem preservados; entrada em operação real depende das verificações descritas na atualização.

## Abrir e entrar

1. Execute **Iniciar CRM.cmd** e mantenha o terminal aberto. Se já estiver iniciado, abra http://127.0.0.1:3000.
2. Administrador inicial: `admin@yso.local`. A senha temporária está em `C:\Users\lucam\AppData\Local\YSO\crm-demo\primeiro-acesso.txt`, fora do projeto. Não compartilhe esse arquivo.
3. No primeiro acesso, digite a senha temporária como senha atual e escolha sua senha pessoal (12 a 128 caracteres). Entre novamente; a senha temporária deixa de funcionar.
4. Em **Acessos da equipe**, crie uma conta individual por pessoa. Atendente para operação diária; Administrador para quem gerenciar acessos.
5. Ao terminar, use **Sair do CRM**. A sessão expira após 30 minutos sem uma operação no servidor ou após 8 horas. Digitar sem salvar não renova esse prazo.

Não há envio de senha por e-mail. Outro administrador pode redefinir uma senha temporária, encerrando as sessões e exigindo nova troca. Se todos os administradores perderem acesso, será necessária recuperação local assistida; executar setup-auth novamente não redefine contas existentes.

## Funcionalidades

- Login, troca de senha, administração de usuários, desativação e redefinição de acesso.
- Permissões no servidor: atendente não administra usuários nem vê a auditoria.
- Contatos fictícios `@example.com`, atendimentos, etapas, responsáveis e retornos.
- Histórico, prevenção de texto duplicado e autor nas novas observações.
- Filtros, indicadores, encerrados preservados e detecção de edição concorrente.
- **Abrir WhatsApp**: informe seu próprio número ou contato de teste autorizado, prepare o link e abra a conversa. Telefone não salvo no CRM; envio manual. WhatsApp recebe o número somente ao abrir o link. Nenhuma observação é transmitida.
- Auditoria de ações de acesso e criação/alteração de atendimentos. Não cobre todas as consultas ou edições de clientes.

Bia Demo/Rui Demo são rótulos de acompanhamento antigos, independentes das contas de login. Todos os usuários ativos veem os registros desta instalação; filtro por responsável não restringe acesso.

## Uso da clínica

Siga [GUIA-CLINICA.md](docs/GUIA-CLINICA.md). O fluxo ainda usa os nomes genéricos da demonstração anterior. Não registre diagnósticos, exames ou pacientes reais. Próximo retorno é data de acompanhamento, sem horário ou reserva de agenda.

Para cada cliente YSO, o desenho inicial é o mesmo código com instalação e banco separados. Esta instalação não oferece isolamento interno entre várias empresas. Trocar o nome da tela não separa dados.

## Operação

Código: `C:\Users\lucam\OneDrive\Documentos\YSO\crm-demo`.
PostgreSQL 18.6 em `%LOCALAPPDATA%\YSO\crm-demo`, fora do OneDrive. Banco `yso_crm_demo` em `127.0.0.1:5432`. Node.js v24.11.1, npm 11.6.2 e Git 2.52.0.windows.1 verificados na preparação. Dependência pg fixada no lockfile.

```powershell
npm.cmd start
npm.cmd test
npm.cmd run backup
```

Inicie o CRM antes dos testes para garantir que o PostgreSQL esteja ativo. Testes limpam somente `yso_crm_test`. Ctrl+C encerra o CRM; depois `npm.cmd run stop` encerra o banco.

`npm.cmd run setup-auth` aplica a migração e cria o administrador somente se não houver usuários; já executado aqui. Não apaga dados. Não copie credenciais, pgdata ou dumps para o repositório.

## Validação e limites

38 testes aprovados: autenticação, revogação de sessões, permissões, atendimento, histórico e link WhatsApp. Backup prévio e comparação após migração confirmaram preservação dos dados existentes.

O backup atualizado também foi restaurado e comparado nas nove tabelas, incluindo usuários e auditoria. Para repetir: sem operar o CRM, execute backup e depois `node scripts/verify-backup.mjs`. Uma nova base de restauração é preservada a cada execução; o backup permanece local e não protege contra perda do computador.

Demonstração local: sem hospedagem, acesso remoto das equipes ou sincronização de mensagens. Antes de um piloto real: validar fluxo, definir contas/responsáveis, preparar implantação, backup externo e revisão para uso real.

## Documentação

- [Guia da clínica](docs/GUIA-CLINICA.md).
- [Treinamento WhatsApp Business](docs/TREINAMENTO-WHATSAPP.md).
- [Plano e responsabilidades](PLANO.md).
- [Arquitetura](ARQUITETURA.md).
- [Fluxo original da oficina](FLUXO.md).
- [Resumo desta entrega](docs/ENTREGA-2026-10-27.md).

README anterior preservado em docs/README-oficina-2026-10-26.md.

## Financeiro — 29/10/2026
Cobranças por atendimento, parcelas mensais, pagamentos parciais, custos e despesas gerais, resultado de caixa e resultado parcial por atendimento. Atendentes registram cobranças e recebimentos; custos, despesas, resultados e estornos são restritos ao administrador na API. Uso e limitações: [FINANCEIRO.md](docs/FINANCEIRO.md).
