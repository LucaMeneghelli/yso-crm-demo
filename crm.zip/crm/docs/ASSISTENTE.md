# Assistente virtual da clínica

Primeira versão: simulador gratuito por regras, sem modelo de IA externo e sem WhatsApp conectado. Nenhum serviço pago foi contratado.

Abra Assistente virtual no menu e clique em Nova simulação. Digite uma mensagem como paciente fictício; revise a sugestão e clique em Aprovar no simulador. Assumir conversa pausa sugestões e permite registrar respostas da equipe. Reativar sugestões vale para próximas mensagens.

Horários fictícios: segunda a sexta 8h–18h, sábado 8h–12h, Brasília. Endereço fictício: Rua Exemplo, 100, Jardim Fictício, São Paulo/SP. Não usar para deslocamento. Serviços de treinamento: avaliação, limpeza e pedidos de agendamento. Nenhuma reserva é confirmada automaticamente.

Conversas persistem no PostgreSQL e ficam privadas por usuário autenticado, tanto administrador quanto atendente. Não alteram clientes, atendimentos ou financeiro. Controle de versão evita aprovação repetida ou desatualizada. Cada conversa tem limite de 200 registros; a lista exibe os últimos 30 treinamentos.

Perguntas clínicas, preços, reclamações e pedidos desconhecidos encaminham à equipe. Reconhecimento por palavras tem limites: este roteiro precisa ser validado antes de qualquer conexão real. Próxima fase: caixa de entrada compartilhada, integração oficial autorizada e avaliação dos custos antes de ativar.

Validação: testes locais de persistência, isolamento entre usuários, aprovação, conflito de versão, pausa e encaminhamento clínico.

Atualização: roteiro de agendamento coleta nome fictício, serviço (avaliação ou limpeza) e preferência de dia/período; permite revisar e reiniciar a coleta. O pedido confirmado pelo usuário fica aguardando a equipe, sem reservar agenda. O resumo aparece na conversa e persiste no banco. Respostas continuam sujeitas à aprovação no simulador. Tipografia utiliza fontes do sistema, sem serviços externos.

Melhoria de conversa: dúvidas sobre endereço e funcionamento mantêm a etapa; comandos corrigir nome, corrigir serviço e corrigir horário retomam o campo. Preferências precisam de dia e período. Domingo, noite e madrugada pedem outra preferência. Preços e pedidos de atendimento humano pausam a coleta para a equipe. Regras não verificam uma agenda real.
