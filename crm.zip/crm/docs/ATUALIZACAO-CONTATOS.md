# Atualização de contatos — 29/10/2026

## Entrega
- Telefone opcional persistido em customers.phone; formato internacional com país e DDD.
- Botão WhatsApp em Clientes e no atendimento; abre seletor com telefone preenchido e link para conversa. Nenhuma mensagem ou observação é enviada automaticamente. Número só é enviado ao WhatsApp quando a pessoa abre o link.
- Conversas avulsas continuam possíveis; telefone digitado na janela de conversa não altera o cadastro. Edite o cliente para salvar.
- Mostrar/Ocultar em login, troca e definição de senhas; ao limpar o formulário volta a ocultar.
- Identidade azul e turquesa YSO preservada, área de contato redesenhada e textos de demonstração removidos da interface.
- E-mails válidos deixam de ser restritos a example.com. Este CRM continua administrativo, sem prontuário clínico.
- Migração 003 adiciona telefone e adapta a restrição de e-mail sem apagar cadastros, notas ou acessos. Migração transacional e repetível.
- Novas instalações online não criam clientes fictícios automaticamente; SEED_DEMO_DATA=true só habilita exemplos de modo explícito.

## Validação
44 testes passaram em PostgreSQL local isolado: permissões, autenticação, persistência, repetição da migração, histórico e regras de atendimento. Revisão visual e sessão autenticada online pendentes devido a falha do controle do navegador.

## Uso
Clientes → Editar → preencher WhatsApp com país + DDD + número → Salvar. Depois clicar WhatsApp no cliente ou Conversar no WhatsApp dentro do atendimento. Conferir destinatário e abrir a conversa. A conversa ocorre no WhatsApp disponível no dispositivo; não existe caixa de entrada compartilhada dentro do CRM.

## Modelo para outros clientes
Mesmo código versionado; implantação, banco, credenciais e contas separados por empresa. Esta separação é a decisão arquitetural, não um provisionamento automático já implementado. Nome e identidade da clínica ainda precisam de parametrização para reutilização sem editar código.

## Limpeza e entrada em operação
Usuário pediu revisão dos fictícios antes de limpeza. Nenhum registro excluído nesta entrega. Nome contendo Demo ou e-mail example.com são apenas indícios, não autorização para excluir. Listar IDs e atendimentos associados, revisar notas inseridas pelo usuário, gerar backup privado e verificar restauração antes de uma exclusão específica. Backup do banco online e revisão dos registros ainda pendentes.
Antes de dados reais: concluir teste de atendente no ambiente online, revisar acesso das duas equipes e definir rotina de backup/restauração. Remover textos de demonstração não equivale a validação final de produção.
## Ajuste de usabilidade — 29/10/2026

WhatsApp salvo agora é um link direto na lista de clientes e dentro do atendimento: um clique abre o destino wa.me em nova aba, sem janela de preparação. O WhatsApp pode pedir login ou escolha do aplicativo. Sem telefone, a ação Cadastrar WhatsApp abre o cadastro do cliente. Nenhuma mensagem é enviada automaticamente.

Interface revisada: conteúdo principal de 15–16 px, botões com altura mínima de 44 px, formulários maiores, contraste aprimorado, menu ativo em turquesa, cartões com mais espaço e títulos diretos (Atendimentos e Clientes). Layout adapta menu e filtros para telas pequenas. Dados e permissões não foram alterados. Painel desktop inspecionado em navegador local com dados isolados de testes; revisão completa móvel pendente.
