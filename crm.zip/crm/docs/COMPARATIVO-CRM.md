# Comparativo de CRM e decisões YSO — 30/10/2026

Pesquisa documental em fontes oficiais públicas. Não houve acesso a implementações proprietárias, testes comparativos de desempenho nem cópia de interfaces. A coluna de aplicação é nossa decisão de produto, não uma afirmação de que determinada marca é objetivamente a melhor. Disponibilidade por plano varia; nenhuma licença foi contratada.

| Referência e fonte | Capacidade documentada escolhida | Aplicação YSO e ordem |
|---|---|---|
| [Pipedrive](https://www.pipedrive.com/en/features/activities-goals) | Atividades e destaque de negócios negligenciados | P1: próxima ação explícita; futuro alerta de inatividade depende de evento confiável |
| [HubSpot](https://knowledge.hubspot.com/records/filter-activities-on-a-record-timeline) | Timeline filtrável | P1: filtros por tipo e período no histórico já existente |
| [Dynamics 365](https://learn.microsoft.com/en-us/dynamics365/sales/sales-accelerator-intro) | Lista de trabalho com contexto do próximo contato | P1: Meu dia com razão da prioridade e ação sugerida |
| [Salesforce](https://help.salesforce.com/s/articleView?id=newforecasts_overview.htm&language=en_US&type=5) | Previsões agregadas e acompanhamento | P3: oportunidades, probabilidade e previsão explicável; sem confundir com caixa |
| [Zoho](https://www.zoho.com/crm/process-management/blueprint.html) | Processo visual com regras | P2: etapas configuráveis com exigências no servidor |
| [Freshsales](https://crmsupport.freshworks.com/support/solutions/articles/50000002580-what-is-predictive-contact-scoring-how-does-it-work-) | Pontuação de contatos | P3: score por eventos e pesos visíveis; sem inventar abertura de mensagem |
| [monday](https://support.monday.com/hc/en-us/articles/360001222900-Get-started-with-monday-automations) | Automação de tarefas repetitivas | P2: gatilho, condição, ação, histórico e prevenção de duplicidade |
| [Creatio](https://academy.creatio.com/guides/creatio-apps/overview/sales-creatio-overview) | Processos configuráveis e módulos componíveis | P2: separar módulos e configuração de regras; editor visual depois |
| [Close](https://help.close.com/feature-guide/inbox) | Comunicações e tarefas numa inbox | P2: caixa compartilhada com responsável; canais reais dependem de integração |
| [Attio](https://attio.com/platform/data) | Modelo de dados flexível | P2: separar contatos, empresas, negócios e campos definidos; evitar estrutura genérica prematura |
| [Odoo](https://www.odoo.com/documentation/18.0/applications/sales/crm/acquire_leads/send_quotes.html) | Propostas relacionadas às oportunidades | P2: catálogo e proposta versionada; aprovação antes da cobrança |
| [Oracle](https://www.oracle.com/cx/sales/) | Orientação comercial e continuidade entre venda e operação | P2/P3: próximo passo e rastreabilidade proposta → cobrança → pagamento |
| [SAP](https://www.sap.com/products/crm/sales-cloud.html) | Venda guiada e previsão | P3: orientação por etapa e indicadores com origem explicada |
| [SugarCRM](https://www.sugarcrm.com/platform-features/intelligence/) | Insights e recomendações de forecast | P3: destacar riscos com evidência; IA preditiva somente após dados e validação |
| [NetSuite](https://www.netsuite.com/portal/products/crm/sales-force-automation.shtml) | Oportunidade, proposta, pedido e forecast conectados | P3: preservar vínculo comercial-financeiro, sem construir ERP inteiro agora |

## Sequência decidida
P1: tornar ações e histórico claros; concluir revisão visual e testes online.
P2: atividades persistentes por usuário; leads/oportunidades; propostas; automações internas; inbox de treinamento compartilhada.
P3: relatórios e forecast baseados em eventos; configuração por empresa; isolamento multiempresa com testes negativos.

Critérios: preservar dados, endpoints autenticados, custos privados, transações e auditoria; tarefas essenciais em até três ações quando possível; layout legível em celular; métricas com fórmula documentada. Medir latência e uso real antes de afirmar superioridade. Mensagens externas e custos dependem de autorização específica.

## Implementado nesta entrega
Cartões de Meu dia e Quadro exibem razão da prioridade (atrasado, hoje, futuro, sem retorno ou encerrado) e próxima ação administrativa por etapa. Texto identificado como regra, sem falsa alegação de IA. Nenhum envio automático ou alteração de registros. Dois testes de visão/prioridade aprovados.

## Limitações da comparação
Documentação dos fornecedores descreve capacidades, não comprova qualidade relativa ou experiência prática. Não foram feitos trials pagos, benchmarks de velocidade, auditorias dos concorrentes ou testes em suas contas. Não declaramos que a YSO já supera essas plataformas.
