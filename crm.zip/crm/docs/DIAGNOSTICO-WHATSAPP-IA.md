# Diagnóstico: atendimento por IA no WhatsApp

Pesquisa preliminar em 29/10/2026. Nenhuma integração ativada, credencial criada, mensagem enviada ou serviço contratado.

## Decisão proposta
É tecnicamente viável. Usar WhatsApp Business Platform / Cloud API oficial, integrada ao servidor do CRM. Não depender de uma aba aberta nem automatizar cliques no WhatsApp Web. O CRM será o painel de supervisão; o agente será um componente do servidor.

Fluxo proposto: mensagem recebida → webhook validado → fila persistente → identificação da empresa/contato → regras e base aprovada → resposta sugerida ou envio autorizado → histórico no CRM. O provedor de IA não substitui a API do WhatsApp; ambos são componentes distintos.

## Primeira versão recomendada
Começar em modo assistido: IA sugere e recepcionista aprova. Depois permitir respostas automáticas somente para informações administrativas aprovadas: horários, endereço, serviços e coleta de preferência de agendamento. Não confirmar horários sem uma agenda integrada que garanta disponibilidade. Encaminhar sintomas, urgências, dúvidas clínicas, reclamações e casos incertos para equipe humana; não diagnosticar nem definir tratamentos.

Controles necessários: validar assinatura de webhooks, deduplicar IDs de mensagem, limitar tentativas e gasto, garantir que humano assumindo pause a IA, permitir desligamento por empresa e manter auditoria. Não dar à IA acesso livre a SQL, custos, lucro, senhas ou dados de outros clientes. Mensagens recebidas são dados não confiáveis, não instruções de sistema.

## Dependências e custos
Necessários: conta empresarial Meta e número autorizado do cliente; definir elegibilidade do número atual e eventual coexistência antes de qualquer migração; credenciais oficiais; provedor de IA; infraestrutura que processe webhooks de modo confiável. A hospedagem gratuita atual pode suspender por inatividade e não deve ser prometida como atendimento imediato 24h.

Não prometer gratuidade de produção. Há custos potenciais de mensagens, IA e infraestrutura. Valores exatos, país, categoria e regras vigentes precisam ser confirmados na conta antes de ativar. Resultados de pesquisa apresentaram divergência entre páginas sobre preços recentes; nenhum preço foi adotado neste diagnóstico.

## Próximas etapas
1. Simulador local com mensagens fictícias e base da clínica revisada, sem envio externo.
2. Inbox no CRM, atribuição de conversa e transferência humana.
3. Teste com número de teste oficial, após acesso autorizado à conta Meta.
4. Revisar políticas atuais e custos, estabelecer limites aprovados, testar falhas e então habilitar piloto supervisionado.

## Fontes primárias consultadas
- Meta / WhatsApp Developer Hub: https://whatsappbusiness.com/developers/developer-hub/
- Coleção oficial Meta Cloud API: https://www.postman.com/meta/whatsapp-business-platform/documentation/wlk6lh4/whatsapp-cloud-api
- Preços: https://whatsappbusiness.com/products/platform-pricing/
- Termos: https://www.whatsapp.com/legal/business-solution-terms

A recomendação arquitetural é uma avaliação para este CRM. Políticas de IA possuem restrições e exceções; não tratar viabilidade técnica como aprovação automática da conta ou do caso de uso pela Meta.
