# Evolução do produto YSO — 30/10/2026

## Diagnóstico inicial (não é auditoria de segurança exaustiva)
Stack preservado: Node.js 24+, servidor HTTP nativo, pg, PostgreSQL, módulos JavaScript e CSS próprios. Deploy existente Render/Supabase. Nenhuma nova dependência ou despesa.

Existentes: clientes, telefone, atendimentos com transições e controle de versão, notas, retorno, login, administrador/atendente, auditoria parcial, cobranças, parcelas, pagamentos parciais, despesas privadas do administrador e estornos. Assistente por regras com coleta de pedido, histórico por usuário e tomada humana. WhatsApp manual por link; Meta suspensa por verificação de telefone.

Lacunas verificadas:
- Não existe tenant/empresa nas tabelas: manter instalações separadas até projetar e testar isolamento completo.
- Responsáveis (owners) ainda não são usuários (app_users).
- /api/state e financeiro carregam listas completas; precisam de paginação e filtros SQL antes de escala.
- Auditoria não inclui alterações de clientes ou ações do simulador.
- Simulador usa JSON de mensagens, sem caixa compartilhada, fila, integração ou agenda real.
- Correção de nome no assistente repete serviço e preferência; evoluir para editar apenas o campo solicitado.
- Verificação de restauração compara somente tabelas antigas; incluir financeiro e assistente.
- Documentação histórica de arquitetura ainda descreve execução exclusivamente local; preservar como histórico e atualizar referência atual.
- Sem leads, empresas, oportunidades comerciais próprias, produtos, tarefas com hora, contratos, recorrência, scoring ou forecast. Não apresentar métricas inexistentes como se fossem reais.

## Entregas e critérios
1. Base confiável: testes reproduzíveis sem fixtures de outros testes; auditoria de clientes e simulador; restauração abrangente. Critério: testes negativos de acesso e backup restaurado comparável.
2. Meu dia e pipeline operacional: retornos de hoje/atrasados, quadro das etapas existentes, filtros e navegação acessível. Não permitir arrastar para contornar transições ou notas obrigatórias.
3. Clientes 360 e atividades: timeline das fontes existentes com filtragem por permissão; tarefas com data/hora/responsável e conclusão auditada.
4. Comercial: leads, origens, empresas e oportunidades separados de atendimentos; conversão transacional, etapas configuráveis, motivo de perda e produtos/propostas.
5. Relatórios: definir fórmulas e eventos antes de conversão, metas e forecast; MRR/ARR só após contratos recorrentes implementados.
6. Conversas: caixa compartilhada, atribuição, respostas rápidas, fila durável, idempotência e transferência humana. Integração oficial depende de acesso Meta e verificação de custos, sem contratação automática.
7. SaaS: organizações, associação de usuários, escopos em todas as consultas e chaves, migração ensaiada e testes cruzados entre duas empresas. Só depois habilitar múltiplos clientes na mesma implantação.

Cada entrega: migração aditiva quando necessária, testes locais, revisão visual, publicação e confirmação. Não substituir stack nem fabricar integrações. Benchmark de referências comerciais será uma pesquisa separada em fontes públicas; não realizado nesta análise inicial.

Equipe: Luca e Japonês desenvolvimento; João comercial; Enzo conteúdo. Meta adiada. Custos adicionais autorizados: R$ 0.

Entrega 1: Meu dia agrupa retornos atrasados, de hoje e futuros; quadro organiza atendimentos pelas etapas existentes. Busca por cliente/serviço e filtro por responsável. Cartões abrem o formulário existente, preservando controle de versão e justificativas. Ainda sem arrastar cartões, tarefas independentes ou pipeline comercial configurável. Corrigida dependência de fixtures no teste do assistente.

Entrega 2: Visão do cliente com cadastro, acesso aos atendimentos e timeline dos últimos 200 eventos (abertura, observações, cobranças e pagamentos, incluindo indicação de estorno). Consulta consistente em transação; não consulta custos/despesas. API exige autenticação e troca inicial de senha. 51 testes aprovados, incluindo acesso anônimo, cliente inexistente e ausência de despesas privadas na resposta ao atendente. Ainda não inclui canais externos, tarefas ou eventos históricos de mudança de etapa que nunca foram registrados.

Entrega 4: atividades por cliente com tipo, usuário responsável, data/hora de Brasília, conclusão pelo responsável/admin e auditoria. Lista compartilhada limitada a 500; sem edição, recorrência ou lembretes externos nesta etapa. Histórico filtra tipo e intervalo inclusivo pela data de registro em Brasília no servidor, antes do limite de 200. Criação/conclusão de atividades integra a timeline. Testes de autenticação, conclusão negada, filtros inválidos e eventos aprovados.
