# Financeiro — YSO CRM

Implementado em 29/10/2026. Módulo administrativo reutilizável para clínicas, oficinas e outros serviços; moeda BRL. Não integra bancos, cartões, emissão fiscal ou WhatsApp e não movimenta dinheiro.

## Como usar
1. Abra Financeiro e escolha o período.
2. Nova cobrança: selecione o atendimento, informe valor total, emissão, número de parcelas (1–36) e primeiro vencimento.
3. As parcelas são mensais, sem juros; centavos restantes são distribuídos nas primeiras parcelas. Em meses menores, o vencimento usa o último dia válido.
4. Em Parcelas e recebimentos, clique Receber e informe somente o valor pago agora, data e forma. Aceita recebimento parcial e antecipado; amplie o período para localizar parcelas futuras.
5. Administrador: Custo ou despesa permite associar materiais, peças ou taxas ao atendimento, ou registrar aluguel, salários e demais despesas gerais. Registre cada gasto uma única vez.
6. Para corrigir pagamentos ou despesas, administrador usa Estornar, informa o motivo e registra o lançamento correto. O estorno é contábil dentro do CRM, não um reembolso bancário.

## Significado dos indicadores
- Cobrado e valor médio: cobranças cuja data de emissão pertence ao período.
- Recebido: pagamentos efetivos, não estornados, pela data informada do recebimento.
- A receber: saldo atual das parcelas com vencimento no período. Não inclui parcelas fora do filtro. Pagamentos posteriores também reduzem esse saldo; não é uma reconstrução histórica.
- Em atraso: parte desse saldo cujo vencimento é anterior a hoje.
- Custos diretos e despesas gerais: lançamentos pagos dentro do período, sem estornos.
- Resultado de caixa: recebido menos custos e despesas pagos dentro do período. Não representa lucro contábil nem considera obrigações não cadastradas.
- Resultado por atendimento: valor cobrado menos custos diretos pagos já lançados para aquele atendimento, em qualquer data; exclui despesas gerais. Pode conter receita ainda não recebida. A lista usa a emissão da cobrança para o filtro.

## Permissões
Atendente cria cobranças, vê valores cobrados e parcelas e registra pagamentos. Administrador também registra e consulta despesas e custos, resultados e estornos. Dados restritos não são incluídos na resposta da API para atendentes. Todos precisam de sessão válida e troca inicial de senha concluída.

## Integridade
Migração 004 cria quatro tabelas no esquema privado já usado pelo CRM. Nenhum dado anterior é apagado. Valores são centavos inteiros. Cobrança única por atendimento; pagamentos travam a parcela em transação e não podem superar o saldo. Reenvio do mesmo formulário usa chave de idempotência. Lançamentos ficam na auditoria.

## Limites da primeira versão
Uma cobrança por atendimento, sem alteração posterior do valor ou cronograma. Conferir antes de salvar. Estornos disponíveis para pagamentos e despesas. Parcelamento mensal sem juros, sem pagamentos recorrentes automáticos. Não há contas a pagar futuras, conciliação bancária nem emissão fiscal. Custos e despesas são registros de valores já pagos. Não confundir conclusão do atendimento com pagamento recebido; são estados independentes.

## Verificação
46 testes da aplicação passaram em PostgreSQL local isolado. Testes financeiros cobrem arredondamento, fim de mês, persistência, autorização, idempotência, pagamento parcial, concorrência contra pagamento excedente, filtros e estornos. Teste adicional após a inclusão do resultado por atendimento passou, confirmando ausência desses dados para atendentes. Tela e formulário de cobrança revisados no navegador local. Testes autenticados completos online e revisão móvel ainda pendentes.
