# Guia de uso — Dr. Alexandre Fuzimoto

Esta versão organiza solicitações administrativas. Não substitui prontuário ou agenda. Somente dados fictícios no CRM.

## Primeiro acesso e equipe

Entre conforme o README e troque a senha temporária. Em Acessos da equipe, o administrador cria uma conta individual por pessoa. Atendentes podem cadastrar, editar e acompanhar registros; apenas administradores gerenciam usuários e consultam as últimas ações. Não há restrição de visualização por responsável nesta versão.

Responsável pelo atendimento e autor da observação são diferentes: o primeiro indica quem acompanha; o segundo vem automaticamente de quem está conectado. Notas antigas sem autor permanecem sem atribuição, pois não há evidência de quem as escreveu.

## Simulação completa

1. Cadastre **Ana Recepção Demo**, contato `ana.recepcao@example.com`.
2. Abra **Solicitação de agendamento — simulação**. Escolha um responsável demonstrativo e retorno de hoje. Nota: “Solicitação administrativa recebida. Aguardando preferência de horário.”
3. Passe para **Em avaliação**. Aqui significa avaliar o pedido e disponibilidade administrativa. Nota: “Recepção verificará opções de horário na agenda de demonstração.”
4. Passe para **Aguardando aprovação**. Nota: “Opção fictícia de horário apresentada. Aguardando confirmação do contato de teste.” Não invente disponibilidade real da clínica.
5. Simule a confirmação e passe para **Em execução**. Nota: “Contato de teste confirmou a opção. Recepção fará a conferência administrativa.”
6. Passe para **Concluído**. Nota: “Solicitação administrativa finalizada na simulação. Confirmação conferida pela recepção.” Isso conclui o pedido, não declara tratamento odontológico realizado.
7. Reabra para conferir histórico e autores. Encerrado é só leitura; nova demanda requer outro atendimento.

As etapas ainda são as do fluxo genérico. Adaptação proposta, a validar: Novo contato → Verificando disponibilidade → Aguardando confirmação → Agendamento confirmado → Solicitação encerrada. Casos antigos não foram renomeados retroativamente.

## Botão WhatsApp

1. No menu, selecione **Abrir WhatsApp**.
2. Digite seu próprio número ou contato de teste autorizado, com código do país e DDD.
3. Clique em **Preparar link**, confira e escolha **Abrir conversa no WhatsApp**.
4. O WhatsApp pode pedir login. Confira o destinatário e escreva manualmente.
5. Registre o resultado administrativo e próximo retorno no CRM. Abrir o link não comprova envio, entrega, leitura ou resposta.

O telefone é temporário: não vai ao banco e é limpo ao fechar a janela. Nenhum texto do atendimento entra no link. Ao abrir, o número é transmitido ao WhatsApp. Não use números inventados para testar.

## Rotina compartilhada

No início do turno, filtre retornos atrasados e de hoje. Defina quem responde antes de usar WhatsApp. Na transferência, registre “Recepção assume próximo contato; retorno previsto em [data]” e atualize o responsável. Quem recebe confirma antes de responder. Não conclua apenas porque enviou uma mensagem.

As duas equipes ainda não podem acessar este computador remotamente: 127.0.0.1 funciona só na máquina local. Colaboração remota depende de implantação futura.
