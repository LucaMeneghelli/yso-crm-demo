# Publicação gratuita para a escola

Estado em 28/10/2026: código preparado, 43 testes locais aprovados na preparação. Repositório privado `LucaMeneghelli/yso-crm-demo` criado e disponível no Render. Ainda não há publicação online validada nem credenciais online ativas.

## Recursos definidos

- Supabase: projeto `yso-crm-escola`, referência `ashvuxcqglhlnrbwyjib`, região Ohio (`us-east-2`), criado e Healthy.
- Render: conta de Luca. Criar um novo Web Service **Free**, sem alterar os serviços existentes.
- Código: deve ficar em um repositório da própria conta de Luca. O GitHub `jpruubio` conectado ao Render pertence a outra pessoa e não será usado para guardar o CRM.
- Formulário do Render preparado com Node, região Ohio e plano Free (US$ 0/mês). Falta concluir variáveis privadas e verificar a publicação.
- Serviço criado: `srv-dbgvo8942hec73e48ukg`, endereço reservado `https://yso-crm-escola.onrender.com`. Primeiro build aprovado; início falhou com `SELF_SIGNED_CERT_IN_CHAIN`. Em 28/10, adicionado `DATABASE_CA_CERT` com o certificado público oficial indicado no painel Supabase e solicitado novo deploy. Aguardando validação online.
- Local e online usam bancos e contas separados. Só exemplos fictícios na demonstração.

## Configuração do Render

Usar `render.yaml` ou configurar: Node, build `npm ci --omit=dev`, start `npm run start:cloud`, healthcheck `/healthz`, plano Free. Escolher uma região disponível próxima do banco em Ohio. Não adicionar discos, domínio pago, IPv4 pago ou outros recursos pagos.

Variáveis privadas:

- `DATABASE_URL`: conexão Session pooler obtida no painel Supabase, incluindo a senha do banco. Não usar chave anon/publishable.
- `DEMO_ADMIN_PASSWORD` e `DEMO_ATTENDANT_PASSWORD`: senhas temporárias diferentes, aleatórias, de 12 a 128 caracteres. Usadas somente para criar as contas no primeiro início.
- `NODE_VERSION`: `24.11.1`.
- `NODE_ENV`: `production`.
- `RENDER_EXTERNAL_URL`: fornecida pelo Render. Se necessário, configurar `PUBLIC_ORIGIN` com a origem HTTPS exata, sem caminho.
- `DATABASE_CA_CERT`: certificado oficial do banco se exigido para validar TLS. Nunca desativar a validação do certificado.

Neste projeto, `DATABASE_CA_CERT` é necessário. Fonte: botão Download certificate em Database Settings do Supabase, `https://supabase-downloads.s3-ap-southeast-1.amazonaws.com/prod/ssl/prod-ca-2021.crt`. Certificado Supabase Root 2021 CA, válido até 26/04/2031; SHA-256 `80:70:25:AD:50:D4:ED:21:9D:2C:9C:7D:29:9C:00:4F:82:4E:B0:0C:F7:F6:5A:FE:F6:07:D0:7B:72:E6:CA:FA`. Colar o PEM completo na variável, mantendo as linhas BEGIN/END. Não usar `NODE_TLS_REJECT_UNAUTHORIZED=0` ou `rejectUnauthorized:false`.

Conexão confirmada no painel, sem senha:

```text
postgresql://postgres.ashvuxcqglhlnrbwyjib:[YOUR-PASSWORD]@aws-0-us-east-2.pooler.supabase.com:5432/postgres
```

Substituir o marcador apenas no painel privado. Caracteres especiais da senha precisam de codificação na URL. Não salvar a conexão completa no repositório, documentação ou mensagens públicas.

## Contas da demonstração

Após a primeira inicialização bem-sucedida, serão criadas `admin@yso.local` e `atendente@yso.local`. Não há senha padrão no código. As senhas vêm das variáveis privadas e exigem troca no primeiro acesso. Novas publicações preservam senhas e registros existentes.

Depois de confirmar a criação, remover as variáveis das senhas iniciais. Manter a conexão do banco no painel privado.

## Validação antes de entregar

Conferir URL HTTPS, login dos dois perfis, bloqueio administrativo do atendente, criação e consulta de atendimento fictício e persistência após reinício. Só anunciar credenciais ativas depois dessas verificações. Os testes locais não confirmam funcionamento na hospedagem.

## Limites dos planos gratuitos

Render Free pode suspender após 15 minutos sem tráfego; o próximo acesso pode levar cerca de um minuto para abrir. Supabase Free pode pausar por inatividade. As cotas são compartilhadas na conta; confirmar disponibilidade antes de criar recursos. Não habilitar cobrança ou upgrade.

O servidor Render tem armazenamento temporário; os registros ficam no PostgreSQL. O esquema privado `yso_crm` não deve ser exposto pela Data API. A API pública do Supabase foi desativada neste projeto; o servidor conecta diretamente pelo pooler.

O endereço da escola depende das regras da rede escolar. Não contornar bloqueios. WhatsApp continua como atalho manual, sem sincronização ou envio automático.

Referências oficiais consultadas:

- https://render.com/docs/free
- https://render.com/docs/blueprint-spec
- https://supabase.com/docs/guides/database/connecting-to-postgres
- https://supabase.com/docs/guides/platform/regions
