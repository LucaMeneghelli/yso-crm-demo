# Plano do demonstrativo de CRM — YSO

## Objetivo e limites

Demonstrar o acompanhamento de atendimentos de uma oficina fictícia, desde o cadastro do cliente até o retorno previsto. Usar somente dados fictícios, em ambiente local, sem integração real com WhatsApp, sem serviços pagos e sem publicação na internet.

## Equipe

| Pessoas | Responsabilidade |
| --- | --- |
| Luca e Japonês | Desenvolver juntos, definindo o fluxo e construindo o demonstrativo. |
| João | Cuidar do comercial e da apresentação do valor da solução. |
| Enzo | Cuidar do conteúdo e dos textos da demonstração. |

## 1. Ambiente — concluído nesta primeira etapa

- [x] Confirmar a pasta `C:\Users\lucam\OneDrive\Documentos\YSO\crm-demo`.
- [x] Inspecionar o conteúdo, incluindo arquivos ocultos: pasta inicialmente vazia.
- [x] Verificar Git: `2.52.0.windows.1`.
- [x] Verificar Node.js: `v24.11.1`.
- [x] Verificar npm: `11.6.2`.
- [x] Criar README.md e PLANO.md.
- [x] Registrar escopo, limites e responsabilidades.

Verificação realizada em 26/10/2026. Nenhuma ferramenta de sistema foi instalada; nenhuma dependência foi adicionada e nenhum repositório Git foi inicializado. Não há implementação do CRM nesta etapa.

Critério de conclusão: ambiente identificado e documentação disponível para orientar o trabalho conjunto.

## 2. Fluxo — definido em documentação

- [x] Descrever a jornada do atendimento da oficina fictícia.
- [x] Definir as etapas: Novo atendimento → Em avaliação → Aguardando aprovação → Em execução → Concluído; Cancelado como saída das etapas ativas.
- [x] Definir os campos: cadastro do cliente, serviço solicitado, etapa do atendimento, responsável, observações e data do próximo retorno.
- [x] Definir obrigatoriedade, retornos vencidos e encerramento.
- [x] Preparar exemplos inteiramente fictícios, com contatos claramente identificados como de demonstração.
- [x] Descrever as telas em um esboço textual e preparar o roteiro mínimo de uso.

Especificação registrada em [FLUXO.md](FLUXO.md), em 26/10/2026. O esboço é documental; não há telas implementadas. As regras estão definidas para orientar a equipe, sem presumir uma revisão já realizada por seus integrantes.

Critério de conclusão: Luca e Japonês terem um fluxo definido para implementar, com contribuição de João no cenário comercial e de Enzo nos textos.

## 3. Primeira versão implementada

- [x] PostgreSQL 18.6 instalado de forma isolada, fora do OneDrive.
- [x] Usuário da aplicação, banco demonstrativo e banco de testes preparados.
- [x] Dependência pg instalada e registrada no lockfile.
- [x] Migração SQL, validações e transações implementadas.
- [x] Cadastro e edição de clientes e atendimentos.
- [x] Etapas, responsável, observações e retorno.
- [x] Busca, filtros e indicadores de acompanhamento.
- [x] Exemplos fictícios, logo e paleta YSO.
- [x] Iniciar CRM.cmd e instruções de operação no README.
- [x] Backup e restauração em base separada verificados.
- [ ] Inicializar histórico Git quando for organizar a colaboração entre os desenvolvedores.

## 4. Testes — primeira versão validada

- [x] 23 testes automatizados de regras e API com PostgreSQL real.
- [x] Campos obrigatórios, datas, contatos fictícios e duplicados.
- [x] Transições, notas obrigatórias e bloqueio de atendimentos encerrados.
- [x] Falha de gravação preserva registros e notas; concorrência detectada por versão.
- [x] Persistência após reinício do backend e nova conexão ao banco.
- [x] Backup restaurado e comparado em base separada.
- [x] Cadastro de cliente e atendimento pela interface e jornada até conclusão.
- [x] Filtro de retornos atrasados verificado no navegador.

## 5. Demonstração — etapa futura

- [ ] João preparar a apresentação comercial do problema e do benefício para a oficina.
- [ ] Enzo preparar os textos e o conteúdo do cenário fictício.
- [ ] Luca e Japonês preparar e conduzir a execução técnica local.
- [ ] Demonstrar cadastro, serviço solicitado, mudança de etapa, responsável, observações e agendamento do próximo retorno.
- [ ] Coletar feedback e registrar melhorias para uma próxima etapa.

Critério de conclusão: apresentação local realizada com um atendimento fictício completo, deixando claro o escopo demonstrativo.


Prioridade atual: usar e ajustar o CRM local. Site institucional e treinamento de WhatsApp Business ficam para depois, conforme orientação de Luca.


