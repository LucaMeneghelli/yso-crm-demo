# YSO CRM — Oficina Horizonte Demo

Primeira versão funcional local, com identidade azul-marinho e turquesa da Yourself Organization. Exclusivamente para dados fictícios; sem WhatsApp real, serviços pagos ou publicação.

## Abrir agora

1. Na pasta do projeto, dê dois cliques em **Iniciar CRM.cmd**.
2. Aguarde aparecer `Local: http://127.0.0.1:3000`.
3. Abra esse endereço no navegador. Mantenha o terminal aberto durante o uso.

Se o CRM já estiver iniciado, basta abrir o endereço. Não execute várias instâncias. Para encerrar o backend, pressione Ctrl+C no terminal. Para parar também o banco, execute `npm.cmd run stop` após encerrar o backend.

Alternativa no PowerShell, dentro desta pasta:

```powershell
npm.cmd start
```

O comando inicia automaticamente o PostgreSQL isolado, caso ele esteja parado. Não é necessário Supabase, Render, pgAdmin ou conexão à internet para operar esta instalação.

## O que funciona

- Cadastro e edição de clientes com contato fictício `@example.com`.
- Reutilização de clientes, com vários atendimentos independentes.
- Cadastro e edição de serviço, responsável e próximo retorno.
- Jornada: Novo atendimento → Em avaliação → Aguardando aprovação → Em execução → Concluído.
- Revisão da proposta e cancelamento com justificativa.
- Histórico de observações, sem substituir notas anteriores.
- Filtros por etapa, responsável e situação do retorno, além da busca textual.
- Destaques para hoje e atrasados; encerrados ficam somente para consulta.
- Dados persistentes no PostgreSQL e backup local.

## Roteiro rápido

1. Em Clientes, cadastre um nome fictício e um contato como `teste.demo@example.com`.
2. Em Atendimentos, clique em Novo atendimento, selecione o cliente, descreva o serviço, escolha Bia Demo ou Rui Demo e a data do próximo retorno.
3. Clique em Abrir para editar ou avançar a etapa. Registre uma nova observação nas decisões de proposta, aprovação e encerramento.
4. Ao concluir, o próximo retorno é removido e o histórico permanece consultável.

Os casos iniciais são Marina, Pedro e Carla. Alex Cliente Demo foi cadastrado pela interface e tem um atendimento concluído, utilizado para conferir a jornada completa. Os exemplos não são apagados nem recriados ao reiniciar.

## Instalação neste computador

| Componente | Versão |
| --- | --- |
| Node.js | v24.11.1 |
| npm | 11.6.2 |
| PostgreSQL | 18.6 |
| pg (node-postgres) | 8.23.1, registrada no package-lock.json |
| Git disponível | 2.52.0.windows.1 |

Código: `C:\Users\lucam\OneDrive\Documentos\YSO\crm-demo`.

Instalação isolada do PostgreSQL: `%LOCALAPPDATA%\YSO\crm-demo\runtime\pgsql`.
Dados: `%LOCALAPPDATA%\YSO\crm-demo\pgdata`.
Banco: `yso_crm_demo`, em `127.0.0.1:5432`.

O banco foi instalado pelos binários oficiais EDB, sem serviço automático do Windows. As credenciais geradas ficam em `app.json` e `admin.json` na pasta local acima, com acesso restrito ao usuário e SYSTEM. Não compartilhar esses arquivos ou colocá-los no Git. O app usa um usuário sem privilégios de superusuário.

## Testes e backup

```powershell
npm.cmd test
npm.cmd run backup
```

Os testes usam somente `yso_crm_test` e limpam seus próprios registros. Nunca apontá-los para dados reais. São 23 testes aprovados, incluindo regras, API e integração com PostgreSQL. Cadastro de cliente, criação de atendimento, jornada até conclusão e filtro de atrasados também foram verificados no navegador. Dados permaneceram após reiniciar o backend.

Backups são gravados em `%LOCALAPPDATA%\YSO\crm-demo\backups`, no formato do pg_dump. Uma restauração foi comparada registro a registro e validada em `yso_crm_restore_test`, preservada para consulta. `scripts/verify-backup.mjs` só cria essa base quando ela não existe: não sobrescreve uma restauração anterior. Restaurar a base de uso requer uma operação deliberada; não há botão de apagar ou redefinir dados.

## Limites atuais

Uso local por um operador, sem login, acesso de outras máquinas, integrações ou envio de mensagens. Site institucional e treinamento de WhatsApp Business são trabalhos posteriores. Este demonstrativo ainda não é uma implantação para dados reais de clientes.

## Documentação

- [FLUXO.md](FLUXO.md): regras da oficina fictícia.
- [ARQUITETURA.md](ARQUITETURA.md): organização técnica e armazenamento.
- [PLANO.md](PLANO.md): progresso e responsabilidades.

