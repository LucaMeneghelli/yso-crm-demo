# Referência funcional Salesforce — 30/10/2026

## Escopo e preservação
Inspeção legítima da interface da conta fornecida. Nenhum código, asset ou dado de cliente foi extraído. Nenhuma compra ou contratação. Referência de recuperação versionada: codex/backup-pre-salesforce-20261030. Arquivos não versionados existentes preservados; essa referência não é backup do banco online.

A base continua Node, JavaScript, PostgreSQL, Supabase e Render. Uma instalação por empresa; não anunciar isolamento multiempresa nesta versão. Clínica mantém seu nome e seus registros.

## Observado diretamente
- Navegação de Vendas separa Leads, Contatos, Contas, Oportunidades, Produtos, Catálogos, Calendário e Análises.
- Lista de leads possui busca, modo de exibição, filtros, atualização e estado vazio explicativo.
- Formulário separa identificação, contato e segmentação; inclui situação, empresa, responsável, origem e descrição.
- A conta exibe avaliação Starter com prazo; não é dependência do CRM YSO e não foi contratada.

## Comparação e sequência
| Área | Situação no YSO | Decisão |
|---|---|---|
| Leads | Ausente antes desta etapa | Cadastro e edição com responsável, situação, origem e busca |
| Contatos | Clientes já disponíveis | Preservar cadastro e histórico |
| Empresas | Apenas descrição no lead nesta etapa | Cadastro próprio e vínculo com contatos ainda pendentes |
| Oportunidades | Pipeline atual é de atendimento | Criar pipeline comercial separado em etapa posterior |
| Atividades | Cadastro/conclusão existentes | Adicionadas busca, situação e minhas atividades |
| Histórico | Filtros existentes | Corrigir referência a atendimento nulo nas atividades |
| Dashboards | Indicadores operacionais/financeiros | Evoluir após modelo comercial |
| Relatórios e automações | Parciais/ausentes | Etapas futuras; sem envio automático nem custo |

## Entrega incremental
Novo módulo Leads: listagem até 500 registros, cartões, busca, filtro, criação e edição; validação no servidor, auditoria e versão contra sobrescrita concorrente. E-mail obrigatório nesta primeira versão, telefone opcional. Qualificar ainda não converte em cliente nem gera oportunidade. Ambos os perfis operam leads, mantendo custos/lucro restritos no Financeiro.

A inspeção aprofundada das outras telas do Salesforce e os módulos restantes ainda não estão concluídos. Não declarar equivalência funcional completa ou produto SaaS multiempresa pronto.
