# Treinamento WhatsApp Business — clínica + YSO

Preparado em 27/10/2026 para Dr. Alexandre Fuzimoto. Duração sugerida: 45 minutos. Material pronto para prática; nenhuma conta do WhatsApp foi configurada e nenhuma mensagem enviada nesta implementação.

## Objetivo

Atender com clareza, evitar respostas simultâneas e dar a toda pendência um responsável e retorno. WhatsApp é o canal da conversa; CRM registra o acompanhamento administrativo.

## Preparação — 10 minutos

- A clínica confirma o responsável pelo número e autoriza pessoas/dispositivos. Contas do CRM devem ser individuais.
- Revisar nome, descrição, horário e endereço com a clínica; não inventar informações.
- Apresentar saudação, ausência e respostas rápidas do WhatsApp Business. Telas e disponibilidade variam conforme versão/conta: configurar durante a prática, com o responsável presente.
- Definir turnos e transferências. Duas equipes com acesso não significa duas pessoas respondendo juntas.

## Organização — 10 minutos

Combinar etiquetas: Novo contato, Aguardando resposta, Confirmar horário, Retorno pendente e Resolvido. O botão do CRM não sincroniza etiquetas.

Antes de responder, conferir mensagens e responsável. Ao assumir, identificar-se. Depois, registrar somente resumo administrativo no CRM. Não copiar conversas completas, fotos, documentos ou informações de saúde para este demonstrativo.

## Respostas rápidas para revisar — 10 minutos

Substituir campos antes do envio. Cadastrar manualmente durante o treinamento.

| Atalho sugerido | Texto |
| --- | --- |
| /ola | Olá! Sou [nome], da equipe de atendimento do Dr. Alexandre Fuzimoto. Como posso ajudar com seu agendamento? |
| /horario | Qual período seria melhor para você? Vou verificar as opções disponíveis com a recepção. |
| /confirmar | Podemos confirmar a opção de [data] às [hora]? Aguardo sua resposta antes de concluir a confirmação. |
| /remarcar | Vamos verificar uma nova opção. Qual período você prefere? |
| /transferir | Vou encaminhar sua solicitação para [nome/equipe], que continuará o atendimento. |
| /retorno | Olá! Retomo nosso contato sobre sua solicitação de agendamento. Você gostaria de continuar? |
| /encerrar | Obrigado pelo retorno. Sua solicitação de atendimento foi finalizada. Se precisar de outra informação administrativa, estamos à disposição. |

Saudação proposta: “Olá! Você entrou em contato com a equipe de atendimento do Dr. Alexandre Fuzimoto. Assim que possível, responderemos sua solicitação.”

Ausência proposta: “Recebemos sua mensagem. Nosso atendimento funciona em [horários confirmados pela clínica]. Retornaremos durante esse período.”

Não prometer horário, preço, prazo ou resultado de tratamento sem aprovação. Questões clínicas devem ser direcionadas ao profissional responsável; este material não orienta atendimento clínico.

## Exercício conjunto — 10 minutos

1. Usar contato de teste autorizado; nunca conversar com número inventado.
2. Uma pessoa representa o contato interessado; outra a YSO e outra a recepção.
3. Abrir WhatsApp pelo CRM, conferir destinatário e enviar manualmente.
4. Simular pedido de horário e criar atendimento fictício.
5. YSO registra resumo e transfere responsabilidade; recepção confirma recebimento.
6. Recepção simula confirmação e conclui somente a solicitação administrativa.

## Conferência — 5 minutos

- Uma só pessoa respondeu por vez?
- Cada pendência tinha responsável e data?
- O histórico mostrou o autor da nova observação?
- Nenhum dado clínico ou telefone real foi salvo no demonstrativo?
- A equipe entendeu que o botão não importa mensagens nem comprova entrega?

## Evolução

Agora: atalho sem automação ou dependência paga no código. Próxima fase possível: telefone cadastrado e mensagens administrativas preparadas, após definir uso real e acesso. Integração bidirecional exige projeto com plataforma oficial, número autorizado, contas, avaliação de custos e regras vigentes. Nada contratado agora.

Fontes oficiais consultadas: [Click to chat](https://faq.whatsapp.com/5913398998672934) e [WhatsApp Business App](https://business.whatsapp.com/products/business-app). O atalho segue wa.me; recursos do aplicativo não se tornam automaticamente recursos do CRM.


## Atualização — 29/10/2026
Cadastre o telefone do cliente uma vez (país + DDD + número). Use WhatsApp em Clientes ou no atendimento para abrir a conversa com esse número. O CRM não sincroniza mensagens, etiquetas ou leitura e não envia observações. O treinamento deve incluir a conferência do destinatário e o registro manual do próximo retorno.
