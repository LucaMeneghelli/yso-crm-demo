CREATE TABLE IF NOT EXISTS schema_migrations (version integer PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS customers (
 id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 name text NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 100),
 email text NOT NULL UNIQUE CHECK (email = lower(trim(email)) AND email LIKE '%@example.com'),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS owners (id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY, name text NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS tickets (
 id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 customer_id integer NOT NULL REFERENCES customers(id),
 service text NOT NULL CHECK (length(trim(service)) BETWEEN 1 AND 500),
 stage text NOT NULL DEFAULT 'Novo atendimento' CHECK (stage IN ('Novo atendimento','Em avaliação','Aguardando aprovação','Em execução','Concluído','Cancelado')),
 owner_id integer NOT NULL REFERENCES owners(id),
 next_return date,
 version integer NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 CHECK ((stage IN ('Concluído','Cancelado') AND next_return IS NULL) OR (stage NOT IN ('Concluído','Cancelado') AND next_return IS NOT NULL))
);
CREATE TABLE IF NOT EXISTS notes (
 id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 ticket_id integer NOT NULL REFERENCES tickets(id),
 body text NOT NULL CHECK (length(trim(body)) BETWEEN 1 AND 2000),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tickets_return_idx ON tickets(next_return);
CREATE INDEX IF NOT EXISTS notes_ticket_idx ON notes(ticket_id, id);
INSERT INTO schema_migrations(version) VALUES (1) ON CONFLICT DO NOTHING;
