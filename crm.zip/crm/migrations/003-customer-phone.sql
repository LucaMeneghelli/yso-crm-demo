ALTER TABLE customers ADD COLUMN IF NOT EXISTS phone text;

DO $$ BEGIN
 IF NOT EXISTS (SELECT 1 FROM schema_migrations WHERE version=3) THEN
  ALTER TABLE customers DROP CONSTRAINT IF EXISTS customers_email_check;
  ALTER TABLE customers ADD CONSTRAINT customers_email_check CHECK (email=lower(trim(email)) AND email ~ '^[^[:space:]@]+@[^[:space:]@]+[.][^[:space:]@]+$');
  ALTER TABLE customers ADD CONSTRAINT customers_phone_check CHECK (phone IS NULL OR phone ~ '^[1-9][0-9]{7,14}$');
  INSERT INTO schema_migrations(version) VALUES (3);
 END IF;
END $$;
