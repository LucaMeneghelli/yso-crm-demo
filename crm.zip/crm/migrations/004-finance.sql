CREATE TABLE IF NOT EXISTS finance_charges (
 id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 ticket_id integer NOT NULL UNIQUE REFERENCES tickets(id),
 amount integer NOT NULL CHECK(amount>0), issued_on date NOT NULL,
 created_by integer NOT NULL REFERENCES app_users(id), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS finance_installments (
 id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 charge_id integer NOT NULL REFERENCES finance_charges(id),
 number integer NOT NULL, amount integer NOT NULL CHECK(amount>0), due_on date NOT NULL,
 UNIQUE(charge_id,number)
);
CREATE TABLE IF NOT EXISTS finance_payments (
 id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 installment_id integer NOT NULL REFERENCES finance_installments(id),
 amount integer NOT NULL CHECK(amount>0), paid_on date NOT NULL,
 method text NOT NULL CHECK(method IN ('Pix','Dinheiro','Cartão','Transferência','Outro')),
 request_id uuid NOT NULL UNIQUE, created_by integer NOT NULL REFERENCES app_users(id),
 voided boolean NOT NULL DEFAULT false, void_reason text, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS finance_expenses (
 id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 ticket_id integer REFERENCES tickets(id), category text NOT NULL,
 description text NOT NULL, amount integer NOT NULL CHECK(amount>0), paid_on date NOT NULL,
 request_id uuid NOT NULL UNIQUE, created_by integer NOT NULL REFERENCES app_users(id),
 voided boolean NOT NULL DEFAULT false, void_reason text, created_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO schema_migrations(version) VALUES (4) ON CONFLICT DO NOTHING;
