CREATE TABLE IF NOT EXISTS assistant_simulations (
 id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 created_by integer NOT NULL REFERENCES app_users(id),
 version integer NOT NULL DEFAULT 0,
 human boolean NOT NULL DEFAULT false,
 pending text,
 messages jsonb NOT NULL DEFAULT '[]',
 created_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO schema_migrations(version) VALUES (5) ON CONFLICT DO NOTHING;
