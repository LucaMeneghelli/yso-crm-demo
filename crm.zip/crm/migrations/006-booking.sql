ALTER TABLE assistant_simulations ADD COLUMN IF NOT EXISTS booking jsonb NOT NULL DEFAULT '{}';
INSERT INTO schema_migrations(version) VALUES (6) ON CONFLICT DO NOTHING;
