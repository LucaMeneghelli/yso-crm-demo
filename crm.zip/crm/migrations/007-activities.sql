CREATE TABLE IF NOT EXISTS activities (
 id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 customer_id integer NOT NULL REFERENCES customers(id),
 assigned_to integer NOT NULL REFERENCES app_users(id),
 title text NOT NULL CHECK(length(title) BETWEEN 1 AND 200),
 kind text NOT NULL CHECK(kind IN ('Ligação','WhatsApp','E-mail','Reunião','Follow-up','Tarefa')),
 due_on date NOT NULL, due_time time NOT NULL,
 created_by integer NOT NULL REFERENCES app_users(id),
 created_at timestamptz NOT NULL DEFAULT now(),completed_at timestamptz,completed_by integer REFERENCES app_users(id)
);
CREATE INDEX IF NOT EXISTS activities_customer_due ON activities(customer_id,due_on);
INSERT INTO schema_migrations(version) VALUES (7) ON CONFLICT DO NOTHING;
