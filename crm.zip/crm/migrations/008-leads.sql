CREATE TABLE IF NOT EXISTS leads (
 id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 name text NOT NULL, email text NOT NULL, phone text,
 company text NOT NULL DEFAULT '', source text NOT NULL DEFAULT '',
 interest text NOT NULL DEFAULT '', status text NOT NULL DEFAULT 'Novo'
 CHECK(status IN ('Novo','Em contato','Qualificado','Descartado')),
 assigned_to integer NOT NULL REFERENCES app_users(id),
 created_by integer NOT NULL REFERENCES app_users(id),
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(), version integer NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS leads_status_created ON leads(status,created_at DESC);
INSERT INTO schema_migrations(version) VALUES(8) ON CONFLICT DO NOTHING;
