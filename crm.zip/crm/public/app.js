import {initializeLeads} from './leads.js';
import {operationalView} from './operations.js';
import {initializeAssistant} from './assistant.js';
import {initializeFinance} from './finance.js';
import {initializeAuth,currentUser,signedOut} from './auth.js';
import {initializeWhatsApp,conversationUrl,formatPhone} from './whatsapp.js';
import {hasDuplicateNote, duplicateNoteMessage} from './note-validation.js';
const $ = selector => document.querySelector(selector);
const openWhatsApp=initializeWhatsApp(()=>state.customers);
const esc = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state = {customers:[],owners:[],tickets:[],stages:[],today:''};
const finance=initializeFinance({api,getState:()=>state,getUser:currentUser,showDialog,toast});
const assistant=initializeAssistant({api,toast});
const leads=initializeLeads({api,showDialog,toast});
let view = 'tickets', customerFilter = null, toastTimer;
const closed = stage => ['Concluído','Cancelado'].includes(stage);
const formatDate = day => day ? day.split('-').reverse().join('/') : '—';
const returnLabel = ticket => closed(ticket.stage) ? 'Encerrado' : ticket.next_return < state.today ? 'Atrasado' : ticket.next_return === state.today ? 'Hoje' : 'Agendado';
const initials = name => name.split(' ').slice(0,2).map(s=>s[0]).join('').toUpperCase();
async function api(path,options={}) {
  const response = await fetch(path,{...options,headers:{'Content-Type':'application/json',...options.headers}});
  const result = await response.json();
  if (!response.ok) { if(response.status===401) signedOut(result.error); throw new Error(result.error || 'Não foi possível concluir a operação.'); }
  return result;
}
function toast(message) { clearTimeout(toastTimer);$('#toast').textContent=message;$('#toast').hidden=false;toastTimer=setTimeout(()=>$('#toast').hidden=true,5000); }
async function activityPanel(){
 try{const d=await api('/api/activities');
 showDialog('Atividades da equipe',`<p class="detail-subtitle">Prazos no horário de Brasília. Até 500 atividades, pendentes primeiro. Nenhuma mensagem é enviada automaticamente.</p><form id="activity-form" class="access-form"><label>Cliente<select name="customer_id" required>${state.customers.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label><label>Descrição<input name="title" required maxlength="200"></label><label>Tipo<select name="kind">${['Ligação','WhatsApp','E-mail','Reunião','Follow-up','Tarefa'].map(k=>`<option>${k}</option>`).join('')}</select></label><label>Responsável<select name="assigned_to" required>${d.users.map(u=>`<option value="${u.id}">${esc(u.name)}</option>`).join('')}</select></label><label>Data<input name="due_on" type="date" required value="${state.today}"></label><label>Hora<input name="due_time" type="time" required value="09:00"></label><p role="alert" class="form-error"></p><button class="primary" type="submit">Criar atividade</button></form><h3>Agenda de atividades</h3><form id="activity-filters" class="filters"><label>Buscar atividade<input name="search" type="search" placeholder="Descrição, cliente ou responsável"></label><label>Situação<select name="status"><option value="">Todas</option><option value="pending">Pendentes</option><option value="completed">Concluídas</option></select></label><label>Responsabilidade<select name="scope"><option value="">Toda a equipe</option><option value="mine">Minhas atividades</option></select></label></form><p id="activity-count" role="status"></p><div id="activity-list" class="customer-timeline">${d.activities.map(a=>`<article data-activity-id="${a.id}"><strong>${esc(a.title)}</strong><p>${esc(a.customer_name)} · ${esc(a.kind)} · ${esc(a.assigned_name)}</p><small>${formatDate(a.due_on)} às ${esc(a.due_time.slice(0,5))} · ${a.completed_at?'Concluída':'Pendente'}</small>${!a.completed_at&&(currentUser().role==='admin'||a.assigned_to===currentUser().id)?`<button class="secondary" data-complete-activity="${a.id}">Concluir</button>`:''}</article>`).join('')||'<p>Nenhuma atividade cadastrada.</p>'}</div>`);
 const filters=$('#activity-filters');
 const applyFilters=()=>{const values=Object.fromEntries(new FormData(filters));let count=0;for(const card of $('#activity-list').querySelectorAll('[data-activity-id]')){const a=d.activities.find(item=>String(item.id)===card.dataset.activityId);const visible=(!values.status||(values.status==='completed')===Boolean(a.completed_at))&&(!values.scope||a.assigned_to===currentUser().id)&&`${a.title} ${a.customer_name} ${a.assigned_name}`.toLocaleLowerCase('pt-BR').includes(values.search.trim().toLocaleLowerCase('pt-BR'));card.hidden=!visible;if(visible)count++;}$('#activity-count').textContent=count?`${count} atividade(s) nesta visão`:'Nenhuma atividade corresponde aos filtros.';};
 filters.oninput=applyFilters;filters.onchange=applyFilters;filters.onsubmit=e=>e.preventDefault();applyFilters();
 $('#activity-form').onsubmit=async e=>{e.preventDefault();const f=e.currentTarget,b=f.querySelector('button');b.disabled=true;try{await api('/api/activities',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(f)))});await activityPanel();}catch(err){f.querySelector('[role=alert]').textContent=err.message;}finally{b.disabled=false;}};
 }catch(e){toast(e.message);}
}
async function load(background=false) {
  try {
    const result = await api('/api/state',{headers:background?{'X-YSO-Background':'1'}:{}});
    state = result;
    $('#connection-error').hidden=true;
    for (const [selector,items] of [['#stage-filter',state.stages.map(s=>({id:s,name:s}))],['#owner-filter',state.owners]]) {
      const el=$(selector), selected=el.value, first=el.options[0].outerHTML;
      el.innerHTML=first+items.map(item=>`<option value="${esc(item.id)}">${esc(item.name)}</option>`).join('');el.value=selected;
    }
    render();return true;
  } catch(error) { $('#connection-error').textContent=`${error.message} Use Atualizar para tentar novamente.`;$('#connection-error').hidden=false;return false; }
}
function render() {
  if(view==='finance'||view==='assistant'||view==='leads')return;
  const active=state.tickets.filter(t=>!closed(t.stage));
  $('#nav-count').textContent=active.length;
  $('#stats').innerHTML=[['Em acompanhamento',active.length,'Atendimentos em aberto','↗'],['Retornos de hoje',active.filter(t=>returnLabel(t)==='Hoje').length,'O próximo passo é hoje','◷'],['Retornos atrasados',active.filter(t=>returnLabel(t)==='Atrasado').length,'Precisam de atenção','!',true],['Concluídos',state.tickets.filter(t=>t.stage==='Concluído').length,'Serviços finalizados','✓']].map(([title,value,description,icon,alert])=>`<div class="stat ${alert?'alert':''}"><div class="stat-title">${title}<span class="stat-icon">${icon}</span></div><div class="stat-number">${value.toString().padStart(2,'0')}</div><small>${description}</small></div>`).join('');
  const search=$('#search').value.toLocaleLowerCase('pt-BR');
  if(view==='day'||view==='board'){
    const tickets=state.tickets.filter(t=>(!$('#owner-filter').value||String(t.owner_id)===$('#owner-filter').value)&&`${t.customer_name} ${t.service}`.toLocaleLowerCase('pt-BR').includes(search));
    $('#records').innerHTML=operationalView({tickets,stages:state.stages,today:state.today,view,escape:esc});
    $('#result-count').textContent='Visão da equipe · filtre por responsável';return;
  }
  if(view==='tickets') {
    const tickets=state.tickets.filter(t=>(!customerFilter||t.customer_id===customerFilter)&&(!$('#stage-filter').value||t.stage===$('#stage-filter').value)&&(!$('#owner-filter').value||String(t.owner_id)===$('#owner-filter').value)&&(!$('#return-filter').value||returnLabel(t)===$('#return-filter').value)&&`${t.customer_name} ${t.service}`.toLocaleLowerCase('pt-BR').includes(search));
    const chip=customerFilter?`<div class="filter-chip">Cliente: ${esc(state.customers.find(c=>c.id===customerFilter)?.name)}<button id="clear-customer">Limpar filtro</button></div>`:'';
    $('#records').innerHTML=chip+(tickets.length?`<table><thead><tr><th>Cliente</th><th>Serviço solicitado</th><th>Etapa</th><th>Responsável</th><th>Próximo retorno</th><th><span class="sr-label">Detalhes</span></th></tr></thead><tbody>${tickets.map(t=>`<tr><td><div class="customer-cell"><span class="avatar">${esc(initials(t.customer_name))}</span><div><strong>${esc(t.customer_name)}</strong><small>Atendimento #${String(t.id).padStart(3,'0')}</small></div></div></td><td class="service-cell">${esc(t.service)}</td><td><span class="badge s${state.stages.indexOf(t.stage)}">${esc(t.stage)}</span></td><td><span class="owner">${esc(t.owner_name)}</span></td><td><span class="return-date">${formatDate(t.next_return)}</span><span class="return-label ${returnLabel(t)==='Atrasado'?'late':returnLabel(t)==='Hoje'?'today':''}">${returnLabel(t)}</span></td><td><button class="open-record" data-ticket="${t.id}">Abrir ↗</button></td></tr>`).join('')}</tbody></table>`:'<div class="empty">Nenhum atendimento encontrado.<br>Experimente outros filtros ou cadastre um novo atendimento.</div>');
    $('#result-count').textContent=`${tickets.length} atendimento${tickets.length===1?'':'s'} nesta visão`;
  } else {
    const customers=state.customers.filter(c=>`${c.name} ${c.email} ${c.phone||''}`.toLocaleLowerCase('pt-BR').includes(search));
    $('#records').innerHTML=customers.length?`<table><thead><tr><th>Cliente</th><th>Contato</th><th>Atendimentos</th><th>Ações</th></tr></thead><tbody>${customers.map(c=>`<tr><td><div class="customer-cell"><span class="avatar">${esc(initials(c.name))}</span><strong>${esc(c.name)}</strong></div></td><td>${esc(c.email)}<small class="contact-phone">${esc(formatPhone(c.phone)||'Telefone não informado')}</small></td><td>${state.tickets.filter(t=>t.customer_id===c.id).length}</td><td><button class="primary" data-customer-history="${c.id}">Visão do cliente</button> <button class="open-record" data-customer-tickets="${c.id}">Ver atendimentos</button> <button class="text-button" data-edit-customer="${c.id}">Editar</button> ${whatsAppAction(c.id)}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">Nenhum cliente encontrado. Cadastre um cliente para começar.</div>';
    $('#result-count').textContent=`${customers.length} cliente${customers.length===1?'':'s'} nesta visão`;
  }
}
function setView(next) {
  view=next;$('#search').value='';
  $('#operations-view').hidden=['finance','assistant','leads'].includes(view);
  leads.close();
  if(view==='leads'){assistant.close();finance.close();document.querySelectorAll('[data-view]').forEach(el=>el.classList.toggle('active',el.dataset.view===view));$('#breadcrumb').textContent='Leads';leads.open();return;}
  assistant.close();
  if(view==='assistant'){
    finance.close();
    document.querySelectorAll('[data-view]').forEach(el=>{el.classList.toggle('active',el.dataset.view===view);el.setAttribute('aria-current',el.dataset.view===view?'page':'false');});
    $('#breadcrumb').textContent='Assistente virtual';
    assistant.open();return;
  }
  if(view==='finance'){document.querySelectorAll('[data-view]').forEach(el=>{el.classList.toggle('active',el.dataset.view===view);el.setAttribute('aria-current',el.dataset.view===view?'page':'false');});$('#breadcrumb').textContent='Financeiro';finance.open();return;}
  finance.close();
  document.querySelectorAll('[data-view]').forEach(el=>{el.classList.toggle('active',el.dataset.view===view);el.setAttribute('aria-current',el.dataset.view===view?'page':'false');});
  if(view==='day'||view==='board'){
    const title=view==='day'?'Meu dia':'Quadro de atendimentos';
    $('#breadcrumb').textContent=title;$('#page-title').textContent=title;
    $('#page-description').textContent=view==='day'?'Comece pelos retornos atrasados e organize os próximos contatos da equipe.':'Acompanhe cada etapa e abra um cartão para registrar o próximo passo.';
    $('#new-record').textContent='＋ Novo atendimento';$('#list-title').textContent=view==='day'?'Prioridades da equipe':'Pipeline de atendimento';
    $('#list-subtitle').textContent='Responsáveis são os rótulos de acompanhamento cadastrados.';
    $('#search').placeholder='Buscar cliente ou serviço...';$('#stage-filter').hidden=true;$('#return-filter').hidden=true;$('#owner-filter').hidden=false;render();return;
  }
  $('#breadcrumb').textContent=view==='tickets'?'Atendimentos':'Clientes';
  $('#page-title').innerHTML=view==='tickets'?'Atendimentos':'Clientes';
  $('#page-description').textContent=view==='tickets'?'Veja quem precisa de retorno e acompanhe cada atendimento.':'Um cadastro organizado para cada cliente da sua clínica.';
  $('#new-record').textContent=view==='tickets'?'＋ Novo atendimento':'＋ Novo cliente';
  $('#list-title').textContent=view==='tickets'?'Visão dos atendimentos':'Sua carteira de clientes';
  $('#list-subtitle').textContent=view==='tickets'?'Tudo o que precisa da sua atenção.':'Seus contatos e conversas, sempre à mão.';
  $('#search').placeholder=view==='tickets'?'Buscar cliente ou serviço...':'Buscar nome ou contato...';
  for(const selector of ['#stage-filter','#owner-filter','#return-filter']) $(selector).hidden=view!=='tickets';
  render();
}
function showDialog(title,content) { $('#dialog-title').textContent=title;$('#dialog-content').innerHTML=content;if(!$('#editor').open)$('#editor').showModal(); }
const errorSlot='<p class="form-error" role="alert" id="form-error"></p>';
const actions=label=>`<div class="form-actions"><button type="button" class="secondary" data-close>Voltar</button><button class="primary" type="submit">${label}</button></div>`;
function whatsAppAction(customerId,label='WhatsApp ↗') {
  const customer=state.customers.find(c=>c.id===customerId);
  if(customer?.phone){try{return '<a class="whatsapp-action" target="_blank" rel="noopener noreferrer" href="'+esc(conversationUrl(customer.phone))+'">'+esc(label)+'</a>';}catch{}}
  return '<button type="button" class="whatsapp-action" data-whatsapp-customer="'+customerId+'">Cadastrar WhatsApp</button>';
}
function customerForm(customer=null) {
  showDialog(customer?'Editar cliente':'Novo cliente',`<p class="detail-subtitle">Cadastre os dados de contato para acompanhar o relacionamento.</p><form id="customer-form"><div class="form-grid"><label class="full">Nome do cliente *<input name="name" required maxlength="100" value="${esc(customer?.name||'')}" placeholder="Nome completo"></label><label class="full">E-mail *<input name="email" type="email" required maxlength="150" value="${esc(customer?.email||'')}" placeholder="nome@exemplo.com"></label><label class="full">WhatsApp<input name="phone" type="tel" maxlength="30" value="${esc(formatPhone(customer?.phone))}" placeholder="+55 (11) 00000-0000"><small>Opcional. Salve uma vez para abrir a conversa pelo CRM. Inclua o código do país.</small></label></div>${errorSlot}${actions(customer?'Salvar alterações':'Cadastrar cliente')}</form>`);
  $('#customer-form').elements.phone.addEventListener('blur',event=>{if(event.target.value.trim()){try{conversationUrl(event.target.value);event.target.value=formatPhone(event.target.value);}catch{}}});
  $('#customer-form').onsubmit=async event=>{
    event.preventDefault();const form=event.currentTarget;const button=form.querySelector('[type=submit]');button.disabled=true;
    try { const result=await api(customer?`/api/customers/${customer.id}`:'/api/customers',{method:customer?'PUT':'POST',body:JSON.stringify(Object.fromEntries(new FormData(form)))});$('#editor').close();await load();toast(result.reused?'Contato já cadastrado. Utilize o cliente existente.':'Cliente salvo com sucesso.'); }
    catch(error){$('#form-error').textContent=error.message;}finally{button.disabled=false;}
  };
}
function ticketForm(ticket=null) {
  const readonly=ticket&&closed(ticket.stage);
  const stageOptions=ticket?[ticket.stage,...(!readonly?[state.stages[state.stages.indexOf(ticket.stage)+1],...(ticket.stage==='Aguardando aprovação'?['Em avaliação']:[]),'Cancelado']:[])]:['Novo atendimento'];
  const noteHelp=readonly?'':'Ao mudar a etapa, registre a proposta, aprovação, conclusão ou motivo. As notas anteriores serão preservadas. Não registre diagnósticos ou informações clínicas.';
  const notes=ticket?.notes?.map(n=>`<div class="note"><small>${esc(new Date(n.created_at).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'}))}</small>${n.author_name?`<small>Registrado por ${esc(n.author_name)}</small>`:""}${esc(n.body)}</div>`).join('')||'<p class="detail-subtitle">Nenhuma observação registrada.</p>';
  showDialog(ticket?`Atendimento #${String(ticket.id).padStart(3,'0')}`:'Novo atendimento',`${ticket?`<p class="detail-subtitle">${esc(ticket.customer_name)} · ${esc(ticket.customer_email)}</p>${whatsAppAction(ticket.customer_id,'Conversar no WhatsApp ↗')}`:'<p class="detail-subtitle">Defina o pedido, quem acompanha e quando será o próximo retorno.</p>'}${readonly?'<p class="closed-info">Atendimento encerrado. O histórico está preservado para consulta. Para uma nova solicitação, abra outro atendimento.</p>':''}<form id="ticket-form"><div class="form-grid">${!ticket?`<label class="full">Cliente *<select name="customer_id" required><option value="">Selecione um cliente</option>${state.customers.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select><small>Cadastre novos clientes na seção Clientes antes de abrir o atendimento.</small></label>`:''}<label class="full">Serviço solicitado *<input name="service" required maxlength="500" value="${esc(ticket?.service||'')}" ${readonly?'disabled':''} placeholder="Ex.: Solicitação de agendamento"></label><label>Responsável *<select name="owner_id" required ${readonly?'disabled':''}><option value="">Selecione</option>${state.owners.map(o=>`<option value="${o.id}" ${o.id===ticket?.owner_id?'selected':''}>${esc(o.name)}</option>`).join('')}</select></label><label>Etapa *<select name="stage" ${readonly?'disabled':''}>${stageOptions.map(s=>`<option ${s===ticket?.stage?'selected':''}>${esc(s)}</option>`).join('')}</select></label><label class="full">Próximo retorno <span id="return-required">${readonly?'':'*'}</span><input name="next_return" type="date" ${readonly?'disabled':'required'} value="${ticket ? (ticket.next_return || '') : state.today}"><small>Quando revisar o atendimento ou retornar ao cliente.</small></label>${!readonly?`<label class="full">Nova observação <span id="note-required"></span><textarea name="note" maxlength="2000" placeholder="Registre o próximo passo administrativo..."></textarea><small>${noteHelp}</small></label>`:''}</div>${errorSlot}${readonly?'<div class="form-actions"><button type="button" class="secondary" data-close>Fechar</button></div>':actions(ticket?'Salvar atendimento':'Criar atendimento')}</form>${ticket?`<section class="history"><h3>Histórico de observações</h3>${notes}</section>`:''}`);
  if(readonly)return;
  const form=$('#ticket-form'),stage=form.elements.stage,returnInput=form.elements.next_return;
  function sync() {
    const isClosed=closed(stage.value);returnInput.disabled=isClosed;returnInput.required=!isClosed;
    $('#return-required').textContent=isClosed?'':'*';
    const required=ticket&&stage.value!==ticket.stage&&!(ticket.stage==='Novo atendimento'&&stage.value==='Em avaliação');
    form.elements.note.required=!!required;$('#note-required').textContent=required?'*':'';
  }
  stage.onchange=sync;sync();
  form.onsubmit=async event=>{
    event.preventDefault();const button=form.querySelector('[type=submit]');button.disabled=true;
    const values=Object.fromEntries(new FormData(form));if(ticket) values.version=ticket.version;
    if(hasDuplicateNote(values.note)) { $('#form-error').textContent=duplicateNoteMessage;form.elements.note.focus();button.disabled=false;return; }
    try {await api(ticket?`/api/tickets/${ticket.id}`:'/api/tickets',{method:ticket?'PUT':'POST',body:JSON.stringify(values)});$('#editor').close();await load();toast('Atendimento salvo. Próximo passo organizado.');}
    catch(error){$('#form-error').textContent=error.message;}finally{button.disabled=false;}
  };
}
document.addEventListener('click',async event=>{
  const button=event.target.closest('button');if(!button)return;
  if(button.id==='open-activities')await activityPanel();
  if(button.dataset.completeActivity){button.disabled=true;try{await api(`/api/activities/${button.dataset.completeActivity}/complete`,{method:'POST',body:'{}'});await activityPanel();}catch(e){toast(e.message);button.disabled=false;}}
  if(button.dataset.view){customerFilter=null;setView(button.dataset.view);}
  if(button.hasAttribute('data-close')||button.id==='close-dialog')$('#editor').close();
  if(button.dataset.customerHistory){
    try{const h=await api(`/api/customers/${button.dataset.customerHistory}/history`);
    showDialog(h.customer.name,`<div class="customer-profile"><p>${esc(h.customer.email)} · ${esc(formatPhone(h.customer.phone)||'Sem telefone')}</p>${whatsAppAction(h.customer.id)}<h3>Atendimentos · ${h.tickets.length}</h3><div class="profile-tickets">${h.tickets.map(t=>`<button class="secondary" data-ticket="${t.id}">#${t.id} · ${esc(t.service)}<small>${esc(t.stage)} · ${esc(t.owner_name)} · Retorno: ${formatDate(t.next_return)}</small></button>`).join('')||'<p>Nenhum atendimento.</p>'}</div><h3>Histórico do relacionamento</h3><p class="detail-subtitle">Até ${h.limit} registros mais recentes, pela data de registro. Custos e despesas são consultados no Financeiro pelo administrador. Conversas externas ainda não são sincronizadas.</p><form id="history-filter" class="filters"><label>Tipo<select name="kind"><option value="">Todos</option><option value="note">Observações</option><option value="ticket">Atendimentos</option><option value="charge">Cobranças</option><option value="payment">Pagamentos</option><option value="activity">Atividades</option></select></label><label>De<input type="date" name="from"></label><label>Até<input type="date" name="to"></label><button class="secondary">Filtrar</button></form><div id="filtered-history" class="customer-timeline">${h.events.map(e=>`<article><small>${esc(new Date(e.at).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'}))}${e.ticket_id?' · Atendimento #'+esc(e.ticket_id):''}${e.author?' · '+esc(e.author):''}</small><p>${esc(e.description)}</p>${e.amount!==null?`<strong>${esc((e.amount/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'}))}${e.voided?' · Estornado':''}</strong>`:''}</article>`).join('')||'<p>Nenhum registro ainda.</p>'}</div></div>`);
    $('#history-filter').onsubmit=async e=>{e.preventDefault();try{const query=new URLSearchParams(new FormData(e.currentTarget));const result=await api(`/api/customers/${h.customer.id}/history?${query}`);$('#filtered-history').innerHTML=result.events.map(ev=>`<article><small>${esc(new Date(ev.at).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'}))}${ev.author?' · '+esc(ev.author):''}</small><p>${esc(ev.description)}</p>${ev.amount!==null?`<strong>${esc((ev.amount/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'}))}${ev.voided?' · Estornado':''}</strong>`:''}</article>`).join('')||'<p>Nenhum registro neste filtro.</p>';}catch(error){toast(error.message);}};
    }catch(error){toast(error.message);}
  }
  if(button.dataset.ticket){try{ticketForm(await api(`/api/tickets/${button.dataset.ticket}`));}catch(error){toast(error.message);}}
  if(button.id==='open-whatsapp')openWhatsApp();
  if(button.dataset.whatsappCustomer){
    const customer=state.customers.find(c=>c.id===Number(button.dataset.whatsappCustomer));
    if(!customer)return;
    if(!customer.phone){customerForm(customer);toast('Cadastre o telefone para abrir a conversa.');}
    else {try{window.open(conversationUrl(customer.phone),'_blank','noopener,noreferrer');}catch(error){toast(error.message);}}
  }
  if(button.dataset.editCustomer)customerForm(state.customers.find(c=>c.id===Number(button.dataset.editCustomer)));
  if(button.dataset.customerTickets){customerFilter=Number(button.dataset.customerTickets);for(const s of ['#stage-filter','#owner-filter','#return-filter'])$(s).value='';setView('tickets');}
  if(button.id==='clear-customer'){customerFilter=null;render();}
});
$('#new-record').onclick=()=>view==='customers'?customerForm():ticketForm();
$('#refresh').onclick=async()=>{if(await load())toast('Dados atualizados.');};
for(const selector of ['#search','#stage-filter','#owner-filter','#return-filter'])$(selector).addEventListener('input',render);
setInterval(()=>{if(currentUser()&&!currentUser().must_change_password&&!$('#editor').open)load(true);},60000);
await initializeAuth(()=>load(),()=>{
  leads.close();assistant.reset();finance.close();view='tickets';$('#operations-view').hidden=false;
  state={customers:[],owners:[],tickets:[],stages:[],today:''};
  $('#records').innerHTML='';$('#stats').innerHTML='';$('#dialog-content').innerHTML='';
});



