const $=selector=>document.querySelector(selector);
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function enhancePasswords(root=document) {
  for(const input of root.querySelectorAll('input[type="password"]')) {
    if(input.parentElement.classList.contains('password-control'))continue;
    const wrapper=document.createElement('span');wrapper.className='password-control';
    input.before(wrapper);wrapper.append(input);
    const button=document.createElement('button');button.type='button';button.className='password-toggle';button.textContent='Mostrar';button.setAttribute('aria-label','Mostrar senha');button.setAttribute('aria-pressed','false');
    button.onclick=()=>{const visible=input.type==='password';input.type=visible?'text':'password';button.textContent=visible?'Ocultar':'Mostrar';button.setAttribute('aria-label',visible?'Ocultar senha':'Mostrar senha');button.setAttribute('aria-pressed',String(visible));};
    input.form?.addEventListener('reset',()=>{input.type='password';button.textContent='Mostrar';button.setAttribute('aria-label','Mostrar senha');button.setAttribute('aria-pressed','false');});wrapper.append(button);
  }
}
let user=null,onLogin=()=>{},onExit=()=>{};
export const currentUser=()=>user;
async function request(path,method='GET',data) {
  const res=await fetch(path,{method,headers:{'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined});
  const result=await res.json();
  if(!res.ok){const error=new Error(result.error||'Operação não concluída.');error.status=res.status;throw error;}
  return result;
}
export function signedOut(message='') {
  user=null;document.body.classList.add('auth-locked');$('#login-screen').hidden=false;
  $('#login-message').textContent=message;$('#access-dialog').close();$('#editor').close();
  $('#whatsapp-dialog').close();$('#access-content').replaceChildren();
  $('#first-password').reset();
  $('#login-form').reset();$('#password-screen').hidden=true;$('#login-form').hidden=false;
  onExit();
}
async function acceptUser(value) {
  user=value;
  $('#session-name').textContent=`${user.name} · ${user.role==='admin'?'Administrador':'Atendente'}`;
  $('#manage-users').hidden=user.role!=='admin';
  if(user.must_change_password) {
    document.body.classList.add('auth-locked');$('#login-screen').hidden=false;$('#login-form').hidden=true;
    $('#password-screen').hidden=false;$('#login-message').textContent='Defina sua senha pessoal antes de acessar os dados.';
    return;
  }
  $('#login-screen').hidden=true;document.body.classList.remove('auth-locked');await onLogin();
}
function passwordFields(prefix='') {return `<label>Senha atual<input name="current_password" type="password" autocomplete="current-password" required maxlength="128"></label><label>Nova senha<input name="new_password" type="password" autocomplete="new-password" required minlength="12" maxlength="128"></label><label>Confirmar nova senha<input name="confirm_password" type="password" autocomplete="new-password" required minlength="12" maxlength="128"></label><small>Use de 12 a 128 caracteres. A troca encerra todas as sessões desta conta.</small>`;}
function attachPasswordForm(form) {
  form.onsubmit=async event=>{
    event.preventDefault();const button=form.querySelector('[type=submit]');const error=form.querySelector('[role=alert]');
    const data=Object.fromEntries(new FormData(form));
    if(data.new_password!==data.confirm_password){error.textContent='As novas senhas não coincidem.';return;}
    button.disabled=true;error.textContent='';
    try{await request('/api/auth/password','POST',data);form.reset();signedOut('Senha alterada. Entre com sua nova senha.');}
    catch(e){error.textContent=e.message;if(e.status===401)signedOut(e.message);}finally{button.disabled=false;}
  };
}
function dialog(title,content) {
  $('#access-title').textContent=title;$('#access-content').innerHTML=content;enhancePasswords($('#access-content'));
  if(!$('#access-dialog').open)$('#access-dialog').showModal();
}
function userForm(existing=null,reset=false) {
  dialog(reset?'Redefinir acesso':existing?'Permissões do usuário':'Novo usuário',`<form id="user-form" class="access-form">${existing?`<p>${esc(existing.name)} · ${esc(existing.email)}</p>`:`<label>Nome<input name="name" required maxlength="100"></label><label>E-mail de acesso<input name="email" type="email" required maxlength="150" autocomplete="off"></label>`}${!existing||reset?'<label>Senha temporária<input name="password" type="password" required minlength="12" maxlength="128" autocomplete="new-password"></label><small>Entregue a senha por um canal privado. A pessoa deverá trocá-la ao entrar.</small>':''}${!reset?`<label>Perfil<select name="role"><option value="attendant" ${existing?.role==='attendant'?'selected':''}>Atendente</option><option value="admin" ${existing?.role==='admin'?'selected':''}>Administrador</option></select></label>${existing?`<label>Situação<select name="active"><option value="true" ${existing.active?'selected':''}>Ativo</option><option value="false" ${!existing.active?'selected':''}>Desativado</option></select></label><small>Alterar o acesso encerra as sessões do usuário. O histórico não é apagado.</small>`:''}`:''}<p role="alert" class="form-error"></p><div class="form-actions"><button type="button" class="secondary" id="users-back">Voltar</button><button type="submit" class="primary">Salvar acesso</button></div></form>`);
  $('#users-back').onclick=showUsers;
  $('#user-form').onsubmit=async event=>{
    event.preventDefault();const form=event.currentTarget;const button=form.querySelector('[type=submit]');button.disabled=true;
    const data=Object.fromEntries(new FormData(form));if(existing&&!reset)data.active=data.active==='true';
    try {
      const url=existing?`/api/admin/users/${existing.id}${reset?'/password':''}`:'/api/admin/users';
      await request(url,existing&&!reset?'PUT':'POST',data);form.reset();
      if(existing?.id===user.id){signedOut('Seu acesso foi atualizado. Entre novamente.');return;}
      await showUsers();
    }catch(e){form.querySelector('[role=alert]').textContent=e.message;if(e.status===401)signedOut(e.message);}finally{button.disabled=false;}
  };
}
async function showUsers() {
  try {
    const {users}=await request('/api/admin/users');
    dialog('Acessos da equipe',`<p class="detail-subtitle">Cada pessoa usa sua própria conta. Atendentes não administram acessos.</p><button id="add-user" class="primary">＋ Novo usuário</button><div class="users-list">${users.map(u=>`<article><div><strong>${esc(u.name)}</strong><small>${esc(u.email)}</small><p>${u.role==='admin'?'Administrador':'Atendente'} · ${u.active?'Ativo':'Desativado'}${u.must_change_password?' · Troca de senha pendente':''}</p></div><div><button class="secondary" data-edit-user="${u.id}">Permissões</button>${u.id!==user.id?` <button class="text-button" data-reset-user="${u.id}">Redefinir senha</button>`:''}</div></article>`).join('')}</div><button id="view-audit" class="text-button">Ver últimas ações registradas</button>`);
    $('#add-user').onclick=()=>userForm();
    document.querySelectorAll('[data-edit-user]').forEach(el=>el.onclick=()=>userForm(users.find(u=>u.id===Number(el.dataset.editUser))));
    document.querySelectorAll('[data-reset-user]').forEach(el=>el.onclick=()=>userForm(users.find(u=>u.id===Number(el.dataset.resetUser)),true));
    $('#view-audit').onclick=async()=>{
      try {
        const {events}=await request('/api/admin/audit');
        const names={charge_created:'Criou cobrança',payment_received:'Registrou recebimento',expense_created:'Registrou custo ou despesa',entry_voided:'Estornou lançamento',login:'Entrou no CRM',user_created:'Criou usuário',user_access_updated:'Alterou acesso',password_reset:'Redefiniu senha',password_changed:'Trocou a própria senha',admin_bootstrapped:'Criou administrador inicial',ticket_created:'Criou atendimento',ticket_updated:'Atualizou atendimento'};
        dialog('Últimas ações',`<div class="users-list">${events.map(e=>`<article><div><strong>${esc(e.actor_name||'Sistema')}</strong><p>${esc(names[e.action]||e.action)} · ${esc(e.target_type)} #${e.target_id??'—'}</p><small>${esc(new Date(e.created_at).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'}))}</small></div></article>`).join('')}</div><button id="audit-back" class="secondary">Voltar aos usuários</button>`);$('#audit-back').onclick=showUsers;
      }catch(e){signedOut(e.message);}
    };
  }catch(e){if(e.status===401||e.status===403)signedOut(e.message);else dialog('Acessos indisponíveis',`<p role="alert">${esc(e.message)}</p>`);}
}
export async function initializeAuth(ready,exit) {
  onLogin=ready;onExit=exit;
  $('#password-screen').innerHTML=`<h2>Defina sua senha</h2><form id="first-password" class="access-form">${passwordFields()}<p role="alert" class="form-error"></p><button type="submit" class="primary">Trocar senha e entrar novamente</button></form><button class="text-button" id="first-exit">Sair</button>`;
  enhancePasswords();
  attachPasswordForm($('#first-password'));
  const signOut=async()=>{try{await request('/api/auth/logout','POST',{});signedOut('Você saiu do CRM.');}catch(e){$('#session-error').textContent=e.message;$('#login-message').textContent=e.message;}};
  $('#logout').onclick=signOut;$('#first-exit').onclick=signOut;
  $('#access-close').onclick=()=>$('#access-dialog').close();
  $('#manage-users').onclick=showUsers;
  $('#my-password').onclick=()=>{dialog('Minha senha',`<form id="my-password-form" class="access-form">${passwordFields()}<p role="alert" class="form-error"></p><button class="primary" type="submit">Alterar senha</button></form>`);attachPasswordForm($('#my-password-form'));};
  $('#login-form').onsubmit=async event=>{
    event.preventDefault();const form=event.currentTarget;const button=form.querySelector('[type=submit]');button.disabled=true;$('#login-message').textContent='';
    try{const result=await request('/api/auth/login','POST',Object.fromEntries(new FormData(form)));form.reset();await acceptUser(result.user);}
    catch(e){$('#login-message').textContent=e.message;}finally{button.disabled=false;}
  };
  try{const result=await request('/api/auth/me');await acceptUser(result.user);}catch(e){signedOut(e.status===401?'':e.message);}
}
