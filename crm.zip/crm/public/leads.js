// public/leads.js - Módulo de Leads Enterprise YSO

async function loadLeadsModule() {
  const container = document.getElementById('main-content');
  if (!container) return;

  // Layout Base
  container.innerHTML = `
    <div class="leads-module-wrapper" style="padding: 24px; max-width: 1400px; margin: 0 auto;">
      
      <!-- Cabeçalho e Ações Principais -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
        <div>
          <h1 style="font-size: 24px; font-weight: 700; color: #0f172a; margin: 0;">Gestão de Leads</h1>
          <p style="font-size: 14px; color: #64748b; margin: 4px 0 0 0;">Acompanhe e qualifique as oportunidades do seu funil comercial.</p>
        </div>
        <button onclick="openNewLeadModal()" style="background-color: #0d9488; color: #fff; border: none; padding: 10px 18px; border-radius: 6px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 8px;">
          + Novo Lead
        </button>
      </div>

      <!-- Resumo KPI (Dashboards Rápidos) -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 24px;">
        <div class="crm-card" style="padding: 16px; border-left: 4px solid #0369a1;">
          <span style="font-size: 12px; font-weight: 600; color: #64748b; text-transform: uppercase;">Total de Leads</span>
          <div id="kpi-total-leads" style="font-size: 24px; font-weight: 700; color: #0f172a; margin-top: 4px;">-</div>
        </div>
        <div class="crm-card" style="padding: 16px; border-left: 4px solid #d97706;">
          <span style="font-size: 12px; font-weight: 600; color: #64748b; text-transform: uppercase;">Em Qualificação</span>
          <div id="kpi-interessados" style="font-size: 24px; font-weight: 700; color: #0f172a; margin-top: 4px;">-</div>
        </div>
        <div class="crm-card" style="padding: 16px; border-left: 4px solid #065f46;">
          <span style="font-size: 12px; font-weight: 600; color: #64748b; text-transform: uppercase;">Convertidos</span>
          <div id="kpi-convertidos" style="font-size: 24px; font-weight: 700; color: #0f172a; margin-top: 4px;">-</div>
        </div>
      </div>

      <!-- Barra de Pesquisa e Filtros -->
      <div class="crm-card" style="padding: 16px; margin-bottom: 20px; display: flex; gap: 12px; flex-wrap: wrap;">
        <input type="text" id="lead-search" placeholder="Pesquisar por nome, telefone ou empresa..." onkeyup="filterLeads()" style="flex: 1; min-width: 250px; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px;">
        <select id="lead-status-filter" onchange="filterLeads()" style="padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px;">
          <option value="">Todos os Status</option>
          <option value="novo">Novo Contato</option>
          <option value="interessado">Interessado</option>
          <option value="orcamento_enviado">Orçamento Enviado</option>
          <option value="aguardando_retorno">Aguardando Retorno</option>
        </select>
      </div>

      <!-- Tabela Principais de Leads -->
      <div id="leads-table-container">
        <div style="text-align: center; padding: 40px; color: #64748b;">Carregando leads...</div>
      </div>
    </div>
  `;

  await fetchAndRenderLeads();
}

async function fetchAndRenderLeads() {
  try {
    const response = await fetch('/api/leads');
    const leads = await response.json();

    // Atualiza KPIs
    document.getElementById('kpi-total-leads').innerText = leads.length;
    document.getElementById('kpi-interessados').innerText = leads.filter(l => l.status === 'interessado').length;
    document.getElementById('kpi-convertidos').innerText = leads.filter(l => l.status === 'fechado').length;

    renderLeadsTable(leads);
  } catch (error) {
    console.error('Erro ao carregar leads:', error);
    document.getElementById('leads-table-container').innerHTML = `
      <div class="crm-card" style="text-align: center; padding: 30px; color: #ef4444;">
        Erro ao carregar os dados dos leads. Verifique a sua conexão ou tente novamente.
      </div>
    `;
  }
}

function renderLeadsTable(leads) {
  const container = document.getElementById('leads-table-container');

  if (!leads || leads.length === 0) {
    container.innerHTML = `
      <div class="crm-card" style="text-align: center; padding: 40px; color: #64748b;">
        <p style="font-weight: 600; font-size: 16px; margin-bottom: 4px;">Nenhum lead encontrado</p>
        <p style="font-size: 14px; margin: 0;">Novos contactos via WhatsApp aparecerão automaticamente nesta lista.</p>
      </div>
    `;
    return;
  }

  let html = `
    <div class="crm-card" style="padding: 0; overflow-x: auto;">
      <table class="crm-table">
        <thead>
          <tr>
            <th>Nome / Empresa</th>
            <th>Contacto</th>
            <th>Origem</th>
            <th>Etapa do Funil</th>
            <th>Última Interação</th>
            <th style="text-align: right;">Ações</th>
          </tr>
        </thead>
        <tbody>
  `;

  leads.forEach(lead => {
    html += `
      <tr>
        <td>
          <div style="font-weight: 600; color: #0f172a;">${lead.name || 'Sem nome'}</div>
          <div style="font-size: 12px; color: #64748b;">${lead.company_name || 'Pessoa Física'}</div>
        </td>
        <td>${lead.phone || '-'}</td>
        <td><span style="font-size: 12px; background: #f1f5f9; padding: 2px 8px; border-radius: 4px; color: #475569;">${lead.source || 'WhatsApp'}</span></td>
        <td><span class="badge badge-${(lead.status || 'novo').toLowerCase()}">${formatStatusLabel(lead.status)}</span></td>
        <td style="font-size: 13px; color: #64748b;">${lead.last_contact_at ? new Date(lead.last_contact_at).toLocaleDateString('pt-BR') : '-'}</td>
        <td style="text-align: right;">
          <button onclick="openLeadDetails('${lead.id}')" style="background: transparent; border: 1px solid #cbd5e1; border-radius: 4px; padding: 4px 10px; color: #0d9488; font-weight: 500; cursor: pointer;">
            Abrir
          </button>
        </td>
      </tr>
    `;
  });

  html += `
        </tbody>
      </table>
    </div>
  `;

  container.innerHTML = html;
}

function formatStatusLabel(status) {
  const map = {
    'novo': 'Novo Contato',
    'interessado': 'Interessado',
    'orcamento_enviado': 'Orçamento Enviado',
    'aguardando_retorno': 'Aguardando Retorno',
    'fechado': 'Fechado',
    'perdido': 'Perdido'
  };
  return map[status] || status || 'Novo Contato';
}