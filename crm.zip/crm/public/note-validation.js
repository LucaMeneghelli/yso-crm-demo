export const duplicateNoteMessage = 'A observação contém uma frase ou um bloco de texto repetido. Revise a duplicação antes de salvar. Seu texto foi mantido.';
const normalize = value => value.normalize('NFC').toLocaleLowerCase('pt-BR').replace(/\s+/gu, ' ').trim();
const enoughWords = value => (value.match(/[\p{L}\p{N}]+/gu) || []).length >= 3;
export function hasDuplicateNote(value) {
  if (typeof value !== 'string' || !value.trim()) return false;
  const words = normalize(value).split(' ');
  // Whole blocks pasted twice or more, even without sentence punctuation.
  for (let size = 3; size <= words.length / 2; size++) {
    if (words.length % size !== 0) continue;
    if (words.every((word, index) => word === words[index % size])) return true;
  }
  const seen = new Set();
  for (const {segment} of new Intl.Segmenter('pt-BR', {granularity:'sentence'}).segment(value)) {
    const sentence = normalize(segment).replace(/[.!?…]+$/u, '').trim();
    if (!enoughWords(sentence)) continue;
    if (seen.has(sentence)) return true;
    seen.add(sentence);
  }
  return false;
}
