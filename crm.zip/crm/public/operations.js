export function nextAction(ticket,today){
 if(['Concluído','Cancelado'].includes(ticket.stage))return {label:'Histórico disponível para consulta',reason:'Atendimento encerrado'};
 const actions={'Novo atendimento':'Confirmar a solicitação e definir o próximo passo','Em avaliação':'Conferir o andamento com a equipe responsável','Aguardando aprovação':'Consultar o cliente sobre a proposta','Em execução':'Conferir andamento e combinar retorno'};
 const reason=!ticket.next_return?'Definir data de retorno':ticket.next_return<today?'Retorno atrasado':ticket.next_return===today?'Retorno previsto para hoje':'Retorno futuro programado';
 return {label:actions[ticket.stage]||'Revisar atendimento com a equipe',reason};
}
export function operationalView({tickets,stages,today,view,escape:esc}){
 const active=t=>!['Concluído','Cancelado'].includes(t.stage);
 const card=t=>`<article class="work-card"><div class="work-card-top"><span>#${t.id}</span><span class="badge">${esc(t.stage)}</span></div><h3>${esc(t.customer_name)}</h3><p>${esc(t.service)}</p><small>${esc(t.owner_name)}</small><div class="next-action"><strong>${esc(nextAction(t,today).reason)}</strong><p>${esc(nextAction(t,today).label)}</p><small>Sugestão administrativa por regra</small></div><p class="${active(t)&&t.next_return<today?'late':''}">${t.next_return?'Retorno: '+esc(t.next_return.split('-').reverse().join('/')):'Encerrado'}</p><button class="secondary" data-ticket="${t.id}">Abrir atendimento ↗</button></article>`;
 const groups=view==='board'?stages.map(stage=>[stage,tickets.filter(t=>t.stage===stage)]):[
 ['Atrasados',tickets.filter(t=>active(t)&&t.next_return<today)],
 ['Hoje',tickets.filter(t=>active(t)&&t.next_return===today)],
 ['Próximos retornos',tickets.filter(t=>active(t)&&t.next_return>today)]];
 return `<div class="work-board ${view==='day'?'work-day':''}">${groups.map(([title,rows])=>`<section class="work-column" aria-label="${esc(title)}"><header><h2>${esc(title)}</h2><span class="count">${rows.length}</span></header>${rows.sort((a,b)=>(a.next_return||'').localeCompare(b.next_return||'')||a.id-b.id).map(card).join('')||'<p class="work-empty">Nenhum atendimento nesta coluna.</p>'}</section>`).join('')}</div>`;
}
