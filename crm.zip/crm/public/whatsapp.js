export function formatPhone(value) {
  const digits=String(value??'').replace(/\D/g,'');
  if(/^55\d{10,11}$/.test(digits)){
    const local=digits.slice(4),split=local.length-4;
    return '+55 ('+digits.slice(2,4)+') '+local.slice(0,split)+'-'+local.slice(split);
  }
  return digits?'+'+digits:'';
}

export function conversationUrl(value) {
  if(typeof value!=='string'||!/^[+\d\s().-]+$/.test(value))throw new Error('Informe apenas o número com código do país e DDD.');
  const digits=value.replace(/\D/g,'');
  if(!/^[1-9]\d{7,14}$/.test(digits))throw new Error('Use o código do país e DDD, sem zero inicial.');
  return `https://wa.me/${digits}`;
}

export function initializeWhatsApp(getCustomers=()=>[]) {
  const dialog=document.querySelector('#whatsapp-dialog');
  const form=document.querySelector('#whatsapp-form');
  const result=document.querySelector('#whatsapp-result');
  const error=document.querySelector('#whatsapp-error');
  const picker=document.querySelector('#whatsapp-customer');
  const contact=document.querySelector('#whatsapp-contact');
  const clear=()=>{form.reset();result.replaceChildren();error.textContent='';};
  document.querySelector('#whatsapp-close').onclick=()=>dialog.close();
  dialog.addEventListener('close',clear);
  form.addEventListener('input',()=>{if(form.elements.phone.value.trim())prepare();else {result.replaceChildren();error.textContent='';}});
  form.elements.phone.addEventListener('blur',()=>{if(form.elements.phone.value.trim()){try{conversationUrl(form.elements.phone.value);form.elements.phone.value=formatPhone(form.elements.phone.value);}catch{}}});
  const prepare=()=>{
    result.replaceChildren();error.textContent='';
    try {
      const link=document.createElement('a');
      link.href=conversationUrl(form.elements.phone.value);
      link.target='_blank';link.rel='noopener noreferrer';link.className='primary whatsapp-link';
      link.textContent='Abrir conversa no WhatsApp ↗';result.append(link);
    }catch(e){error.textContent=e.message;}
  };
  const select=()=>{
    clear();
    const customer=getCustomers().find(c=>String(c.id)===picker.value);
    form.elements.phone.value=formatPhone(customer?.phone);
    contact.textContent=customer ? `${customer.name} · ${formatPhone(customer.phone)||'Sem telefone. Edite o cadastro para salvar o WhatsApp.'}` : 'Escolha um cliente ou informe um telefone para uma conversa avulsa.';
    if(customer?.phone)prepare();
  };
  picker.onchange=select;
  form.onsubmit=event=>{
    event.preventDefault();result.replaceChildren();error.textContent='';
    prepare();
  };
  return (customerId=null)=>{
    picker.replaceChildren(new Option('Selecione um cliente',''));
    for(const customer of getCustomers())picker.append(new Option(customer.name,String(customer.id)));
    picker.value=customerId==null?'':String(customerId);select();dialog.showModal();
  };
}
