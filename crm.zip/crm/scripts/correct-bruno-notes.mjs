// Correção pontual autorizada: somente o texto duplicado das notas 8 e 9.
import assert from 'node:assert/strict';
import { config } from '../src/config.mjs';
import { poolFor } from '../src/db.mjs';

const settings = config();
assert.equal(settings.database, 'yso_crm_demo');
const pool = poolFor(settings);
const client = await pool.connect();
const corrections = new Map([
  [8, 'Cliente fictício relata ruído ao frear. Aguardando avaliação da oficina.'],
  [9, 'Avaliação fictícia iniciada. Rui verificará as pastilhas e os discos para identificar a causa do ruído.'],
]);
try {
  await client.query('BEGIN');
  const ticket = (await client.query('SELECT * FROM tickets WHERE id=5 FOR UPDATE')).rows[0];
  assert.ok(ticket, 'Atendimento não encontrado.');
  assert.equal(ticket.stage, 'Concluído');
  const customer = (await client.query('SELECT * FROM customers WHERE id=$1 FOR SHARE', [ticket.customer_id])).rows[0];
  assert.equal(customer.name, 'Bruno Cliente Demo');
  assert.equal(customer.email, 'bruno.demo@example.com');
  const before = (await client.query('SELECT * FROM notes WHERE ticket_id=5 ORDER BY id FOR UPDATE')).rows;
  let changed = 0;
  for (const [noteId, clean] of corrections) {
    const note = before.find(n => n.id === noteId);
    assert.ok(note, `Nota ${noteId} não encontrada.`);
    if (note.body === clean) continue;
    assert.equal(note.body, `${clean} ${clean}`, `Nota ${noteId} foi alterada; correção interrompida para preservar o conteúdo.`);
    const result = await client.query('UPDATE notes SET body=$1 WHERE id=$2 AND ticket_id=5 AND body=$3', [clean, noteId, note.body]);
    assert.equal(result.rowCount, 1);
    changed++;
  }
  const after = (await client.query('SELECT * FROM notes WHERE ticket_id=5 ORDER BY id')).rows;
  assert.deepEqual(after, before.map(note => corrections.has(note.id) ? {...note, body: corrections.get(note.id)} : note));
  assert.deepEqual((await client.query('SELECT * FROM tickets WHERE id=5')).rows[0], ticket);
  await client.query('COMMIT');
  console.log(JSON.stringify({correctedNotes:changed,ticketId:ticket.id,stage:ticket.stage,notesPreserved:after.length,ticketUnchanged:true,noteDatesUnchanged:true},null,2));
} catch (error) {
  await client.query('ROLLBACK');
  throw error;
} finally {
  client.release();
  await pool.end();
}
