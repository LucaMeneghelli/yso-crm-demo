$ErrorActionPreference = 'Stop'
$crmRoot = Join-Path $env:LOCALAPPDATA 'YSO\crm-demo'
$crmBin = Join-Path $crmRoot 'runtime\pgsql\bin'
$crmData = Join-Path $crmRoot 'pgdata'
if (Test-Path -LiteralPath (Join-Path $crmData 'PG_VERSION')) { Write-Output 'Cluster existente preservado.'; exit 0 }
if (Test-Path -LiteralPath $crmData) { throw 'Diretório de dados já existe; verifique antes de inicializar.' }
$crmUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
& icacls.exe $crmRoot /inheritance:r /grant:r "${crmUser}:(OI)(CI)F" 'SYSTEM:(OI)(CI)F' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Não foi possível proteger a pasta local.' }
$crmPassword = [Convert]::ToHexString([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32)).ToLowerInvariant()
$crmPasswordFile = Join-Path $crmRoot 'init-password.tmp'
try {
  [System.IO.File]::WriteAllText($crmPasswordFile, $crmPassword)
  & (Join-Path $crmBin 'initdb.exe') -D $crmData -U postgres --encoding=UTF8 --locale=C --auth=scram-sha-256 "--pwfile=$crmPasswordFile"
  if ($LASTEXITCODE -ne 0) { throw 'Falha ao inicializar PostgreSQL.' }
  $crmAdmin = @{ host='127.0.0.1'; port=5432; user='postgres'; password=$crmPassword; database='postgres' }
  $crmAdmin | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $crmRoot 'admin.json') -Encoding utf8
  Add-Content -LiteralPath (Join-Path $crmData 'postgresql.conf') -Value "`nlisten_addresses = '127.0.0.1'`nport = 5432`ntimezone = 'America/Sao_Paulo'`n"
  & (Join-Path $crmBin 'pg_ctl.exe') start -D $crmData -l (Join-Path $crmRoot 'postgres.log') -w -t 30
  if ($LASTEXITCODE -ne 0) { throw 'Falha ao iniciar PostgreSQL.' }
  & (Join-Path $crmBin 'pg_isready.exe') -h 127.0.0.1 -p 5432
} finally {
  if (Test-Path -LiteralPath $crmPasswordFile) { Remove-Item -LiteralPath $crmPasswordFile }
  $crmPassword = $null
}
