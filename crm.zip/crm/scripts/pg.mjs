import { spawnSync } from 'node:child_process';
import { join } from 'node:path';
import { localRoot } from '../src/config.mjs';
export const bin = join(localRoot,'runtime','pgsql','bin');
export const dataDir = join(localRoot,'pgdata');
export function pgCommand(name,args,options={}) {
  const result = spawnSync(join(bin,`${name}.exe`),args,{windowsHide:true,encoding:'utf8',...options});
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${name} falhou: ${result.stderr || result.stdout}`);
  return result.stdout;
}
export function ensurePostgres() {
  const status = spawnSync(join(bin,'pg_ctl.exe'),['status','-D',dataDir],{windowsHide:true,stdio:'ignore'});
  if (status.status !== 0) pgCommand('pg_ctl',['start','-D',dataDir,'-l',join(localRoot,'postgres.log'),'-w','-t','30']);
}
