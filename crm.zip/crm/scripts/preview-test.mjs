// Preview only the isolated fixtures produced by npm test. Never uses demo records.
import {config} from '../src/config.mjs';
import {poolFor} from '../src/db.mjs';
import {createApp} from '../src/server.mjs';
const pool=poolFor({...config(),database:'yso_crm_test'});
const server=createApp(pool);
server.listen(3001,'127.0.0.1',()=>console.log('Interface de teste isolada: http://127.0.0.1:3001'));
process.on('SIGINT',()=>server.close(async()=>{await pool.end();process.exit();}));
