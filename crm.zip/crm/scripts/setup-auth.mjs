import {randomBytes} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {config,localRoot} from '../src/config.mjs';
import {poolFor,migrate} from '../src/db.mjs';
import {hashPassword,transaction,audit} from '../src/auth.mjs';
const pool=poolFor(config());
try {
  await migrate(pool);
  const path=join(localRoot,'primeiro-acesso.txt');
  const created=await transaction(pool,async c=>{
    await c.query('SELECT pg_advisory_xact_lock(2561027)');
    if((await c.query('SELECT 1 FROM app_users LIMIT 1')).rowCount)return false;
    const password=randomBytes(18).toString('base64url');
    const user=(await c.query("INSERT INTO app_users(name,email,password_hash,role) VALUES ('Administrador YSO','admin@yso.local',$1,'admin') RETURNING id",[await hashPassword(password)])).rows[0];
    await writeFile(path,`YSO CRM — primeiro acesso local\n\nEndereço: http://127.0.0.1:3000\nE-mail: admin@yso.local\nSenha temporária: ${password}\n\nTroque a senha no primeiro acesso. Não compartilhe este arquivo.\nA senha temporária perde a validade após a troca.\n`,{mode:0o600,flag:'wx'});
    await audit(c,user.id,'admin_bootstrapped','user',user.id);return true;
  });
  console.log(created?`Administrador criado. Credencial temporária disponível somente no arquivo local: ${path}`:'Usuários existentes preservados. Nenhuma senha redefinida.');
}finally{await pool.end();}
