import { randomBytes } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { config, localRoot } from '../src/config.mjs';
import { poolFor, migrate, seed } from '../src/db.mjs';
import { ensurePostgres } from './pg.mjs';
ensurePostgres();
const admin = poolFor(config('admin'));
try {
  let app;
  try { app = config(); } catch { app = {host:'127.0.0.1',port:5432,user:'yso_crm_app',password:randomBytes(32).toString('hex'),database:'yso_crm_demo'}; }
  const role = await admin.query("SELECT 1 FROM pg_roles WHERE rolname='yso_crm_app'");
  if (!role.rowCount) {
    // Password is generated as hex; keep it out of output and process arguments.
    if (!/^[a-f0-9]{64}$/.test(app.password)) throw new Error('Credencial gerada inválida.');
    await admin.query(`CREATE ROLE yso_crm_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD '${app.password}'`);
  }
  await writeFile(join(localRoot,'app.json'),JSON.stringify(app,null,2),{mode:0o600});
  for (const name of ['yso_crm_demo','yso_crm_test']) {
    if (!(await admin.query('SELECT 1 FROM pg_database WHERE datname=$1',[name])).rowCount) await admin.query(`CREATE DATABASE ${name} OWNER yso_crm_app`);
    const pool = poolFor({...app,database:name});
    try { await migrate(pool); if (name === 'yso_crm_demo') await seed(pool); } finally { await pool.end(); }
  }
  console.log('Bases yso_crm_demo e yso_crm_test preparadas. Exemplos fictícios preservados.');
} finally { await admin.end(); }
