import {cloudConfig} from '../src/cloud-config.mjs';
import {poolFor} from '../src/db.mjs';
import {bootstrapCloud} from '../src/cloud-bootstrap.mjs';
import {createApp} from '../src/server.mjs';
import {cloudFailureHint} from '../src/cloud-diagnostics.mjs';
let pool;
try {
  const settings=cloudConfig();
  pool=poolFor(settings.db);
  await bootstrapCloud(pool);
  const server=createApp(pool,{publicOrigin:settings.origin});
  server.on('error',async()=>{console.error('Não foi possível iniciar o servidor online.');await pool.end();process.exitCode=1;});
  server.listen(settings.port,'0.0.0.0',()=>console.log('YSO CRM online: servidor iniciado; dados fictícios e acesso autenticado.'));
  let closing=false;
  const close=()=>{if(closing)return;closing=true;server.close(async()=>{await pool.end();process.exit(0);});setTimeout(()=>process.exit(1),10000).unref();};
  process.on('SIGTERM',close);process.on('SIGINT',close);
}catch(error){
  // Never print connection strings or credential-bearing error details.
  console.error('Inicialização online falhou. Confira conexão TLS, permissões do banco e senhas iniciais no painel. Código:',error.code||error.name);
  console.error(cloudFailureHint(error));
  if(pool)await pool.end();process.exitCode=1;
}
