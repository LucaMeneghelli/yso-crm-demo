import { config,localRoot } from '../src/config.mjs';
import { poolFor,migrate } from '../src/db.mjs';
import { createApp } from '../src/server.mjs';
import { ensurePostgres } from './pg.mjs';
import { writeFile, unlink } from 'node:fs/promises';
import { join } from 'node:path';
ensurePostgres();
const pool = poolFor(config());
if(!(await pool.query('SELECT 1 FROM schema_migrations WHERE version=2')).rowCount) {
  await pool.end();throw new Error('Prepare o login com npm.cmd run setup-auth antes de iniciar.');
}
await migrate(pool);
const server = createApp(pool);
server.on('error',async error=>{console.error(error.code === 'EADDRINUSE' ? 'A porta 3000 já está em uso. Verifique se o CRM já está aberto.' : error.message);await pool.end();process.exitCode=1;});
server.listen(3000,'127.0.0.1',async()=>{
  await writeFile(join(localRoot,'app.pid'),String(process.pid));
  console.log('YSO CRM • Dr. Alexandre Fuzimoto');
  console.log('Local: http://127.0.0.1:3000');
  console.log('Somente dados fictícios. Ctrl+C encerra a aplicação.');
});
async function close() { server.close(async()=>{await pool.end();await unlink(join(localRoot,'app.pid')).catch(()=>{});process.exit(0);}); }
process.on('SIGINT',close);process.on('SIGTERM',close);
