import { pgCommand,dataDir } from './pg.mjs';
console.log('Encerre primeiro a aplicação com Ctrl+C no terminal em que ela foi iniciada.');
console.log(pgCommand('pg_ctl',['stop','-D',dataDir,'-m','fast','-w']));
