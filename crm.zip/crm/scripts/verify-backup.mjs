import { readdir } from 'node:fs/promises';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import { config,localRoot } from '../src/config.mjs';
import { poolFor } from '../src/db.mjs';
import { pgCommand } from './pg.mjs';
const database = `yso_crm_restore_${Date.now()}`;
const admin = poolFor(config('admin'));
const app = config();
const demo = poolFor(app);
let restored;
try {
  if ((await admin.query('SELECT 1 FROM pg_database WHERE datname=$1',[database])).rowCount) throw new Error('A base de restauração já existe; preservada. Inspecione-a antes de repetir.');
  const files=(await readdir(join(localRoot,'backups'))).filter(name=>/^yso-crm-.*\.dump$/.test(name)).sort();
  if(!files.length)throw new Error('Execute npm run backup antes.');
  await admin.query(`CREATE DATABASE ${database} OWNER yso_crm_app`);
  pgCommand('pg_restore',['-h',app.host,'-p',String(app.port),'-U',app.user,'-d',database,'--no-owner','--exit-on-error',join(localRoot,'backups',files.at(-1))],{env:{...process.env,PGPASSWORD:app.password}});
  restored=poolFor({...app,database});
  for(const [table,key] of [['customers','id'],['owners','id'],['tickets','id'],['notes','id'],['app_users','id'],['app_sessions','token_hash'],['auth_attempts','key'],['audit_events','id'],['schema_migrations','version']]) {
    const source=(await demo.query(`SELECT * FROM ${table} ORDER BY ${key}`)).rows;
    const result=(await restored.query(`SELECT * FROM ${table} ORDER BY ${key}`)).rows;
    assert.deepEqual(result,source,`Diferença em ${table}`);
  }
  console.log('Backup restaurado e comparado: registros, usuários, sessões, auditoria e migrações idênticos.');
  console.log(`Base ${database} preservada para consulta. Execute a verificação com o CRM sem operações durante backup e comparação.`);
} finally {await demo.end();await admin.end();if(restored)await restored.end();}
