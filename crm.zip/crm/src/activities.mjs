import {ValidationError,id,text,date} from './rules.mjs';
import {transaction,audit} from './auth.mjs';
export async function activityRoute(pool,user,method,path,input){
 if(path==='/api/activities'&&method==='GET')return {activities:(await pool.query('SELECT a.*,c.name AS customer_name,u.name AS assigned_name FROM activities a JOIN customers c ON c.id=a.customer_id JOIN app_users u ON u.id=a.assigned_to ORDER BY (completed_at IS NOT NULL),due_on,due_time,a.id LIMIT 500')).rows,users:(await pool.query('SELECT id,name FROM app_users WHERE active ORDER BY name')).rows};
 if(path==='/api/activities'&&method==='POST'){
  const customer=id(input.customer_id,'Cliente'),assigned=id(input.assigned_to,'Responsável'),title=text(input.title,'Atividade',200),due=date(input.due_on);
  if(!['Ligação','WhatsApp','E-mail','Reunião','Follow-up','Tarefa'].includes(input.kind)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(input.due_time||''))throw new ValidationError('Informe tipo e horário válidos.');
  return transaction(pool,async c=>{
   if(!(await c.query('SELECT id FROM app_users WHERE id=$1 AND active FOR SHARE',[assigned])).rowCount)throw new ValidationError('Responsável inativo ou inexistente.');
   const row=(await c.query('INSERT INTO activities(customer_id,assigned_to,title,kind,due_on,due_time,created_by) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *',[customer,assigned,title,input.kind,due,input.due_time,user.id])).rows[0];
   await audit(c,user.id,'activity_created','activity',row.id);return row;
  });
 }
 const match=path.match(/^\/api\/activities\/(\d+)\/complete$/);
 if(match&&method==='POST')return transaction(pool,async c=>{
  const row=(await c.query('SELECT * FROM activities WHERE id=$1 FOR UPDATE',[id(match[1],'Atividade')])).rows[0];
  if(!row)throw new ValidationError('Atividade não encontrada.',404);
  if(user.role!=='admin'&&row.assigned_to!==user.id)throw new ValidationError('Somente o responsável ou administrador pode concluir.',403);
  if(!row.completed_at){await c.query('UPDATE activities SET completed_at=now(),completed_by=$1 WHERE id=$2',[user.id,row.id]);await audit(c,user.id,'activity_completed','activity',row.id);}
  return {ok:true};
 });
 throw new ValidationError('Operação não encontrada.',404);
}
