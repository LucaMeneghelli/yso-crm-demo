import {ValidationError,text,id} from './rules.mjs';
export const knowledge={name:'Assistente virtual da clínica',hours:'Segunda a sexta, das 8h às 18h; sábado, das 8h às 12h (horário de Brasília).',address:'Rua Exemplo, 100, Jardim Fictício, São Paulo/SP. Endereço fictício: não se dirija a este local.',services:'Avaliação odontológica, limpeza e orientação sobre agendamento.',mode:'Simulação gratuita por regras. Sem IA externa e sem envio ao WhatsApp.'};
export function suggest(input){
 const s=input.normalize('NFD').replace(/\p{Diacritic}/gu,'').toLowerCase();
 if(/dor|sangr|urgenc|febre|inchac|remedio|medic|diagnost|falta de ar/.test(s))return {human:true,reply:'Não realizo avaliação clínica nem indico tratamentos. Vou encaminhar sua solicitação à equipe. Em caso de urgência, procure atendimento presencial de urgência.'};
 if(/humano|pessoa|atendente|reclam|cancel|reembolso/.test(s))return {human:true,reply:'Vou encaminhar sua conversa à equipe da clínica para continuar o atendimento.'};
 if(/horario|abre|fecha|funciona/.test(s))return {reply:'Na nossa simulação: '+knowledge.hours};
 if(/endereco|onde|localiza|como chegar/.test(s))return {reply:'Endereço de treinamento: '+knowledge.address};
 if(/preco|valor|quanto|custa|desconto/.test(s))return {human:true,reply:'Os valores precisam ser confirmados pela equipe. Vou encaminhar seu pedido, sem informar preços ou descontos não aprovados.'};
 if(/agend|consulta|marcar/.test(s))return {reply:'Para simular um pedido de agendamento, informe um nome fictício, o serviço desejado e sua preferência de dia e período. A equipe precisa confirmar a disponibilidade; nenhum horário está reservado.'};
 if(/servico|limpeza|avaliacao/.test(s))return {reply:'Neste treinamento, atendemos solicitações de '+knowledge.services+' A equipe confirma indicação e disponibilidade.'};
 if(/^(oi|ola|bom dia|boa tarde|boa noite|obrigad)[! .a-z]*$/.test(s))return {reply:'Olá! Sou o Assistente virtual da clínica. Este é um treinamento com dados fictícios. Posso ajudar com horários, endereço, serviços ou pedido de agendamento. Como posso ajudar?'};
 return {human:true,reply:'Não tenho uma resposta aprovada para esse pedido. Vou encaminhar à equipe para confirmar as informações.'};
}
export function bookingReply(message,booking={}){
 const normalized=message.normalize('NFD').replace(/\p{Diacritic}/gu,'').toLowerCase();
 const base=suggest(message);
 if(base.human&&(!booking.step||/dor|sangr|urgenc|febre|inchac|remedio|medic|diagnost|humano|pessoa|atendente|reclam|cancel|reembolso|preco|valor|quanto|custa|desconto|falta de ar/.test(normalized)))return {...base,booking};
 if(!booking.step&&!/agend|marcar|consulta/.test(normalized))return {...base,booking};
 const next={...booking};
 if(!next.step){next.step='name';return {booking:next,reply:'Vamos preparar seu pedido fictício. Qual nome devo registrar? Nenhum horário está reservado.'};}
 const prompts={name:'Qual nome fictício devo registrar?',service:'Você prefere avaliação ou limpeza?',preference:'Qual dia e período você prefere?',confirm:'O resumo está correto? Responda sim ou não.'};
 if(next.step!=='requested'&&/^(corrigir|alterar|trocar) (o |a |meu |minha )?(nome|servico|dia|periodo|horario)/.test(normalized)){
  next.step=/nome/.test(normalized)?'name':/servico/.test(normalized)?'service':'preference';
  return {booking:next,reply:'Claro. '+prompts[next.step]};
 }
 if(/endereco|onde|funciona|abre|fecha|qual.*horario|horario.*funcionamento/.test(normalized))return {...base,booking,reply:base.reply+' '+(prompts[next.step]||'Seu pedido continua com a equipe.')};
 if(/^(oi|ola|obrigad[oa]|bom dia|boa tarde|boa noite)[!. ]*$/.test(normalized))return {booking:next,reply:'Estou por aqui! '+(prompts[next.step]||'Seu pedido continua com a equipe.')};
 if(message.includes('?')&&next.step==='name')return {booking:next,reply:'Para começar o pedido, preciso apenas de um nome fictício. Qual devo usar?'};

 if(next.step==='name'){next.name=message.trim().slice(0,100);next.step='service';return {booking:next,reply:`Obrigado, ${next.name}. Qual serviço você procura: avaliação ou limpeza?`};}
 if(next.step==='service'){
  if(!/limpeza|avaliacao/.test(normalized))return {booking:next,reply:'Neste roteiro podemos solicitar avaliação ou limpeza. Qual você prefere?'};
  next.service=/limpeza/.test(normalized)?'Limpeza':'Avaliação';next.step='preference';return {booking:next,reply:'Qual dia e período você prefere? Exemplo: segunda-feira pela manhã. Funcionamos de segunda a sexta, 8h–18h, e sábado, 8h–12h.'};
 }
 if(next.step==='preference'){
  if(/domingo|noite|madrugada/.test(normalized))return {booking:next,reply:'Esse período está fora do nosso horário fictício. Prefere segunda a sexta, entre 8h e 18h, ou sábado pela manhã?'};
  if(!/segunda|terca|quarta|quinta|sexta|sabado|amanha|hoje|\d{1,2}[/-]\d{1,2}/.test(normalized)||! /\bmanha\b|\btarde\b|\d{1,2}\s*(h|:)/.test(normalized))return {booking:next,reply:'Informe o dia e o período juntos, por exemplo: segunda-feira pela manhã. Isso será uma preferência, sujeita à confirmação da equipe.'};
  next.preference=message.trim().slice(0,200);next.step='confirm';return {booking:next,reply:`Confira o pedido fictício: ${next.name}, ${next.service}, preferência: ${next.preference}. Está correto? Responda sim ou não. A disponibilidade ainda será verificada pela equipe.`};}
 if(next.step==='confirm'){
  if(/^(sim|ok|correto|confirmo)\b/.test(normalized)){next.step='requested';return {booking:next,human:true,reply:'Pedido fictício registrado para a equipe conferir a disponibilidade. Ainda não é um agendamento confirmado. A equipe assume a conversa a partir daqui.'};}
  if(/^(nao|corrigir)\b/.test(normalized)){next.step='name';return {booking:next,reply:'Vamos corrigir o pedido. Qual nome fictício devo registrar?'};}
  return {booking:next,reply:'Está correto? Responda sim para registrar o pedido ou não para corrigir.'};
 }
 return {booking:next,human:true,reply:'Seu pedido está com a equipe, aguardando confirmação de disponibilidade.'};
}
export async function assistantRoute(pool,user,method,path,data={}){
 if(path==='/api/assistant'&&method==='GET')return {knowledge,conversations:(await pool.query('SELECT * FROM assistant_simulations WHERE created_by=$1 ORDER BY id DESC LIMIT 30',[user.id])).rows};
 if(path==='/api/assistant'&&method==='POST')return (await pool.query('INSERT INTO assistant_simulations(created_by) VALUES ($1) RETURNING *',[user.id])).rows[0];
 const match=path.match(/^\/api\/assistant\/(\d+)$/);
 if(!match||method!=='POST')throw new ValidationError('Operação não encontrada.',404);
 const c=await pool.connect();
 try{
  await c.query('BEGIN');
  const row=(await c.query('SELECT * FROM assistant_simulations WHERE id=$1 AND created_by=$2 FOR UPDATE',[id(match[1]),user.id])).rows[0];
  if(!row)throw new ValidationError('Simulação não encontrada.',404);
  if(data.version!==row.version)throw new ValidationError('A conversa mudou. Atualize antes de tentar novamente.',409);
  const add=(role,body)=>row.messages.push({role,body,at:new Date().toISOString()});
  if(row.messages.length>=200)throw new ValidationError('Limite de treinamento atingido. Inicie outra simulação.');
  if(data.action==='message'){
   const message=text(data.text,'Mensagem',1500);add('patient',message);row.pending=null;
   if(!row.human){const result=bookingReply(message,row.booking||{});row.booking=result.booking;row.pending=result.reply;row.human=!!result.human;if(row.human)add('system','Encaminhado à equipe. Assistente pausado.');}
  }else if(data.action==='approve'){
   if(!row.pending)throw new ValidationError('Não há sugestão pendente.',409);
   add('assistant',row.pending);row.pending=null;
  }else if(data.action==='takeover'){row.human=true;row.pending=null;add('system','Equipe assumiu a simulação.');
  }else if(data.action==='resume'){row.human=false;row.pending=null;add('system','Sugestões reativadas para as próximas mensagens.');
  }else if(data.action==='reply'){
   if(!row.human)throw new ValidationError('Assuma a conversa antes de responder.');
   add('team',text(data.text,'Resposta',1500));row.pending=null;
  }else throw new ValidationError('Ação inválida.');
  const updated=(await c.query('UPDATE assistant_simulations SET messages=$1,human=$2,pending=$3,booking=$5,version=version+1 WHERE id=$4 RETURNING *',[JSON.stringify(row.messages),row.human,row.pending,row.id,JSON.stringify(row.booking||{})])).rows[0];
  await c.query('COMMIT');return updated;
 }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
}
