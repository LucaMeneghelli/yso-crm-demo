import {randomBytes, scrypt as derive, timingSafeEqual, createHash} from 'node:crypto';
import {promisify} from 'node:util';
import {ValidationError, text} from './rules.mjs';
const scrypt=promisify(derive);
const digest=value=>createHash('sha256').update(value).digest('hex');
const fields='id,name,email,role,active,must_change_password,created_at';
export const publicUser=user=>Object.fromEntries(fields.split(',').map(k=>[k,user[k]]));
export function emailInput(value) {
  const email=text(value,'E-mail de acesso',150).toLowerCase();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new ValidationError('E-mail de acesso inválido.');
  return email;
}
export async function hashPassword(password) {
  if(typeof password!=='string'||password.length<12||password.length>128||!password.trim())throw new ValidationError('Use uma senha de 12 a 128 caracteres, preferencialmente uma frase longa.');
  const salt=randomBytes(16).toString('hex');
  const hash=await scrypt(password,salt,64,{N:32768,r:8,p:1,maxmem:64*1024*1024});
  return `scrypt:${salt}:${hash.toString('hex')}`;
}
export async function verifyPassword(password,stored) {
  if(typeof password!=='string'||password.length>128)return false;
  const [method,salt,hash]=String(stored).split(':');
  if(method!=='scrypt'||!salt||!hash)return false;
  const result=await scrypt(password,salt,64,{N:32768,r:8,p:1,maxmem:64*1024*1024});
  const expected=Buffer.from(hash,'hex');
  return result.length===expected.length&&timingSafeEqual(result,expected);
}
function token(req) {
  const raw=(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('yso_session='))?.slice(12);
  return raw&&/^[a-f0-9]{64}$/.test(raw)?raw:null;
}
export function clearCookie(res) {res.setHeader('Set-Cookie',`yso_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${res.crmSecure?'; Secure':''}`);}
export async function audit(db,actor,action,type,target=null) {
  await db.query('INSERT INTO audit_events(actor_id,action,target_type,target_id) VALUES ($1,$2,$3,$4)',[actor,action,type,target]);
}
export async function transaction(pool,fn) {
  const c=await pool.connect();
  try {await c.query('BEGIN');const result=await fn(c);await c.query('COMMIT');return result;}
  catch(error){await c.query('ROLLBACK');throw error;}finally{c.release();}
}
async function limit(pool,key,maximum) {
  const result=await pool.query(`INSERT INTO auth_attempts(key,attempts) VALUES ($1,1)
    ON CONFLICT(key) DO UPDATE SET attempts=CASE WHEN auth_attempts.window_start<now()-interval '15 minutes' THEN 1 ELSE auth_attempts.attempts+1 END,
    window_start=CASE WHEN auth_attempts.window_start<now()-interval '15 minutes' THEN now() ELSE auth_attempts.window_start END RETURNING attempts`,[digest(key)]);
  if(result.rows[0].attempts>maximum)throw new ValidationError('Muitas tentativas. Aguarde 15 minutos antes de tentar novamente.',429);
}
export async function requireUser(pool,req) {
  const raw=token(req);
  if(!raw)throw new ValidationError('Entre com sua conta para acessar o CRM.',401);
  const user=(await pool.query(`SELECT u.*,s.token_hash FROM app_sessions s JOIN app_users u ON u.id=s.user_id
    WHERE s.token_hash=$1 AND u.active AND s.expires_at>now() AND s.last_seen_at>now()-interval '30 minutes'`,[digest(raw)])).rows[0];
  if(!user)throw new ValidationError('Sua sessão terminou. Entre novamente.',401);
  // Polling does not prolong an idle session; only user-initiated API calls do.
  if(req.headers['x-yso-background']!=='1')await pool.query('UPDATE app_sessions SET last_seen_at=now() WHERE token_hash=$1',[digest(raw)]);
  return user;
}
export function requireAdmin(user) {if(user.role!=='admin')throw new ValidationError('Somente administradores podem gerenciar acessos.',403);}
export async function login(pool,req,res,input) {
  await limit(pool,`ip:${req.socket.remoteAddress}`,50);
  const email=emailInput(input.email);
  await limit(pool,`email:${email}`,10);
  const user=(await pool.query('SELECT * FROM app_users WHERE email=$1',[email])).rows[0];
  const valid=await verifyPassword(input.password,user?.password_hash||`scrypt:${'0'.repeat(32)}:${'0'.repeat(128)}`);
  if(!user||!user.active||!valid)throw new ValidationError('E-mail ou senha inválidos.',401);
  const raw=randomBytes(32).toString('hex');
  const latest=await transaction(pool,async c=>{
    const current=(await c.query('SELECT * FROM app_users WHERE id=$1 FOR UPDATE',[user.id])).rows[0];
    if(!current.active||current.password_hash!==user.password_hash)throw new ValidationError('E-mail ou senha inválidos.',401);
    const previous=token(req);if(previous)await c.query('DELETE FROM app_sessions WHERE token_hash=$1',[digest(previous)]);
    await c.query("DELETE FROM app_sessions WHERE expires_at<=now() OR last_seen_at<=now()-interval '30 minutes'");
    await c.query("INSERT INTO app_sessions(token_hash,user_id,expires_at) VALUES ($1,$2,now()+interval '8 hours')",[digest(raw),user.id]);
    await audit(c,user.id,'login','user',user.id);return current;
  });
  // The application is loopback-only HTTP; HTTPS deployment must add Secure.
  res.setHeader('Set-Cookie',`yso_session=${raw}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${res.crmSecure?'; Secure':''}`);
  return publicUser(latest);
}
export async function logout(pool,req,res) {
  const raw=token(req);if(raw)await pool.query('DELETE FROM app_sessions WHERE token_hash=$1',[digest(raw)]);
  clearCookie(res);
}
export async function changePassword(pool,user,input) {
  await limit(pool,`change:${user.id}`,10);
  if(!await verifyPassword(input.current_password,user.password_hash))throw new ValidationError('Senha atual incorreta.');
  if(input.new_password===input.current_password)throw new ValidationError('Escolha uma senha diferente da atual.');
  const hash=await hashPassword(input.new_password);
  await transaction(pool,async c=>{
    const result=await c.query('UPDATE app_users SET password_hash=$1,must_change_password=false WHERE id=$2 AND password_hash=$3 AND active RETURNING id',[hash,user.id,user.password_hash]);
    if(!result.rowCount)throw new ValidationError('O acesso mudou. Entre novamente.',401);
    await c.query('DELETE FROM app_sessions WHERE user_id=$1',[user.id]);
    await audit(c,user.id,'password_changed','user',user.id);
  });
}
export async function listUsers(pool){return (await pool.query(`SELECT ${fields} FROM app_users ORDER BY id`)).rows;}
export async function createUser(pool,actor,input) {
  const name=text(input.name,'Nome',100),email=emailInput(input.email);
  if(!['admin','attendant'].includes(input.role))throw new ValidationError('Perfil inválido.');
  const hash=await hashPassword(input.password);
  return transaction(pool,async c=>{
    await c.query('SELECT pg_advisory_xact_lock(2561027)');
    await checkActor(c,actor);
    const user=(await c.query(`INSERT INTO app_users(name,email,password_hash,role) VALUES ($1,$2,$3,$4) RETURNING ${fields}`,[name,email,hash,input.role])).rows[0];
    await audit(c,actor.id,'user_created','user',user.id);return user;
  });
}
async function checkActor(c,actor) {
  const current=(await c.query('SELECT role,active,must_change_password FROM app_users WHERE id=$1 FOR SHARE',[actor.id])).rows[0];
  if(!current?.active||current.role!=='admin'||current.must_change_password)throw new ValidationError('Seu acesso administrativo mudou. Entre novamente.',403);
}
export async function updateUser(pool,actor,target,input) {
  if(!['admin','attendant'].includes(input.role)||typeof input.active!=='boolean')throw new ValidationError('Informe perfil e situação válidos.');
  if(target===actor.id&&(!input.active||input.role!=='admin'))throw new ValidationError('Você não pode remover seu próprio acesso administrativo.');
  return transaction(pool,async c=>{
    await c.query('SELECT pg_advisory_xact_lock(2561027)');
    await checkActor(c,actor);
    const old=(await c.query('SELECT * FROM app_users WHERE id=$1 FOR UPDATE',[target])).rows[0];
    if(!old)throw new ValidationError('Usuário não encontrado.',404);
    if(old.active&&old.role==='admin'&&(!input.active||input.role!=='admin')) {
      const n=(await c.query("SELECT count(*)::int AS n FROM app_users WHERE active AND role='admin'")).rows[0].n;
      if(n<=1)throw new ValidationError('Mantenha ao menos um administrador ativo.');
    }
    const result=(await c.query(`UPDATE app_users SET role=$1,active=$2 WHERE id=$3 RETURNING ${fields}`,[input.role,input.active,target])).rows[0];
    await c.query('DELETE FROM app_sessions WHERE user_id=$1',[target]);
    await audit(c,actor.id,'user_access_updated','user',target);return result;
  });
}
export async function resetPassword(pool,actor,target,input) {
  if(target===actor.id)throw new ValidationError('Use Minha senha para alterar sua própria senha.');
  const hash=await hashPassword(input.password);
  await transaction(pool,async c=>{
    await c.query('SELECT pg_advisory_xact_lock(2561027)');await checkActor(c,actor);
    const result=await c.query('UPDATE app_users SET password_hash=$1,must_change_password=true WHERE id=$2 RETURNING id',[hash,target]);
    if(!result.rowCount)throw new ValidationError('Usuário não encontrado.',404);
    await c.query('DELETE FROM app_sessions WHERE user_id=$1',[target]);
    await audit(c,actor.id,'password_reset','user',target);
  });
}
