import {migrate} from './db.mjs';
import {hashPassword,transaction,audit} from './auth.mjs';
import {today} from './rules.mjs';

export async function bootstrapCloud(pool,env=process.env) {
  // Separate, non-exposed schema: never put passwords/sessions in Supabase public.
  await pool.query('CREATE SCHEMA IF NOT EXISTS yso_crm');
  await pool.query('REVOKE ALL ON SCHEMA yso_crm FROM PUBLIC');
  await migrate(pool);
  await transaction(pool,async c=>{
    await c.query('SELECT pg_advisory_xact_lock(2561027)');
    if(!(await c.query('SELECT 1 FROM app_users LIMIT 1')).rowCount) {
      const accounts=[['Administrador YSO','admin@yso.local','admin',env.DEMO_ADMIN_PASSWORD],['Recepção','atendente@yso.local','attendant',env.DEMO_ATTENDANT_PASSWORD]];
      if(accounts[0][3]===accounts[1][3])throw new Error('Defina senhas iniciais diferentes para as duas contas.');
      for(const [name,email,role,password] of accounts) {
        const user=(await c.query('INSERT INTO app_users(name,email,role,password_hash) VALUES ($1,$2,$3,$4) RETURNING id',[name,email,role,await hashPassword(password)])).rows[0];
        await audit(c,user.id,'admin_bootstrapped','user',user.id);
      }
    }
    // Re-deploys preserve all existing users, passwords and demonstrations.
    await c.query("INSERT INTO owners(name) SELECT 'Recepção' WHERE NOT EXISTS (SELECT 1 FROM owners)");
    if(env.SEED_DEMO_DATA==='true'&&!(await c.query('SELECT 1 FROM customers LIMIT 1')).rowCount) {
      await c.query("INSERT INTO owners(name) VALUES ('Recepção Demo'),('YSO Demo') ON CONFLICT DO NOTHING");
      const owner=(await c.query('SELECT id FROM owners ORDER BY id LIMIT 1')).rows[0].id;
      const customer=(await c.query("INSERT INTO customers(name,email) VALUES ('Ana Recepção Demo','ana.recepcao@example.com') RETURNING id")).rows[0].id;
      const ticket=(await c.query("INSERT INTO tickets(customer_id,service,owner_id,next_return) VALUES ($1,'Solicitação de agendamento — simulação',$2,$3) RETURNING id",[customer,owner,today()])).rows[0].id;
      await c.query("INSERT INTO notes(ticket_id,body) VALUES ($1,'Solicitação administrativa fictícia recebida. Aguardando preferência de horário.')",[ticket]);
    }
  });
  await pool.query('REVOKE ALL ON ALL TABLES IN SCHEMA yso_crm FROM PUBLIC');
  await pool.query('REVOKE ALL ON ALL SEQUENCES IN SCHEMA yso_crm FROM PUBLIC');
  for(const role of ['anon','authenticated']) {
    if((await pool.query('SELECT 1 FROM pg_roles WHERE rolname=$1',[role])).rowCount) {
      await pool.query(`REVOKE ALL ON SCHEMA yso_crm FROM ${role}`);
      await pool.query(`REVOKE ALL ON ALL TABLES IN SCHEMA yso_crm FROM ${role}`);
      await pool.query(`REVOKE ALL ON ALL SEQUENCES IN SCHEMA yso_crm FROM ${role}`);
    }
  }
}
