// Explicit cloud entry point: local scripts never read these settings.
export function cloudConfig(env=process.env) {
  const rawOrigin=env.PUBLIC_ORIGIN || env.RENDER_EXTERNAL_URL;
  let origin,db;
  try {origin=new URL(rawOrigin);db=new URL(env.DATABASE_URL);}catch{throw new Error('Configure PUBLIC_ORIGIN e DATABASE_URL no painel da hospedagem.');}
  if(origin.protocol!=='https:'||origin.username||origin.password||origin.pathname!=='/'||origin.search||origin.hash)throw new Error('PUBLIC_ORIGIN deve conter somente a origem HTTPS do CRM.');
  if(!['postgres:','postgresql:'].includes(db.protocol)||!db.hostname||!db.username||!db.password||db.pathname==='/')throw new Error('DATABASE_URL deve ser a conexão PostgreSQL privada.');
  // pg connectionString SSL parameters can override the explicit certificate policy.
  if(db.search)throw new Error('Remova parâmetros da DATABASE_URL; TLS é configurado pela aplicação.');
  const port=Number(env.PORT||10000);
  if(!Number.isInteger(port)||port<1||port>65535)throw new Error('PORT inválida.');
  return {origin:origin.origin,port,db:{
    connectionString:db.href,ssl:{rejectUnauthorized:true,...(env.DATABASE_CA_CERT?{ca:env.DATABASE_CA_CERT.replace(/\\n/g,'\n')}:{})},
    options:'-c search_path=yso_crm,pg_catalog',
  }};
}
