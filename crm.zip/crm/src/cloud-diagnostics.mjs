// Only emit fixed messages: database errors can contain connection credentials.
export function cloudFailureHint(error) {
  const message=String(error?.message||'');
  if(/tenant or user not found/i.test(message))return 'POOLER_TENANT: confira host e usuario do Session pooler no painel Supabase.';
  if(/password authentication failed|wrong password|invalid password|SASL.*password/i.test(message))return 'DB_PASSWORD: confira a senha e sua codificacao na DATABASE_URL.';
  if(/unsupported.*(startup|parameter)|invalid.*search_path/i.test(message))return 'POOLER_OPTIONS: parametros de inicializacao recusados pelo pooler.';
  if(/certificate|self.signed/i.test(message))return 'DB_TLS: confira DATABASE_CA_CERT oficial.';
  if(/senhas iniciais diferentes|senha.*(12|128)/i.test(message))return 'DEMO_PASSWORD: confira as duas senhas iniciais, diferentes e entre 12 e 128 caracteres.';
  return 'Confira configuracao privada e disponibilidade do banco; detalhes sensiveis omitidos.';
}
