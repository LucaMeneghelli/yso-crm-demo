import { readFileSync } from 'node:fs';
import { join } from 'node:path';
export const localRoot = join(process.env.LOCALAPPDATA || process.env.HOME, 'YSO', 'crm-demo');
export function config(kind = 'app') {
  try { return JSON.parse(readFileSync(join(localRoot, `${kind}.json`), 'utf8').replace(/^\uFEFF/, '')); }
  catch { throw new Error('Configuração local não encontrada. Consulte o README para preparar o PostgreSQL.'); }
}
