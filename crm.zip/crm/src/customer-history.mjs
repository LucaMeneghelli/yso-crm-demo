import {ValidationError,date} from './rules.mjs';
import {transaction} from './auth.mjs';
export async function customerHistory(pool,customerId,filters={}){
 const kind=filters.kind||'',from=filters.from?date(filters.from):null,to=filters.to?date(filters.to):null;
 if(!['','note','charge','payment','ticket','activity'].includes(kind)||(from&&to&&from>to))throw new ValidationError('Filtros inválidos.');
 return transaction(pool,async c=>{
  await c.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');
  const customer=(await c.query('SELECT id,name,email,phone,created_at FROM customers WHERE id=$1',[customerId])).rows[0];
  if(!customer)throw new ValidationError('Cliente não encontrado.',404);
  const tickets=(await c.query('SELECT t.*,o.name AS owner_name FROM tickets t JOIN owners o ON o.id=t.owner_id WHERE t.customer_id=$1 ORDER BY t.id DESC',[customerId])).rows;
  const events=(await c.query(`SELECT * FROM (
   SELECT 'note' AS kind,n.id,n.ticket_id,n.created_at AS at,n.body AS description,NULL::integer AS amount,false AS voided,u.name AS author FROM notes n JOIN tickets t ON t.id=n.ticket_id LEFT JOIN app_users u ON u.id=n.author_id WHERE t.customer_id=$1
   UNION ALL SELECT 'charge',f.id,f.ticket_id,f.created_at,'Cobrança registrada',f.amount,false,u.name FROM finance_charges f JOIN tickets t ON t.id=f.ticket_id LEFT JOIN app_users u ON u.id=f.created_by WHERE t.customer_id=$1
   UNION ALL SELECT 'payment',p.id,f.ticket_id,p.created_at,'Pagamento · '||p.method||' · data: '||p.paid_on::text,p.amount,p.voided,u.name FROM finance_payments p JOIN finance_installments i ON i.id=p.installment_id JOIN finance_charges f ON f.id=i.charge_id JOIN tickets t ON t.id=f.ticket_id LEFT JOIN app_users u ON u.id=p.created_by WHERE t.customer_id=$1
   UNION ALL SELECT 'ticket',t.id,t.id,t.created_at,'Atendimento aberto: '||t.service,NULL::integer,false,NULL::text FROM tickets t WHERE t.customer_id=$1
   UNION ALL SELECT 'activity',a.id,NULL::integer,a.created_at,'Atividade criada: '||a.title,NULL::integer,false,u.name FROM activities a LEFT JOIN app_users u ON u.id=a.created_by WHERE a.customer_id=$1
   UNION ALL SELECT 'activity',a.id,NULL::integer,a.completed_at,'Atividade concluída: '||a.title,NULL::integer,false,u.name FROM activities a LEFT JOIN app_users u ON u.id=a.completed_by WHERE a.customer_id=$1 AND a.completed_at IS NOT NULL
  ) e WHERE ($2='' OR kind=$2) AND ($3::date IS NULL OR (at AT TIME ZONE 'America/Sao_Paulo')::date >= $3) AND ($4::date IS NULL OR (at AT TIME ZONE 'America/Sao_Paulo')::date <= $4) ORDER BY at DESC,kind,id DESC LIMIT 200`,[customerId,kind,from,to])).rows;
  return {customer,tickets,events,limit:200};
 });
}
