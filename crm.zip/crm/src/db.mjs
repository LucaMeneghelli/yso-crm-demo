import pg from 'pg';
import { readFile } from 'node:fs/promises';
import { today } from './rules.mjs';
pg.types.setTypeParser(1082, value => value);
export function poolFor(settings) { return new pg.Pool({...settings, max:5, connectionTimeoutMillis:4000}); }
export async function migrate(pool) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT pg_advisory_xact_lock(2561026)');
    await client.query(await readFile(new URL('../migrations/001-initial.sql', import.meta.url), 'utf8'));
    await client.query(await readFile(new URL('../migrations/002-auth.sql', import.meta.url), 'utf8'));
    await client.query(await readFile(new URL('../migrations/003-customer-phone.sql', import.meta.url), 'utf8'));
    await client.query(await readFile(new URL('../migrations/004-finance.sql', import.meta.url), 'utf8'));
    await client.query(await readFile(new URL('../migrations/005-assistant.sql', import.meta.url), 'utf8'));
    await client.query(await readFile(new URL('../migrations/006-booking.sql', import.meta.url), 'utf8'));
    await client.query(await readFile(new URL('../migrations/007-activities.sql', import.meta.url), 'utf8'));
    await client.query(await readFile(new URL('../migrations/008-leads.sql', import.meta.url), 'utf8'));
    await client.query('COMMIT');
  } catch (error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}
export async function seed(pool) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    await c.query('SELECT pg_advisory_xact_lock(2561026)');
    await c.query("INSERT INTO owners(name) VALUES ('Bia Demo'),('Rui Demo') ON CONFLICT DO NOTHING");
    const existing = await c.query('SELECT count(*)::int AS n FROM customers');
    if (!existing.rows[0].n) {
      const owners = (await c.query('SELECT id FROM owners ORDER BY id')).rows;
      const day = today();
      const shifted = delta => { const d = new Date(`${day}T12:00:00Z`); d.setUTCDate(d.getUTCDate()+delta); return d.toISOString().slice(0,10); };
      const samples = [
        ['Marina Cliente Demo','marina.demo@example.com','Avaliação de ruído nos freios','Novo atendimento',owners[0].id,day,'Cliente fictícia solicita avaliação dos freios.'],
        ['Pedro Cliente Demo','pedro.demo@example.com','Revisão preventiva','Aguardando aprovação',owners[1].id,shifted(1),'Avaliação simulada concluída. Proposta: revisão preventiva. Aguardando aprovação fictícia.'],
        ['Carla Cliente Demo','carla.demo@example.com','Avaliação de ruído na suspensão','Em avaliação',owners[1].id,shifted(-1),'Avaliação simulada em andamento. Retorno anterior pendente.']
      ];
      for (const [name,email,service,stage,owner,returnDate,note] of samples) {
        const customer = (await c.query('INSERT INTO customers(name,email) VALUES ($1,$2) RETURNING id',[name,email])).rows[0];
        const ticket = (await c.query('INSERT INTO tickets(customer_id,service,stage,owner_id,next_return) VALUES ($1,$2,$3,$4,$5) RETURNING id',[customer.id,service,stage,owner,returnDate])).rows[0];
        await c.query('INSERT INTO notes(ticket_id,body) VALUES ($1,$2)',[ticket.id,note]);
      }
    }
    await c.query('COMMIT');
  } catch (error) { await c.query('ROLLBACK'); throw error; }
  finally { c.release(); }
}

