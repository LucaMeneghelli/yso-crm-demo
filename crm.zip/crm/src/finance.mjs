import {ValidationError,id,date,text,today} from './rules.mjs';
import {transaction,audit,requireAdmin} from './auth.mjs';
export function cents(value){
 if(typeof value!=='string'||!/^\d{1,7}([.,]\d{1,2})?$/.test(value))throw new ValidationError('Informe um valor positivo com até duas casas decimais.');
 const [whole,part='']=value.replace(',','.').split('.');const result=Number(whole)*100+Number(part.padEnd(2,'0'));
 if(result<=0||result>100000000)throw new ValidationError('Valor deve estar entre R$ 0,01 e R$ 1.000.000,00.');return result;
}
export function schedule(amount,count,first){
 if(!Number.isInteger(count)||count<1||count>36||count>amount)throw new ValidationError('Escolha de 1 a 36 parcelas, com pelo menos um centavo por parcela.');
 date(first);const [y,m,d]=first.split('-').map(Number);
 return Array.from({length:count},(_,i)=>{const end=new Date(Date.UTC(y,m+i,0));const due=new Date(Date.UTC(y,m-1+i,Math.min(d,end.getUTCDate())));return {number:i+1,amount:Math.floor(amount/count)+(i<amount%count?1:0),due_on:due.toISOString().slice(0,10)};});
}
const key=value=>{if(typeof value!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value))throw new ValidationError('Atualize o formulário antes de salvar.');return value;};
const pastDate=value=>{date(value);if(value>today())throw new ValidationError('Recebimentos e despesas pagos não podem ter data futura.');return value;};
export async function financeRoute(pool,user,method,path,url,input){
 const admin=user.role==='admin';
 if(path==='/api/finance'&&method==='GET'){
  const from=date(url.searchParams.get('from')||today().slice(0,8)+'01'),to=date(url.searchParams.get('to')||today());
  if(from>to)throw new ValidationError('O início deve ser anterior ao fim do período.');
  return transaction(pool,async c=>{
   await c.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');
   const charges=(await c.query(`SELECT f.*,t.service,t.stage,c.name AS customer_name FROM finance_charges f JOIN tickets t ON t.id=f.ticket_id JOIN customers c ON c.id=t.customer_id ORDER BY f.id DESC`)).rows;
   const installments=(await c.query(`SELECT i.*,COALESCE(sum(p.amount) FILTER(WHERE NOT p.voided),0)::bigint AS received FROM finance_installments i LEFT JOIN finance_payments p ON p.installment_id=i.id GROUP BY i.id ORDER BY i.due_on,i.id`)).rows.map(i=>({...i,received:Number(i.received)}));
   const payments=(await c.query('SELECT id,installment_id,amount,paid_on,method,voided FROM finance_payments ORDER BY id DESC')).rows;
   const periodCharges=charges.filter(f=>f.issued_on>=from&&f.issued_on<=to);
   const due=installments.filter(i=>i.due_on>=from&&i.due_on<=to);
   const received=payments.filter(p=>!p.voided&&p.paid_on>=from&&p.paid_on<=to).reduce((n,p)=>n+p.amount,0);
   const result={from,to,charges,installments,payments,summary:{billed:periodCharges.reduce((n,f)=>n+f.amount,0),received,outstanding:due.reduce((n,i)=>n+i.amount-i.received,0),overdue:due.filter(i=>i.due_on<today()).reduce((n,i)=>n+i.amount-i.received,0),count:periodCharges.length}};
   if(admin){
    result.expenses=(await c.query('SELECT id,ticket_id,category,description,amount,paid_on,voided FROM finance_expenses ORDER BY id DESC')).rows;
    const expenses=result.expenses.filter(e=>!e.voided&&e.paid_on>=from&&e.paid_on<=to);
    result.summary.directCosts=expenses.filter(e=>e.ticket_id).reduce((n,e)=>n+e.amount,0);
    result.summary.generalExpenses=expenses.filter(e=>!e.ticket_id).reduce((n,e)=>n+e.amount,0);
    result.summary.cashResult=received-result.summary.directCosts-result.summary.generalExpenses;
    result.serviceResults=periodCharges.map(f=>{const cost=result.expenses.filter(e=>!e.voided&&e.ticket_id===f.ticket_id).reduce((n,e)=>n+e.amount,0);return {ticket_id:f.ticket_id,customer_name:f.customer_name,service:f.service,stage:f.stage,amount:f.amount,cost,result:f.amount-cost};});
   }
   return result;
  });
 }
 if(path==='/api/finance/charges'&&method==='POST'){
  const amount=cents(input.amount),ticket=id(input.ticket_id,'Atendimento'),issued=pastDate(input.issued_on),parts=schedule(amount,Number(input.count),input.first_due);
  return transaction(pool,async c=>{
   const t=(await c.query('SELECT id,stage FROM tickets WHERE id=$1 FOR UPDATE',[ticket])).rows[0];if(!t)throw new ValidationError('Atendimento não encontrado.',404);
   if(t.stage==='Cancelado')throw new ValidationError('Não é possível cobrar atendimento cancelado.');
   if((await c.query('SELECT id FROM finance_charges WHERE ticket_id=$1',[ticket])).rowCount)throw new ValidationError('Este atendimento já tem cobrança.',409);
   const f=(await c.query('INSERT INTO finance_charges(ticket_id,amount,issued_on,created_by) VALUES($1,$2,$3,$4) RETURNING id',[ticket,amount,issued,user.id])).rows[0];
   for(const p of parts)await c.query('INSERT INTO finance_installments(charge_id,number,amount,due_on) VALUES($1,$2,$3,$4)',[f.id,p.number,p.amount,p.due_on]);
   await audit(c,user.id,'charge_created','charge',f.id);return {ok:true};
  });
 }
 if(path==='/api/finance/payments'&&method==='POST'){
  const amount=cents(input.amount),installment=id(input.installment_id,'Parcela'),paid=pastDate(input.paid_on),request=key(input.request_id);
  if(!['Pix','Dinheiro','Cartão','Transferência','Outro'].includes(input.method))throw new ValidationError('Selecione a forma de pagamento.');
  return transaction(pool,async c=>{
   const i=(await c.query('SELECT * FROM finance_installments WHERE id=$1 FOR UPDATE',[installment])).rows[0];if(!i)throw new ValidationError('Parcela não encontrada.',404);
   if((await c.query('SELECT id FROM finance_payments WHERE request_id=$1',[request])).rowCount)return {ok:true};
   const paidSoFar=Number((await c.query('SELECT COALESCE(sum(amount),0) AS total FROM finance_payments WHERE installment_id=$1 AND NOT voided',[installment])).rows[0].total);
   if(amount>i.amount-paidSoFar)throw new ValidationError('O pagamento excede o saldo da parcela. Atualize a tela.',409);
   const p=(await c.query('INSERT INTO finance_payments(installment_id,amount,paid_on,method,request_id,created_by) VALUES($1,$2,$3,$4,$5,$6) RETURNING id',[installment,amount,paid,input.method,request,user.id])).rows[0];
   await audit(c,user.id,'payment_received','payment',p.id);return {ok:true};
  });
 }
 if(path==='/api/finance/expenses'&&method==='POST'){
  requireAdmin(user);const amount=cents(input.amount),paid=pastDate(input.paid_on),request=key(input.request_id),description=text(input.description,'Descrição',200),category=text(input.category,'Categoria',60),ticket=input.ticket_id?id(input.ticket_id,'Atendimento'):null;
  return transaction(pool,async c=>{
   const e=(await c.query('INSERT INTO finance_expenses(ticket_id,category,description,amount,paid_on,request_id,created_by) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(request_id) DO NOTHING RETURNING id',[ticket,category,description,amount,paid,request,user.id])).rows[0];
   if(e)await audit(c,user.id,'expense_created','expense',e.id);return {ok:true};
  });
 }
 const cancel=path.match(/^\/api\/finance\/(payments|expenses)\/(\d+)\/void$/);
 if(cancel&&method==='POST'){
  requireAdmin(user);const reason=text(input.reason,'Motivo do estorno',200),target=id(cancel[2],'Lançamento'),table=cancel[1]==='payments'?'finance_payments':'finance_expenses';
  return transaction(pool,async c=>{const r=await c.query(`UPDATE ${table} SET voided=true,void_reason=$1 WHERE id=$2 AND NOT voided RETURNING id`,[reason,target]);if(!r.rowCount)throw new ValidationError('Lançamento inexistente ou já estornado.',409);await audit(c,user.id,'entry_voided',cancel[1],target);return {ok:true};});
 }
 throw new ValidationError('Operação financeira não encontrada.',404);
}
