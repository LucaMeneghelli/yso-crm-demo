import {customerInput,id,text,ValidationError} from './rules.mjs';
import {transaction,audit} from './auth.mjs';
export const leadStatuses=['Novo','Em contato','Qualificado','Descartado'];
export async function leadRoute(pool,user,method,path,input){
 if(path==='/api/leads'&&method==='GET')return {leads:(await pool.query('SELECT l.*,u.name AS assigned_name FROM leads l JOIN app_users u ON u.id=l.assigned_to ORDER BY l.created_at DESC,l.id DESC LIMIT 500')).rows,users:(await pool.query('SELECT id,name FROM app_users WHERE active ORDER BY name')).rows};
 const match=path.match(/^\/api\/leads\/(\d+)$/);
 if(method==='POST'&&(path==='/api/leads'||match)){
  const contact=customerInput(input),assigned=id(input.assigned_to,'Responsável');
  const optional=(value,label,max)=>value==null||value===''?'':text(value,label,max);
  const company=optional(input.company,'Empresa',150),source=optional(input.source,'Origem',100),interest=optional(input.interest,'Interesse',1000);
  if(!leadStatuses.includes(input.status))throw new ValidationError('Situação inválida.');
  return transaction(pool,async c=>{
   if(!(await c.query('SELECT id FROM app_users WHERE id=$1 AND active FOR SHARE',[assigned])).rowCount)throw new ValidationError('Escolha um responsável ativo.');
   const values=[contact.name,contact.email,contact.phone,company,source,interest,input.status,assigned];let row;
   if(match){
    row=(await c.query('UPDATE leads SET name=$1,email=$2,phone=$3,company=$4,source=$5,interest=$6,status=$7,assigned_to=$8,version=version+1,updated_at=now() WHERE id=$9 AND version=$10 RETURNING *',[...values,id(match[1],'Lead'),id(input.version,'Versão')])).rows[0];
    if(!row)throw new ValidationError('Lead alterado ou não encontrado. Atualize a lista antes de salvar.',409);
   }else row=(await c.query('INSERT INTO leads(name,email,phone,company,source,interest,status,assigned_to,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *',[...values,user.id])).rows[0];
   await audit(c,user.id,match?'lead_updated':'lead_created','lead',row.id);return row;
  });
 }
 throw new ValidationError('Operação não encontrada.',404);
}
