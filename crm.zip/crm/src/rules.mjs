import {hasDuplicateNote, duplicateNoteMessage} from '../public/note-validation.js';
import {conversationUrl} from '../public/whatsapp.js';
export const stages = ['Novo atendimento', 'Em avaliação', 'Aguardando aprovação', 'Em execução', 'Concluído', 'Cancelado'];
export const closed = stage => ['Concluído', 'Cancelado'].includes(stage);
export class ValidationError extends Error { constructor(message, status = 400) { super(message); this.status = status; } }
export function today(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {timeZone:'America/Sao_Paulo', year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now);
  const get = name => parts.find(p => p.type === name).value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}
export function text(value, label, max = 500) {
  if (typeof value !== 'string' || !value.trim()) throw new ValidationError(`${label}: preencha este campo.`);
  if (value.trim().length > max) throw new ValidationError(`${label}: limite de ${max} caracteres.`);
  return value.trim();
}
export function id(value, label) {
  if (!Number.isSafeInteger(Number(value)) || Number(value) <= 0) throw new ValidationError(`${label}: selecione uma opção válida.`);
  return Number(value);
}
export function customerInput(input) {
  const name = text(input.name, 'Nome', 100);
  const email = text(input.email, 'E-mail', 150).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new ValidationError('Informe um e-mail válido.');
  let phone=null;
  if(input.phone!=null&&input.phone!=='') {
    try {phone=conversationUrl(input.phone).split('/').pop();}
    catch(error){throw new ValidationError(error.message);}
  }
  return {name, email, phone};
}
export function date(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new ValidationError('Próximo retorno: informe uma data válida.');
  const parsed = new Date(`${value}T12:00:00Z`);
  if (!Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0,10) !== value || value < '1900-01-01') throw new ValidationError('Próximo retorno: informe uma data válida.');
  return value;
}
export function ticketInput(input, old = null, day = today()) {
  if (old && closed(old.stage)) throw new ValidationError('Atendimento encerrado: disponível somente para consulta.', 409);
  const service = text(input.service, 'Serviço solicitado', 500);
  const owner_id = id(input.owner_id, 'Responsável');
  const customer_id = old ? old.customer_id : id(input.customer_id, 'Cliente');
  const stage = input.stage ?? 'Novo atendimento';
  if (!stages.includes(stage)) throw new ValidationError('Etapa inválida.');
  const note = input.note == null || input.note === '' ? '' : text(input.note, 'Observação', 2000);
  if (hasDuplicateNote(note)) throw new ValidationError(duplicateNoteMessage);
  if (!old && stage !== stages[0]) throw new ValidationError('Novos atendimentos começam em Novo atendimento.');
  const changed = old && old.stage !== stage;
  if (changed) {
    const allowed = [stages[stages.indexOf(old.stage)+1], 'Cancelado'];
    if (old.stage === 'Aguardando aprovação') allowed.push('Em avaliação');
    if (!allowed.includes(stage)) throw new ValidationError('Mudança de etapa não permitida. Siga a jornada do atendimento.');
    if (!(old.stage === 'Novo atendimento' && stage === 'Em avaliação') && !note) throw new ValidationError('Observação obrigatória: registre a proposta, aprovação, resultado ou motivo desta mudança.');
  }
  let next_return = null;
  if (!closed(stage)) {
    next_return = date(input.next_return);
    if ((!old || changed || next_return !== old.next_return) && next_return < day) throw new ValidationError('Próximo retorno: escolha hoje ou uma data futura.');
  }
  return {service, owner_id, customer_id, stage, note, next_return};
}
