import {leadRoute} from './leads.mjs';
import {activityRoute} from './activities.mjs';
import {customerHistory} from './customer-history.mjs';
import {assistantRoute} from './assistant.mjs';
import {financeRoute} from './finance.mjs';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { customerInput, ticketInput, ValidationError, id, today, stages } from './rules.mjs';
import {login,logout,requireUser,requireAdmin,publicUser,changePassword,clearCookie,listUsers,createUser,updateUser,resetPassword,audit} from './auth.mjs';

const files = {'/leads.js':['leads.js','text/javascript; charset=utf-8'],'/operations.js':['operations.js','text/javascript; charset=utf-8'],'/assistant.js':['assistant.js','text/javascript; charset=utf-8'],'/refinement.css':['refinement.css','text/css; charset=utf-8'],'/finance.js':['finance.js','text/javascript; charset=utf-8'],'/whatsapp.js':['whatsapp.js','text/javascript; charset=utf-8'],'/auth.js':['auth.js','text/javascript; charset=utf-8'],'/note-validation.js':['note-validation.js','text/javascript; charset=utf-8'],'/':['index.html','text/html; charset=utf-8'],'/app.js':['app.js','text/javascript; charset=utf-8'],'/style.css':['style.css','text/css; charset=utf-8'],'/yso-logo.jpg':['yso-logo.jpg','image/jpeg']};
const ticketSelect = `SELECT t.*, c.name AS customer_name,c.email AS customer_email,o.name AS owner_name
 FROM tickets t JOIN customers c ON c.id=t.customer_id JOIN owners o ON o.id=t.owner_id`;
function send(res, status, payload) { res.writeHead(status, {'Content-Type':'application/json; charset=utf-8'}); res.end(JSON.stringify(payload)); }
async function body(req) {
  if (!req.headers['content-type']?.startsWith('application/json')) throw new ValidationError('Envie dados no formato JSON.',415);
  let value = '';
  for await (const chunk of req) { value += chunk; if (Buffer.byteLength(value)>16384) throw new ValidationError('ConteÃºdo muito grande.',413); }
  try { const data = JSON.parse(value); if (!data || Array.isArray(data) || typeof data !== 'object') throw new Error(); return data; }
  catch { throw new ValidationError('Dados invÃ¡lidos.'); }
}
export function createApp(pool,{publicOrigin=null}={}) {
  if(publicOrigin&&new URL(publicOrigin).protocol!=='https:')throw new Error('O ambiente online exige HTTPS.');
  return createServer(async (req,res) => {
    res.crmSecure=!!publicOrigin;
    if(publicOrigin)res.setHeader('Strict-Transport-Security','max-age=31536000');
    res.setHeader('Cache-Control','no-store');
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    res.setHeader('Referrer-Policy','no-referrer');
    try {
      if(publicOrigin&&req.method==='GET'&&req.url==='/healthz') {
        await pool.query('SELECT 1');send(res,200,{ok:true});return;
      }
      const expectedOrigin=publicOrigin||`http://127.0.0.1:${req.socket.localPort}`;
      const expectedHost=new URL(expectedOrigin).host;
      if(req.headers.host!==expectedHost||(req.headers.origin&&req.headers.origin!==expectedOrigin))throw new ValidationError('Acesse pelo endereÃ§o autorizado do CRM.',403);
      if(req.headers['sec-fetch-site']==='cross-site'&&!['GET','HEAD'].includes(req.method))throw new ValidationError('Origem da operaÃ§Ã£o nÃ£o autorizada.',403);
      const url = new URL(req.url, expectedOrigin);
      if (req.method === 'GET' && files[url.pathname]) {
        const [name,type] = files[url.pathname];
        let contents = await readFile(new URL(`../public/${name}`,import.meta.url));
        if(publicOrigin&&name==='index.html')contents=contents.toString('utf8').replaceAll('Ambiente local','DemonstraÃ§Ã£o online').replaceAll('ExecuÃ§Ã£o local','DemonstraÃ§Ã£o online').replaceAll('Primeira versÃ£o local','DemonstraÃ§Ã£o online');
        res.writeHead(200,{'Content-Type':type}); res.end(contents); return;
      }
      if(!url.pathname.startsWith('/api/'))throw new ValidationError('PÃ¡gina nÃ£o encontrada.',404);
      if(url.pathname==='/api/auth/login'&&req.method==='POST') {
        send(res,200,{user:await login(pool,req,res,await body(req))});return;
      }
      if(url.pathname==='/api/auth/logout'&&req.method==='POST') {
        await body(req);await logout(pool,req,res);send(res,200,{ok:true});return;
      }
      const user=await requireUser(pool,req);
      if(url.pathname==='/api/auth/me'&&req.method==='GET'){send(res,200,{user:publicUser(user)});return;}
      if(url.pathname==='/api/auth/password'&&req.method==='POST') {
        await changePassword(pool,user,await body(req));clearCookie(res);send(res,200,{ok:true});return;
      }
      if(user.must_change_password)throw new ValidationError('Troque sua senha temporÃ¡ria antes de acessar os dados.',403);
      if(url.pathname.startsWith('/api/leads')){send(res,200,await leadRoute(pool,user,req.method,url.pathname,req.method==='POST'?await body(req):{}));return;}
      if(url.pathname.startsWith('/api/activities')){send(res,200,await activityRoute(pool,user,req.method,url.pathname,req.method==='POST'?await body(req):{}));return;}
      if(url.pathname.startsWith('/api/assistant')){send(res,200,await assistantRoute(pool,user,req.method,url.pathname,req.method==='POST'?await body(req):{}));return;}
      if(url.pathname.startsWith('/api/finance')){send(res,200,await financeRoute(pool,user,req.method,url.pathname,url,req.method==='POST'?await body(req):{}));return;}
      if(url.pathname.startsWith('/api/admin/')) {
        requireAdmin(user);
        if(url.pathname==='/api/admin/users'&&req.method==='GET'){send(res,200,{users:await listUsers(pool)});return;}
        if(url.pathname==='/api/admin/users'&&req.method==='POST'){send(res,201,{user:await createUser(pool,user,await body(req))});return;}
        const target=url.pathname.match(/^\/api\/admin\/users\/(\d+)(\/password)?$/);
        if(target&&req.method==='PUT'&&!target[2]){send(res,200,{user:await updateUser(pool,user,id(target[1],'UsuÃ¡rio'),await body(req))});return;}
        if(target&&req.method==='POST'&&target[2]){await resetPassword(pool,user,id(target[1],'UsuÃ¡rio'),await body(req));send(res,200,{ok:true});return;}
        if(url.pathname==='/api/admin/audit'&&req.method==='GET') {
          send(res,200,{events:(await pool.query('SELECT a.*,u.name AS actor_name FROM audit_events a LEFT JOIN app_users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 100')).rows});return;
        }
        throw new ValidationError('OperaÃ§Ã£o administrativa nÃ£o encontrada.',404);
      }
      if (req.method === 'GET' && url.pathname === '/api/state') {
        const [customers,owners,tickets] = await Promise.all([
          pool.query('SELECT * FROM customers ORDER BY name,id'), pool.query('SELECT * FROM owners ORDER BY id'),
          pool.query(`${ticketSelect} ORDER BY t.created_at DESC,t.id DESC`)
        ]);
        send(res,200,{customers:customers.rows,owners:owners.rows,tickets:tickets.rows,today:today(),stages,user:publicUser(user)}); return;
      }
      const historyRoute=url.pathname.match(/^\/api\/customers\/(\d+)\/history$/);
      if(historyRoute&&req.method==='GET'){send(res,200,await customerHistory(pool,id(historyRoute[1],'Cliente'),Object.fromEntries(url.searchParams)));return;}
      const customerRoute = url.pathname.match(/^\/api\/customers(?:\/(\d+))?$/);
      if (customerRoute && ['POST','PUT'].includes(req.method)) {
        const input = customerInput(await body(req));
        if (req.method === 'POST' && !customerRoute[1]) {
          const inserted = await pool.query('INSERT INTO customers(name,email,phone) VALUES ($1,$2,$3) ON CONFLICT(email) DO NOTHING RETURNING *',[input.name,input.email,input.phone]);
          const customer = inserted.rows[0] || (await pool.query('SELECT * FROM customers WHERE email=$1',[input.email])).rows[0];
          send(res,inserted.rowCount?201:200,{customer,reused:!inserted.rowCount}); return;
        }
        if (req.method === 'PUT' && customerRoute[1]) {
          const result = await pool.query('UPDATE customers SET name=$1,email=$2,phone=$4 WHERE id=$3 RETURNING *',[input.name,input.email,id(customerRoute[1],'Cliente'),input.phone]);
          if (!result.rowCount) throw new ValidationError('Cliente nÃ£o encontrado.',404);
          send(res,200,{customer:result.rows[0]}); return;
        }
      }
      const detail = url.pathname.match(/^\/api\/tickets\/(\d+)$/);
      if (req.method === 'GET' && detail) {
        const ticketId = id(detail[1],'Atendimento');
        const ticket = (await pool.query(`${ticketSelect} WHERE t.id=$1`,[ticketId])).rows[0];
        if (!ticket) throw new ValidationError('Atendimento nÃ£o encontrado.',404);
        ticket.notes = (await pool.query('SELECT n.*,u.name AS author_name FROM notes n LEFT JOIN app_users u ON u.id=n.author_id WHERE ticket_id=$1 ORDER BY n.id',[ticketId])).rows;
        send(res,200,ticket); return;
      }
      if ((req.method === 'POST' && url.pathname === '/api/tickets') || (req.method === 'PUT' && detail)) {
        const input = await body(req);
        const client = await pool.connect();
        try {
          await client.query('BEGIN');
          let old;
          if (detail) {
            old = (await client.query('SELECT * FROM tickets WHERE id=$1 FOR UPDATE',[id(detail[1],'Atendimento')])).rows[0];
            if (!old) throw new ValidationError('Atendimento nÃ£o encontrado.',404);
            if (input.version !== old.version) throw new ValidationError('Este atendimento foi atualizado em outra tela. Feche e abra novamente antes de salvar.',409);
          }
          const data = ticketInput(input,old);
          const params = [data.service,data.stage,data.owner_id,data.next_return];
          const ticket = old ? (await client.query('UPDATE tickets SET service=$1,stage=$2,owner_id=$3,next_return=$4,updated_at=now(),version=version+1 WHERE id=$5 RETURNING *',[...params,old.id])).rows[0]
            : (await client.query('INSERT INTO tickets(service,stage,owner_id,next_return,customer_id) VALUES ($1,$2,$3,$4,$5) RETURNING *',[...params,data.customer_id])).rows[0];
          if (data.note) await client.query('INSERT INTO notes(ticket_id,body,author_id) VALUES ($1,$2,$3)',[ticket.id,data.note,user.id]);
          await audit(client,user.id,old?'ticket_updated':'ticket_created','ticket',ticket.id);
          await client.query('COMMIT');
          send(res,old?200:201,ticket);
        } catch (error) { await client.query('ROLLBACK'); throw error; }
        finally { client.release(); }
        return;
      }
      throw new ValidationError('PÃ¡gina ou operaÃ§Ã£o nÃ£o encontrada.',404);
    } catch (error) {
      if (error instanceof ValidationError) send(res,error.status,{error:error.message});
      else if (error.code === '23505') send(res,409,{error:'Este e-mail jÃ¡ estÃ¡ cadastrado. Utilize o cadastro existente.'});
      else if (error.code === '23503') send(res,400,{error:'Cliente ou responsÃ¡vel nÃ£o encontrado. Atualize a lista.'});
      else if (error.code === '23514') send(res,400,{error:'Os dados nÃ£o atendem Ã s regras do atendimento.'});
      else { console.error('Falha na operaÃ§Ã£o:',error.code || error.name); send(res,503,{error:'NÃ£o foi possÃ­vel concluir a operaÃ§Ã£o. Verifique o PostgreSQL local e tente novamente; os dados do formulÃ¡rio foram mantidos.'}); }
    }
  });
}



