import test from 'node:test';
import assert from 'node:assert/strict';
import {suggest,assistantRoute} from '../src/assistant.mjs';
import {poolFor,migrate} from '../src/db.mjs';
import {config} from '../src/config.mjs';
test('roteiro encaminha riscos e não confirma agenda',()=>{
 assert.match(suggest('Qual horário?').reply,/8h/);
 assert.match(suggest('Quero agendar').reply,/nenhum horário está reservado/);
 for(const message of ['dor de dente','qual preço','quero humano','pedido desconhecido'])assert.equal(suggest(message).human,true);
});
test('persistência, isolamento, aprovação e pausa',async()=>{
 const pool=poolFor({...config(),database:'yso_crm_test'});
 try{
 await migrate(pool);
 const users=(await pool.query("INSERT INTO app_users(name,email,password_hash,role) VALUES ('Teste A','assistant-a@example.com','disabled-test-hash','attendant'),('Teste B','assistant-b@example.com','disabled-test-hash','attendant') ON CONFLICT(email) DO UPDATE SET name=EXCLUDED.name RETURNING id")).rows;assert.equal(users.length,2);
 let row=await assistantRoute(pool,users[0],'POST','/api/assistant');const path='/api/assistant/'+row.id;
 const act=async(action,text)=>{row=await assistantRoute(pool,users[0],'POST',path,{action,text,version:row.version});};
 await act('message','Qual horário?');assert.ok(row.pending);assert.equal(row.messages.length,1);
 const old=row.version;await act('approve');assert.equal(row.messages[1].role,'assistant');
 await assert.rejects(assistantRoute(pool,users[0],'POST',path,{action:'approve',version:old}),e=>e.status===409);
 await assert.rejects(assistantRoute(pool,users[1],'POST',path,{action:'takeover',version:row.version}),e=>e.status===404);
 await act('takeover');await act('message','Qual horário?');assert.equal(row.pending,null);
 await act('reply','Resposta fictícia');await act('resume');await act('message','Tenho dor');assert.equal(row.human,true);
 assert.ok((await assistantRoute(pool,users[0],'GET','/api/assistant')).conversations.some(c=>c.id===row.id));
 await pool.query('DELETE FROM assistant_simulations WHERE id=$1',[row.id]);
 }finally{await pool.end();}
});

test('coleta e confirma apenas pedido, com correção e intervenção humana',async()=>{
 const {bookingReply}=await import('../src/assistant.mjs');let booking={};
 for(const msg of ['Quero agendar','Marina Teste','limpeza','segunda de manhã','sim']){const r=bookingReply(msg,booking);booking=r.booking;}
 assert.equal(booking.step,'requested');assert.equal(booking.name,'Marina Teste');
 assert.equal(bookingReply('Tenho dor',{step:'name'}).human,true);
 assert.equal(bookingReply('não',{step:'confirm'}).booking.step,'name');
});

test('dúvidas e correções preservam coleta; preferências incompletas não avançam',async()=>{
 const {bookingReply}=await import('../src/assistant.mjs');
 const b={step:'preference',name:'Marina Teste',service:'Limpeza'};
 assert.equal(bookingReply('Qual o horário?',b).booking.step,'preference');
 assert.equal(bookingReply('obrigada',b).booking.step,'preference');
 for(const m of ['domingo de manhã','amanhã','qualquer coisa'])assert.equal(bookingReply(m,b).booking.step,'preference');
 assert.equal(bookingReply('terça de tarde',b).booking.step,'confirm');
 assert.equal(bookingReply('corrigir nome',b).booking.step,'name');
 assert.equal(bookingReply('quanto custa?',b).human,true);
});
