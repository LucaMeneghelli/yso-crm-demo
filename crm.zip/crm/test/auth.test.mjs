import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {config} from '../src/config.mjs';
import {poolFor,migrate} from '../src/db.mjs';
import {createApp} from '../src/server.mjs';
import {hashPassword,verifyPassword} from '../src/auth.mjs';
test('senhas usam salt aleatório e verificação segura',async()=>{
  const pass='Senha de teste que não é real!';
  const a=await hashPassword(pass),b=await hashPassword(pass);
  assert.notEqual(a,b);assert.ok(!a.includes(pass));
  assert.equal(await verifyPassword(pass,a),true);assert.equal(await verifyPassword('Errada',a),false);
  await assert.rejects(hashPassword('curta'));
});
test('login e permissões com PostgreSQL real',async t=>{
  const pool=poolFor({...config(),database:'yso_crm_test'});
  await migrate(pool);
  assert.equal((await pool.query('SELECT current_database() AS name')).rows[0].name,'yso_crm_test');
  await pool.query('TRUNCATE audit_events,app_sessions,auth_attempts,notes,tickets,customers,owners,app_users RESTART IDENTITY CASCADE');
  const pass='Senha fictícia para teste 123!';
  const hash=await hashPassword(pass);
  await pool.query("INSERT INTO app_users(name,email,password_hash,role,must_change_password) VALUES ('Admin Teste','admin@example.com',$1,'admin',false),('Recepção Teste','recepcao@example.com',$1,'attendant',false),('Primeiro acesso','novo@example.com',$1,'attendant',true)",[hash]);
  await pool.query("INSERT INTO owners(name) VALUES ('Recepção Demo')");
  const server=createApp(pool);server.listen(0,'127.0.0.1');await once(server,'listening');
  const origin=`http://127.0.0.1:${server.address().port}`;
  async function req(path,{method='GET',data,cookie='',headers={}}={}){
    const response=await fetch(origin+path,{method,headers:{'Content-Type':'application/json',Cookie:cookie,...headers},body:data?JSON.stringify(data):undefined});
    return {status:response.status,body:await response.json(),cookie:response.headers.get('set-cookie')};
  }
  const signIn=email=>req('/api/auth/login',{method:'POST',data:{email,password:pass}});
  let admin,attendant,newCookie;
  try {
    await t.test('todas as rotas de dados exigem sessão',async()=>{
      for(const path of ['/api/state','/api/tickets/1','/api/admin/users','/api/admin/audit'])assert.equal((await req(path)).status,401);
      assert.equal((await req('/api/customers',{method:'POST',data:{name:'X',email:'x@example.com'}})).status,401);
    });
    await t.test('login rejeita senha errada e origem externa',async()=>{
      assert.equal((await req('/api/auth/login',{method:'POST',data:{email:'admin@example.com',password:'errada'}})).status,401);
      assert.equal((await req('/api/auth/login',{method:'POST',data:{email:'admin@example.com',password:pass},headers:{Origin:'https://externo.example'}})).status,403);
    });
    await t.test('cookie opaco HttpOnly e SameSite, nenhum hash na resposta',async()=>{
      const a=await signIn('admin@example.com'),b=await signIn('recepcao@example.com');
      assert.equal(a.status,200);assert.match(a.cookie,/HttpOnly/);assert.match(a.cookie,/SameSite=Strict/);
      assert.equal(a.body.user.password_hash,undefined);assert.equal(a.body.user.token_hash,undefined);
      admin=a.cookie.split(';')[0];attendant=b.cookie.split(';')[0];
      const tokens=(await pool.query('SELECT token_hash FROM app_sessions')).rows;
      assert.ok(tokens.every(row=>!admin.includes(row.token_hash)));
    });
    await t.test('atendente opera cadastros mas não acessos ou auditoria',async()=>{
      assert.equal((await req('/api/state',{cookie:attendant})).status,200);
      assert.equal((await req('/api/customers',{cookie:attendant,method:'POST',data:{name:'Pessoa Demo',email:'pessoa@example.com'}})).status,201);
      for(const path of ['/api/admin/users','/api/admin/audit'])assert.equal((await req(path,{cookie:attendant})).status,403);
      assert.equal((await req('/api/admin/users',{cookie:attendant,method:'POST',data:{name:'Invasor',email:'x@example.com',role:'admin',password:pass}})).status,403);
      assert.equal((await req('/api/admin/users/2',{cookie:attendant,method:'PUT',data:{role:'admin',active:true}})).status,403);
      assert.equal((await req('/api/admin/users/1/password',{cookie:attendant,method:'POST',data:{password:pass}})).status,403);
    });
    await t.test('troca inicial obrigatória e senha antiga invalidada',async()=>{
      newCookie=(await signIn('novo@example.com')).cookie.split(';')[0];
      assert.equal((await req('/api/state',{cookie:newCookie})).status,403);
      assert.equal((await req('/api/auth/me',{cookie:newCookie})).body.user.must_change_password,true);
      assert.equal((await req('/api/auth/password',{cookie:newCookie,method:'POST',data:{current_password:'errada',new_password:'Outra senha fictícia 456!'}})).status,400);
      assert.equal((await req('/api/auth/password',{cookie:newCookie,method:'POST',data:{current_password:pass,new_password:'Outra senha fictícia 456!'}})).status,200);
      assert.equal((await req('/api/auth/me',{cookie:newCookie})).status,401);
      assert.equal((await signIn('novo@example.com')).status,401);
      const result=await req('/api/auth/login',{method:'POST',data:{email:'novo@example.com',password:'Outra senha fictícia 456!'}});
      assert.equal(result.status,200);assert.equal(result.body.user.must_change_password,false);
    });
    await t.test('admin cria conta sem expor senha e duplicidade é rejeitada',async()=>{
      const data={name:'Nova Recepção',email:'criado@example.com',password:pass,role:'attendant'};
      const created=await req('/api/admin/users',{cookie:admin,method:'POST',data});
      assert.equal(created.status,201);assert.equal(created.body.user.must_change_password,true);assert.equal(created.body.user.password_hash,undefined);
      assert.equal((await req('/api/admin/users',{cookie:admin,method:'POST',data})).status,409);
      const list=await req('/api/admin/users',{cookie:admin});assert.equal(list.body.users.length,4);assert.ok(list.body.users.every(u=>!u.password_hash));
    });
    await t.test('desativar revoga sessão e impede login; reativar não revive sessão',async()=>{
      assert.equal((await req('/api/admin/users/2',{cookie:admin,method:'PUT',data:{role:'attendant',active:false}})).status,200);
      assert.equal((await req('/api/state',{cookie:attendant})).status,401);
      assert.equal((await signIn('recepcao@example.com')).status,401);
      assert.equal((await req('/api/admin/users/2',{cookie:admin,method:'PUT',data:{role:'attendant',active:true}})).status,200);
      assert.equal((await req('/api/state',{cookie:attendant})).status,401);
      attendant=(await signIn('recepcao@example.com')).cookie.split(';')[0];
    });
    await t.test('admin não remove o próprio acesso',async()=>{
      assert.equal((await req('/api/admin/users/1',{cookie:admin,method:'PUT',data:{role:'attendant',active:true}})).status,400);
      assert.equal((await req('/api/admin/users/1',{cookie:admin,method:'PUT',data:{role:'admin',active:false}})).status,400);
    });
    await t.test('reset de senha revoga sessões e exige nova troca',async()=>{
      const result=await req('/api/admin/users/2/password',{cookie:admin,method:'POST',data:{password:'Senha temporária redefinida 789!'}});assert.equal(result.status,200);
      assert.equal((await req('/api/state',{cookie:attendant})).status,401);
      assert.equal((await signIn('recepcao@example.com')).status,401);
      const next=await req('/api/auth/login',{method:'POST',data:{email:'recepcao@example.com',password:'Senha temporária redefinida 789!'}});
      assert.equal(next.status,200);assert.equal(next.body.user.must_change_password,true);
    });
    await t.test('sessão expira por tempo absoluto e inatividade',async()=>{
      await pool.query("UPDATE app_sessions SET expires_at=now()-interval '1 second' WHERE user_id=1");
      assert.equal((await req('/api/state',{cookie:admin})).status,401);
      admin=(await signIn('admin@example.com')).cookie.split(';')[0];
      await pool.query("UPDATE app_sessions SET last_seen_at=now()-interval '31 minutes' WHERE user_id=1");
      assert.equal((await req('/api/state',{cookie:admin})).status,401);
      admin=(await signIn('admin@example.com')).cookie.split(';')[0];
    });
    await t.test('auditoria registra autor sem segredos e logout invalida sessão',async()=>{
      const result=await req('/api/admin/audit',{cookie:admin});assert.equal(result.status,200);assert.ok(result.body.events.some(e=>e.action==='password_reset'));assert.ok(!JSON.stringify(result.body).includes(pass));
      assert.equal((await req('/api/auth/logout',{cookie:admin,method:'POST',data:{}})).status,200);
      assert.equal((await req('/api/state',{cookie:admin})).status,401);
    });
    await t.test('tentativas excessivas são limitadas',async()=>{
      let result;for(let i=0;i<11;i++)result=await req('/api/auth/login',{method:'POST',data:{email:'ausente@example.com',password:'errada'}});
      assert.equal(result.status,429);
    });
  }finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await pool.end();}
});
