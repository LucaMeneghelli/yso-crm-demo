import test from 'node:test';
import assert from 'node:assert/strict';
import {cloudFailureHint} from '../src/cloud-diagnostics.mjs';

test('diagnostico reconhece falhas sem divulgar detalhes privados',()=>{
  for(const [message,expected] of [
    ['Tenant or user not found','POOLER_TENANT'],
    ['password authentication failed for user private-user','DB_PASSWORD'],
    ['unsupported startup parameter: options','POOLER_OPTIONS'],
    ['self-signed certificate in certificate chain','DB_TLS'],
    ['unknown postgresql://private-user:secret-password@host/db','detalhes sensiveis omitidos'],
  ]) {
    const result=cloudFailureHint(new Error(message));
    assert.ok(result.includes(expected));
    assert.doesNotMatch(result,/private-user|secret-password|postgresql:\/\//);
  }
});
