import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {request as httpRequest} from 'node:http';
import {cloudConfig} from '../src/cloud-config.mjs';
import {bootstrapCloud} from '../src/cloud-bootstrap.mjs';
import {config} from '../src/config.mjs';
import {poolFor} from '../src/db.mjs';
import {createApp} from '../src/server.mjs';

test('configuração online exige HTTPS e validação TLS do PostgreSQL',()=>{
  const env={PUBLIC_ORIGIN:'https://crm.example.com',DATABASE_URL:'postgresql://user:pass@db.example.com/demo'};
  const c=cloudConfig(env);assert.equal(c.db.ssl.rejectUnauthorized,true);assert.equal(c.port,10000);assert.equal(c.origin,env.PUBLIC_ORIGIN);
  assert.match(c.db.options,/yso_crm/);
  for(const bad of ['http://crm.example.com','https://crm.example.com/path','https://user:pass@crm.example.com','https://crm.example.com?x=1'])assert.throws(()=>cloudConfig({...env,PUBLIC_ORIGIN:bad}));
  assert.throws(()=>cloudConfig({...env,DATABASE_URL:env.DATABASE_URL+'?sslmode=no-verify'}));
  assert.throws(()=>cloudConfig({...env,PORT:'NaN'}));
  assert.equal(cloudConfig({...env,PUBLIC_ORIGIN:undefined,RENDER_EXTERNAL_URL:env.PUBLIC_ORIGIN}).origin,env.PUBLIC_ORIGIN);
});

test('online: banco privado, bootstrap idempotente e sessão Secure',async t=>{
  const p=poolFor({...config(),database:'yso_crm_test',options:'-c search_path=yso_crm,pg_catalog'});
  assert.equal((await p.query('SELECT current_database() AS name')).rows[0].name,'yso_crm_test');
  // Dedicated schema in the disposable test database only.
  await p.query('DROP SCHEMA IF EXISTS yso_crm CASCADE');
  const secrets={SEED_DEMO_DATA:'true',DEMO_ADMIN_PASSWORD:'Senha de admin fictícia 123!',DEMO_ATTENDANT_PASSWORD:'Senha de atendente fictícia 456!'};
  let server;
  try {
    await bootstrapCloud(p,secrets);
    await t.test('cria exemplos clínicos fictícios e preserva o estado em novo deploy',async()=>{
      const before=(await p.query('SELECT * FROM app_users ORDER BY id')).rows;
      assert.equal(before.length,2);assert.ok(before.every(u=>u.must_change_password));
      await bootstrapCloud(p,{});
      assert.deepEqual((await p.query('SELECT * FROM app_users ORDER BY id')).rows,before);
      assert.equal((await p.query('SELECT count(*)::int n FROM customers')).rows[0].n,1);
      assert.equal((await p.query('SELECT service FROM tickets')).rows[0].service,'Solicitação de agendamento — simulação');
      assert.equal((await p.query("SELECT has_schema_privilege('public','yso_crm','usage') allowed")).rows[0].allowed,false);
    });
    server=createApp(p,{publicOrigin:'https://crm.example.com'});server.listen(0,'127.0.0.1');await once(server,'listening');
    const base=`http://127.0.0.1:${server.address().port}`;
    const request=(path,opts={})=>new Promise((resolve,reject)=>{
      const req=httpRequest(base+path,{method:opts.method||'GET',headers:{Host:'crm.example.com',...opts.headers}},res=>{
        let data='';res.setEncoding('utf8');res.on('data',chunk=>data+=chunk);
        res.on('end',()=>resolve({status:res.statusCode,headers:{get:name=>Array.isArray(res.headers[name])?res.headers[name][0]:res.headers[name]},text:async()=>data}));
      });req.on('error',reject);req.end(opts.body);
    });
    await t.test('origem autorizada, healthcheck e tela online',async()=>{
      assert.equal((await fetch(base+'/')).status,403);
      assert.equal((await fetch(base+'/healthz')).status,200);
      const page=await request('/');assert.equal(page.status,200);assert.match(page.headers.get('strict-transport-security'),/max-age/);assert.match(await page.text(),/Gestão de recepção/);
      assert.equal((await request('/api/state')).status,401);
      assert.equal((await request('/api/auth/login',{method:'POST',headers:{Origin:'https://outro.example'}})).status,403);
      assert.equal((await request('/api/auth/login',{method:'POST',headers:{'Sec-Fetch-Site':'cross-site'}})).status,403);
    });
    await t.test('login e logout geram cookies seguros e exigem troca inicial',async()=>{
      const response=await request('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json',Origin:'https://crm.example.com'},body:JSON.stringify({email:'admin@yso.local',password:secrets.DEMO_ADMIN_PASSWORD})});
      assert.equal(response.status,200);assert.match(response.headers.get('set-cookie'),/; Secure/);
      const cookie=response.headers.get('set-cookie').split(';')[0];
      assert.equal((await request('/api/state',{headers:{Cookie:cookie}})).status,403);
      const logout=await request('/api/auth/logout',{method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},body:'{}'});
      assert.equal(logout.status,200);assert.match(logout.headers.get('set-cookie'),/Max-Age=0; Secure/);
    });
  }finally {if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}await p.end();}
});
