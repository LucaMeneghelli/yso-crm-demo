import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { poolFor, migrate } from '../src/db.mjs';
import { config } from '../src/config.mjs';
import { createApp } from '../src/server.mjs';
import { today } from '../src/rules.mjs';
import {hashPassword} from '../src/auth.mjs';

test('API real com PostgreSQL isolado',async t=>{
  const settings={...config(),database:'yso_crm_test'};
  assert.equal(settings.database,'yso_crm_test');
  const pool=poolFor(settings);
  await migrate(pool);
  assert.equal((await pool.query('SELECT current_database() AS name')).rows[0].name,'yso_crm_test');
  await pool.query('TRUNCATE audit_events,app_sessions,auth_attempts,notes,tickets,customers,owners,app_users RESTART IDENTITY CASCADE');
  await pool.query("INSERT INTO app_users(name,email,password_hash,role,must_change_password) VALUES ('Teste Admin','admin@example.com',$1,'admin',false)",[await hashPassword('Senha de teste isolada 123!')]);
  await pool.query("INSERT INTO owners(name) VALUES ('Bia Demo'),('Rui Demo')");
  const server=createApp(pool);server.listen(0,'127.0.0.1');await once(server,'listening');
  const origin=`http://127.0.0.1:${server.address().port}`;
  const loginResponse=await fetch(origin+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:'admin@example.com',password:'Senha de teste isolada 123!'})});
  assert.equal(loginResponse.status,200);
  const cookie=loginResponse.headers.get('set-cookie').split(';')[0];
  async function request(path,method='GET',data,headers={}) {
    const response=await fetch(origin+path,{method,headers:{'Content-Type':'application/json',Cookie:cookie,...headers},body:data?JSON.stringify(data):undefined});
    return {status:response.status,body:await response.json()};
  }
  let customer,ticket;
  try {
    await t.test('cria cliente e reutiliza contato normalizado',async()=>{
      const result=await request('/api/customers','POST',{name:'Ana Cliente Demo',email:'ana@example.com',phone:'+1 (202) 555-0100'});
      assert.equal(result.status,201);customer=result.body.customer;assert.equal(customer.phone,'12025550100');
      await migrate(pool);assert.equal((await pool.query('SELECT phone FROM customers WHERE id=$1',[customer.id])).rows[0].phone,customer.phone);
      const duplicate=await request('/api/customers','POST',{name:'Outro nome',email:' ANA@EXAMPLE.COM '});
      assert.equal(duplicate.status,200);assert.equal(duplicate.body.customer.id,customer.id);assert.equal(duplicate.body.reused,true);
    });
    await t.test('edita cliente sem substituir contato de outro cadastro',async()=>{
      const other=await request('/api/customers','POST',{name:'Outro Demo',email:'outro@example.com'});
      const conflict=await request(`/api/customers/${customer.id}`,'PUT',{name:'Ana Demo',email:other.body.customer.email});
      assert.equal(conflict.status,409);
      const updated=await request(`/api/customers/${customer.id}`,'PUT',{name:'Ana Cliente Demo',email:customer.email,phone:'+1 (202) 555-0101'});assert.equal(updated.status,200);assert.equal(updated.body.customer.phone,'12025550101');
    });
    await t.test('API rejeita contato inválido e origem externa',async()=>{
      assert.equal((await request('/api/customers','POST',{name:'Teste',email:'invalido'})).status,400);
      assert.equal((await request('/api/customers','POST',{name:'Teste',email:'teste@example.com'},{Origin:'https://externo.example'})).status,403);
    });
    await t.test('observação duplicada não cria atendimento',async()=>{
      const before=(await pool.query('SELECT count(*)::int AS n FROM tickets')).rows[0].n;
      const result=await request('/api/tickets','POST',{customer_id:customer.id,service:'Revisão fictícia',owner_id:1,next_return:today(),note:'Cliente aguarda avaliação. Cliente aguarda avaliação.'});
      assert.equal(result.status,400);assert.match(result.body.error,/texto repetido/);
      assert.equal((await pool.query('SELECT count(*)::int AS n FROM tickets')).rows[0].n,before);
    });
    await t.test('cria atendimento com nota',async()=>{
      const result=await request('/api/tickets','POST',{customer_id:customer.id,service:'Revisão fictícia',owner_id:1,next_return:today(),note:'Solicitação recebida.'});
      assert.equal(result.status,201);ticket=result.body;
      assert.equal((await request(`/api/tickets/${ticket.id}`)).body.notes.length,1);
    });
    await t.test('duplicação rejeitada preserva etapa, versão e histórico',async()=>{
      const path=`/api/tickets/${ticket.id}`;
      const before=(await request(path)).body;
      const result=await request(path,'PUT',{...ticket,stage:'Em avaliação',note:'Avaliação fictícia iniciada. Avaliação fictícia iniciada.'});
      assert.equal(result.status,400);assert.match(result.body.error,/texto repetido/);
      assert.deepEqual((await request(path)).body,before);
    });
    await t.test('impede saltos, notas ausentes e atualizações concorrentes',async()=>{
      const url=`/api/tickets/${ticket.id}`;
      assert.equal((await request(url,'PUT',{...ticket,stage:'Em execução',note:'Pular'})).status,400);
      const first=await request(url,'PUT',{...ticket,stage:'Em avaliação'});assert.equal(first.status,200);
      assert.equal((await request(url,'PUT',{...ticket,stage:'Em avaliação'})).status,409);
      ticket=first.body;
      assert.equal((await request(url,'PUT',{...ticket,stage:'Aguardando aprovação'})).status,400);
    });
    await t.test('falha de referência desfaz mudança e preserva notas',async()=>{
      const before=(await request(`/api/tickets/${ticket.id}`)).body;
      const result=await request(`/api/tickets/${ticket.id}`,'PUT',{...ticket,owner_id:999999,note:'Não deve ser salva'});
      assert.equal(result.status,400);
      const after=(await request(`/api/tickets/${ticket.id}`)).body;
      assert.equal(after.version,before.version);assert.equal(after.notes.length,before.notes.length);
    });
    await t.test('percorre proposta, revisão, aprovação e conclusão',async()=>{
      for(const [stage,note] of [['Aguardando aprovação','Diagnóstico e proposta simulados.'],['Em avaliação','Cliente pediu revisão fictícia.'],['Aguardando aprovação','Nova proposta simulada.'],['Em execução','Aprovação fictícia registrada.'],['Concluído','Serviço concluído e entrega simulada realizada.']]) {
        const result=await request(`/api/tickets/${ticket.id}`,'PUT',{...ticket,stage,note});
        assert.equal(result.status,200,JSON.stringify(result.body));ticket=result.body;
      }
      assert.equal(ticket.next_return,null);
      const result=await request(`/api/tickets/${ticket.id}`);assert.equal(result.body.notes.length,6);
      assert.equal((await request(`/api/tickets/${ticket.id}`,'PUT',{...ticket,note:'Alterar encerrado'})).status,409);
    });
    await t.test('mesmo cliente possui outro atendimento e cancelamento com motivo',async()=>{
      const created=await request('/api/tickets','POST',{customer_id:customer.id,service:'Outro pedido fictício',owner_id:2,next_return:today()});
      assert.equal(created.status,201);
      assert.equal((await request(`/api/tickets/${created.body.id}`,'PUT',{...created.body,stage:'Cancelado'})).status,400);
      const cancel=await request(`/api/tickets/${created.body.id}`,'PUT',{...created.body,stage:'Cancelado',note:'Desistência fictícia.'});
      assert.equal(cancel.status,200);assert.equal(cancel.body.next_return,null);
    });
    await t.test('dados permanecem após reconectar ao banco',async()=>{
      const second=poolFor(settings);
      try {assert.equal((await second.query('SELECT count(*)::int AS n FROM tickets')).rows[0].n,2);}
      finally{await second.end();}
    });
    await t.test('entrega interface e não expõe arquivos internos',async()=>{
      const html=await fetch(origin);assert.equal(html.status,200);assert.match(await html.text(),/Dr. Alexandre Fuzimoto/);
      assert.equal((await fetch(origin+'/src/config.mjs')).status,404);
    });
  } finally {server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await pool.end();}
});
