import test from 'node:test';
import assert from 'node:assert/strict';
import {operationalView} from '../public/operations.js';
test('Meu dia separa prioridades e exclui encerrados; quadro mantém todas etapas',()=>{
 const tickets=[{id:1,stage:'Novo atendimento',next_return:'2026-10-29',customer_name:'Teste',service:'Limpeza',owner_name:'Equipe'},{id:2,stage:'Concluído',next_return:null,customer_name:'Encerrado',service:'Avaliação',owner_name:'Equipe'}];
 const params={tickets,stages:['Novo atendimento','Concluído'],today:'2026-10-30',escape:v=>String(v??'')};
 const day=operationalView({...params,view:'day'});assert.ok(day.includes('data-ticket="1"'));assert.ok(!day.includes('data-ticket="2"'));assert.ok(day.includes('Atrasados'));
 const board=operationalView({...params,view:'board'});assert.ok(board.includes('data-ticket="2"'));assert.equal(tickets[0].id,1);
});

test('próxima ação explica urgência sem reabrir encerrados',async()=>{
 const {nextAction}=await import('../public/operations.js');
 assert.equal(nextAction({stage:'Concluído',next_return:null},'2026-10-30').reason,'Atendimento encerrado');
 assert.equal(nextAction({stage:'Novo atendimento',next_return:null},'2026-10-30').reason,'Definir data de retorno');
 assert.equal(nextAction({stage:'Em execução',next_return:'2026-10-29'},'2026-10-30').reason,'Retorno atrasado');
 assert.match(nextAction({stage:'Aguardando aprovação',next_return:'2026-10-30'},'2026-10-30').label,/proposta/);
});
