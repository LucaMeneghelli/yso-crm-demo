import test from 'node:test';
import assert from 'node:assert/strict';
import {today,customerInput,ticketInput,date} from '../src/rules.mjs';
const basic = {service:'Revisão fictícia',customer_id:1,owner_id:1,next_return:'2026-10-26'};
test('bloqueia frases e blocos duplicados sem alterar o texto',()=>{
  const phrase='Cliente fictício relata ruído ao frear. Aguardando avaliação da oficina.';
  for(const note of [`${phrase} ${phrase}`, 'Avaliação fictícia iniciada.\nAVALIAÇÃO   FICTÍCIA INICIADA.', 'Cliente aguarda avaliação cliente aguarda avaliação', 'Aguardar contato do cliente. Serviço em análise. Aguardar contato do cliente.']) {
    assert.throws(()=>ticketInput({...basic,note},null,'2026-10-26'),/texto repetido/);
  }
});
test('permite palavras recorrentes e observações diferentes',()=>{
  for(const note of ['Pastilhas dianteiras verificadas. Pastilhas traseiras em avaliação.', 'Valor R$ 350,00. Prazo de 1 dia útil.', 'Não, não há aprovação.', 'Cliente pediu retorno. Cliente confirmou o retorno.']) {
    assert.equal(ticketInput({...basic,note},null,'2026-10-26').note,note);
  }
});
test('calendário brasileiro respeita a virada do dia',()=>{
  assert.equal(today(new Date('2026-10-27T02:59:59Z')),'2026-10-26');
  assert.equal(today(new Date('2026-10-27T03:00:00Z')),'2026-10-27');
});
test('contato normalizado e telefone opcional validado',()=>{
  assert.deepEqual(customerInput({name:' Ana Demo ',email:' ANA@EXAMPLE.COM '}),{name:'Ana Demo',email:'ana@example.com',phone:null});
  assert.equal(customerInput({name:'Ana',email:'ana@clinica.example',phone:'+1 (202) 555-0100'}).phone,'12025550100');
  assert.throws(()=>customerInput({name:'Ana',email:'invalido'}));
  assert.throws(()=>customerInput({name:'Ana',email:'ana@example.com',phone:'javascript:alert(1)'}));
  assert.throws(()=>customerInput({name:'  ',email:'ana@example.com'}));
});
test('datas inexistentes não são aceitas',()=>{
  for(const value of ['2026-02-30','2026-13-01','26/10/2026',''])assert.throws(()=>date(value));
  assert.equal(date('2028-02-29'),'2028-02-29');
});
test('abertura exige responsável, serviço e retorno válido',()=>{
  assert.equal(ticketInput(basic,null,'2026-10-26').stage,'Novo atendimento');
  for(const input of [{...basic,owner_id:''},{...basic,service:' '},{...basic,next_return:'2026-10-25'},{...basic,stage:'Em execução'}]) assert.throws(()=>ticketInput(input,null,'2026-10-26'));
});
test('retorno vencido pode permanecer ao editar outros campos, mas não ao avançar',()=>{
  const old={...basic,stage:'Em avaliação',next_return:'2026-10-25'};
  assert.equal(ticketInput({...old,service:'Pedido revisado'},old,'2026-10-26').next_return,'2026-10-25');
  assert.throws(()=>ticketInput({...old,stage:'Aguardando aprovação',note:'Proposta fictícia'},old,'2026-10-26'));
});
test('encerramento exige nota e limpa retorno mesmo vencido',()=>{
  const old={...basic,stage:'Em execução',next_return:'2026-10-25'};
  assert.throws(()=>ticketInput({...old,stage:'Concluído'},old,'2026-10-26'));
  assert.equal(ticketInput({...old,stage:'Concluído',note:'Serviço concluído e entregue na simulação'},old,'2026-10-26').next_return,null);
  assert.equal(ticketInput({...old,stage:'Cancelado',note:'Desistência fictícia'},old,'2026-10-26').next_return,null);
});
test('revisão exige justificativa e etapas não podem ser puladas',()=>{
  const old={...basic,stage:'Aguardando aprovação'};
  assert.equal(ticketInput({...old,stage:'Em avaliação',note:'Revisar proposta'},old,'2026-10-26').stage,'Em avaliação');
  assert.throws(()=>ticketInput({...old,stage:'Em avaliação'},old,'2026-10-26'));
  assert.throws(()=>ticketInput({...old,stage:'Concluído',note:'Pular'},old,'2026-10-26'));
});
test('encerrados são somente leitura',()=>{
  for(const stage of ['Concluído','Cancelado'])assert.throws(()=>ticketInput({...basic,stage}, {...basic,stage},'2026-10-26'));
});
