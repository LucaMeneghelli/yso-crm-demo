import test from 'node:test';
import assert from 'node:assert/strict';
import {conversationUrl} from '../public/whatsapp.js';
test('atalho WhatsApp aceita telefone internacional e nunca inclui dados do atendimento',()=>{
  assert.equal(conversationUrl('+1 (202) 555-0100'),'https://wa.me/12025550100');
  for(const value of ['',null,'0123456789','javascript:alert(1)','123?text=segredo','123','1'.repeat(16)])assert.throws(()=>conversationUrl(value));
  assert.equal(new URL(conversationUrl('12025550100')).search,'');
});
